package com.nalamfarms.notification_service.service;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class NotificationKafkaConfig {
	
	  private static final Logger logger = LoggerFactory.getLogger(NotificationKafkaConfig.class);


  @Bean
  public ProducerFactory<String, Object> producerFactory() {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
    logger.debug("Creating ProducerFactory bean for PaymentKafkaConfig");
    configProps.put("max.block.ms", "2000"); 
    return new DefaultKafkaProducerFactory<>(configProps);
  }

  @Bean
  public KafkaTemplate<String, Object> kafkaTemplate() {
    KafkaTemplate<String, Object> template = new KafkaTemplate<>(producerFactory());
    logger.debug("Creating KafkaTemplate bean for PaymentKafkaConfig: " + template);
    return template;
  }
  
  

  @Bean
  public AdminClient adminClient() {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
    return AdminClient.create(configProps);
  }



//  @Bean
//  public ConsumerFactory<String, OrderEventDto> consumerFactory() {
//    // Configure the deserializer to handle the message properly
//    JsonDeserializer<OrderEventDto> deserializer = new JsonDeserializer<>(OrderEventDto.class);
//    deserializer.addTrustedPackages("*");
//
//    Map<String, Object> consumerProps = new HashMap<>();
//    consumerProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//    consumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, "notification-service-group");
//    consumerProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//    consumerProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
//
//    return new DefaultKafkaConsumerFactory<>(consumerProps, new StringDeserializer(), deserializer);
//  }
//
//  @Bean
//  public ConcurrentKafkaListenerContainerFactory<String, OrderEventDto> kafkaListenerContainerFactory() {
//    ConcurrentKafkaListenerContainerFactory<String, OrderEventDto> factory =
//      new ConcurrentKafkaListenerContainerFactory<>();
//    factory.setConsumerFactory(consumerFactory());
//    return factory;
//  }
}



//
//import com.nalamfarms.notification_service.DTO.OrderEventDto;
//import org.apache.kafka.clients.admin.AdminClient;
//import org.apache.kafka.clients.admin.AdminClientConfig;
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.producer.ProducerConfig;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.apache.kafka.common.serialization.StringSerializer;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.kafka.annotation.EnableKafka;
//import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
//import org.springframework.kafka.core.*;
//import org.springframework.kafka.support.serializer.JsonDeserializer;
//import org.springframework.kafka.support.serializer.JsonSerializer;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Configuration
//@EnableKafka
//public class NotificationKafkaConfig {
//
//  @Bean
//  public ProducerFactory<String, Object> producerFactory() {
//    Map<String, Object> configProps = new HashMap<>();
//    configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
//    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
//    configProps.put("spring.json.add.type.headers", true);
//    configProps.put("spring.json.type.mapping", "orderEvent:com.nalamfarms.notification_service.dto.OrderEventDto");
//    System.out.println("Creating ProducerFactory bean for NotificationKafkaConfig");
//    return new DefaultKafkaProducerFactory<>(configProps);
//  }
//
//  @Bean
//  public KafkaTemplate<String, Object> kafkaTemplate() {
//    KafkaTemplate<String, Object> template = new KafkaTemplate<>(producerFactory());
//    System.out.println("Creating KafkaTemplate bean for NotificationKafkaConfig: " + template);
//    return template;
//  }
//
//  @Bean
//  public AdminClient adminClient() {
//    Map<String, Object> configProps = new HashMap<>();
//    configProps.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//    System.out.println("Creating AdminClient bean for NotificationKafkaConfig");
//    return AdminClient.create(configProps);
//  }
//
//  @Bean
//  public ConsumerFactory<String, OrderEventDto> consumerFactory() {
//    Map<String, Object> configProps = new HashMap<>();
//    configProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//    configProps.put(ConsumerConfig.GROUP_ID_CONFIG, "notification-service-group");
//    configProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//    configProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
//    configProps.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
//    configProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//    configProps.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "45000");
//    configProps.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "3000");
//    configProps.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "300000");
//    System.out.println("Creating ConsumerFactory bean for NotificationKafkaConfig");
//    return new DefaultKafkaConsumerFactory<>(configProps);
//  }
//
//  @Bean
//  public ConcurrentKafkaListenerContainerFactory<String, OrderEventDto> kafkaListenerContainerFactory() {
//    ConcurrentKafkaListenerContainerFactory<String, OrderEventDto> factory = new ConcurrentKafkaListenerContainerFactory<>();
//    factory.setConsumerFactory(consumerFactory());
//    System.out.println("Creating kafkaListenerContainerFactory bean for NotificationKafkaConfig");
//    return factory;
//  }
//
//  @Bean
//  public ConsumerFactory<String, String> stringConsumerFactory() {
//    Map<String, Object> configProps = new HashMap<>();
//    configProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//    configProps.put(ConsumerConfig.GROUP_ID_CONFIG, "notification-service-group-raw");
//    configProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//    configProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
//    configProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
//    configProps.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "45000");
//    configProps.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "3000");
//    configProps.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "300000");
//    System.out.println("Creating stringConsumerFactory bean for NotificationKafkaConfig");
//    return new DefaultKafkaConsumerFactory<>(configProps);
//  }
//
//  @Bean
//  public ConcurrentKafkaListenerContainerFactory<String, String> stringKafkaListenerContainerFactory() {
//    ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
//    factory.setConsumerFactory(stringConsumerFactory());
//    System.out.println("Creating stringKafkaListenerContainerFactory bean for NotificationKafkaConfig");
//    return factory;
//  }
//}
