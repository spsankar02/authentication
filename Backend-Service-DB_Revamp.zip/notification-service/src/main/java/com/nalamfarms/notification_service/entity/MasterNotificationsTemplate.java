package com.nalamfarms.notification_service.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "master_notifications_template")
public class MasterNotificationsTemplate {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "notification_id")
  private Long notificationId;

  @Column(name = "type")
  private String type;

  @Column(name = "title")
  private String title;

  @Column(name = "body")
  private String body;

  @Column(name = "channel")
  private String channel;

  @Column(name = "is_active")
  private Boolean isActive;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @Column(name = "modified_at")
  private LocalDateTime modifiedAt;

  @Column(name = "created_by")
  private Long createdBy;

  @Column(name = "modified_by")
  private Long modifiedBy;

}
