package com.nalamfarms.notification_service.util;


public class ResponseContent {
	
	private ResponseContent() {}
	
	/**========== ERROR MESSAGES ==========**/
	public static final String INVENTORY_UPDATE_ERRORMESSAGE="Error Occurred While Updating the Inventory Details";
	public static final String NOTIFICATION_UPDATE_ERRORMESSAGE="Error updating notification read status: ";
	 /** ========== EXCEPTION MESSAGES ========== */
	public static final String INVALID_MEMBER_EXCEPTION="invalid member details";
	public static final String INVENTORY_UPDATE_EXCEPTION="Failed to process inventory.updated message";
	
	/** ========== SUCCESS MESSAGES ========== */
	public static final String SHIPMENT_ADDED_MESSAGE = "shipment details added successfully";
	
	/** ========== STATUS MESSAGES ========== */
	public static final String USER_NAME="user_name";
	public static final String ORDER_ID="order_id";
	public static final String TRACKING_LINK="tracking_link";
	public static final String DISCOUNT="discount";
	public static final String PROMO_CODE="promo_code";
	public static final String ITEM_ID="itemId";
	public static final String BASKET_ID="basketId";
	public static final String USER = "user";
	public static final String YOUR_ORDERS ="your orders";
	public static final String DISCOUNT_UPPERCASE="Discount";
	public static final String NALAM="NALAM";
	public static final String EMAIL="Email";
	public static final String PUSH = "Push";
	public static final String SMS = "SMS";
	public static final String WHATS_APP = "Whats App";
	public static final String ORDER_CONFIRMATION ="ORDER_CONFIRMATION";
	public static final String ORDER_CONFIRMATION_LOWERCASE ="Order Confirmation";
	public static final String EMAIL_UPPERCASE="EMAIL";
	public static final String NOTIFICATION_NOT_FOUND="Notification not found with id: ";
	public static final String NOTIFICATION_READ="Notification marked as read.";
	public static final String NOTIFICATION_SEND="notification.send";
	
	
	
}

