package com.nalamfarms.notification_service.repository;

import com.nalamfarms.notification_service.entity.MasterNotificationsTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MasterNotificationsTemplateRepo extends JpaRepository<MasterNotificationsTemplate,Long> {
    MasterNotificationsTemplate findByType(String notificationType);
}
