package com.nalamfarms.notification_service.service;

import com.nalamfarms.notification_service.dto.*;
import org.springframework.stereotype.Service;

@Service
public interface NotificationService {
  void sendNotification(NotificationDto notificationDTO);
  void __sendNotification(NotificationRequestDto notificationDto);

  void sendNotifications(OrderEventDto orderEventDto);
  TxnNotificationResponse markNotificationAsRead(Long generalNotificationId);
  NotificationSummaryResponse getTxnGeneralNotification(Long toMemberId);
}
