package com.nalamfarms.notification_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class NotificationDto {
    private Long memberId;
    private String orderId;
    private String notificationType;
    private String trackingLink;
    private String Discount;
    private String promoCode;
    private String itemId;
    private String basketId;
    private Long referredMemberId;
    private String phoneNumber;

}
