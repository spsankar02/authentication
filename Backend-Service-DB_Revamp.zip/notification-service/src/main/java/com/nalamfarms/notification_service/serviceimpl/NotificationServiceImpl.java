package com.nalamfarms.notification_service.serviceimpl;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.nalamfarms.notification_service.dto.MemberDetailsDto;
import com.nalamfarms.notification_service.dto.NotificationDto;
import com.nalamfarms.notification_service.dto.NotificationRequestDto;
import com.nalamfarms.notification_service.dto.NotificationSummaryResponse;
import com.nalamfarms.notification_service.dto.OrderEventDto;
import com.nalamfarms.notification_service.dto.TxnNotificationResponse;
import com.nalamfarms.notification_service.entity.MasterNotificationsTemplate;
import com.nalamfarms.notification_service.entity.MemberNotificationSettings;
import com.nalamfarms.notification_service.entity.TxnGeneralNotification;
import com.nalamfarms.notification_service.repository.MasterNotificationTypesRepo;
import com.nalamfarms.notification_service.repository.MasterNotificationsTemplateRepo;
import com.nalamfarms.notification_service.repository.MemberNotificationSettingsRepo;
import com.nalamfarms.notification_service.repository.TxnGeneralNotificationRepository;
import com.nalamfarms.notification_service.service.NotificationService;
import com.nalamfarms.notification_service.util.FcmPushNotification;
import com.nalamfarms.notification_service.util.ResponseContent;
import com.nalamfarms.notification_service.util.SendWhatsAppNotification;
import com.nalamfarms.notification_service.util.TemplateEngine;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class NotificationServiceImpl implements NotificationService {

  private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);

  private final MasterNotificationsTemplateRepo masterNotificationsTemplateRepo;
  private final MemberNotificationSettingsRepo memberNotificationSettingsRepo;
  //private final MasterNotificationTypesRepo masterNotificationTypesRepo;
  private final FcmPushNotification fcmPushNotification;
  private final SendWhatsAppNotification sendWhatsAppNotification;
  private final TxnGeneralNotificationRepository txnGeneralNotificationRepo;
  //private WebClient webClient;

  @Value("${user.service.url}")
  String userServiceUrl;

  @Value("${product.service.url}")
  String productServiceUrl;



  @Override
  public void sendNotification(NotificationDto notificationDTO) {
    try {
      logger.info("Received notification DTO: {}", notificationDTO);

      MasterNotificationsTemplate masterTemplate = masterNotificationsTemplateRepo.findByType(notificationDTO.getNotificationType());
      if (masterTemplate == null) {
        logger.warn("No template found for notification type: {}", notificationDTO.getNotificationType());
        return;
      }
      MemberDetailsDto member =getMemberDetails(notificationDTO.getMemberId()!=null?notificationDTO.getMemberId():notificationDTO.getReferredMemberId()!=null?notificationDTO.getReferredMemberId():null);

      logger.info("member details : {}", member);
      if(member == null){
        throw new RuntimeException(ResponseContent.INVALID_MEMBER_EXCEPTION);
      }
      String memberName = member.getFirstname()!=null?member.getFirstname():"".concat(member.getLastname()!=null?member.getLastname():"");
      String deviceToken = member.getToken();
      Map<String, String> values = new HashMap<>();
      values.put(ResponseContent.USER_NAME, memberName != "" ? memberName: ResponseContent.USER);
      values.put(ResponseContent.ORDER_ID, notificationDTO.getOrderId() != null ? notificationDTO.getOrderId() : "");
      values.put(ResponseContent.TRACKING_LINK, notificationDTO.getTrackingLink() != null ? notificationDTO.getTrackingLink() : ResponseContent.YOUR_ORDERS);
      values.put(ResponseContent.DISCOUNT, notificationDTO.getDiscount() != null ? notificationDTO.getDiscount() : ResponseContent.DISCOUNT_UPPERCASE);
      values.put(ResponseContent.PROMO_CODE, notificationDTO.getPromoCode() != null ? notificationDTO.getPromoCode() :ResponseContent.NALAM );
      values.put(ResponseContent.ITEM_ID, notificationDTO.getItemId() != null ? notificationDTO.getItemId() : "");
      values.put(ResponseContent.BASKET_ID, notificationDTO.getBasketId() != null ? notificationDTO.getBasketId() : "");

      String resultTitle = TemplateEngine.replacePlaceholders(masterTemplate.getTitle(), values);
      String resultBody = TemplateEngine.replacePlaceholders(masterTemplate.getBody(), values);

      logger.info("Composed title: {}", resultTitle);
      logger.info("Composed body: {}", resultBody);
      List<MemberNotificationSettings> settingsList = memberNotificationSettingsRepo.findByMemberId(notificationDTO.getMemberId());

      for (MemberNotificationSettings setting : settingsList) {
        String channel = setting.getNotificationTypeId().getNotificationTypeName();
        ExecutorService executorService = Executors.newSingleThreadExecutor();

        executorService.submit(() -> {
          try {
            switch (channel) {
              case ResponseContent.EMAIL:
                sendEmail(resultTitle, resultBody, notificationDTO);

                break;
              case ResponseContent.PUSH:
                sendPushNotification(resultTitle, resultBody, notificationDTO,deviceToken);
                break;
              case ResponseContent.SMS:
                sendSMS(resultTitle, resultBody, notificationDTO);
                break;
              case ResponseContent.WHATS_APP:
                sendWhatsApp(resultTitle, resultBody, notificationDTO);
                break;
              default:
                logger.warn("Unknown notification channel: {}", channel);
            }
          } catch (Exception e) {
            logger.error("Error while sending {} notification for memberId {}: {}", channel, notificationDTO.getMemberId(), e.getMessage(), e);
          }
        });
      }
    } catch (Exception ex) {
      logger.error("Exception in sendNotification: {}", ex.getMessage(), ex);
    }
  }

	@Override
	public void __sendNotification(NotificationRequestDto notificationRequestDto) {
		try {
			logger.info("Received notification DTO: {}", notificationRequestDto.getNotification());

			NotificationDto notificationDTO = notificationRequestDto.getNotification();
			logger.info("Received notification DTO: {}", notificationDTO);

			MasterNotificationsTemplate masterTemplate = masterNotificationsTemplateRepo
					.findByType(notificationDTO.getNotificationType());
			if (masterTemplate == null) {
				logger.warn("No template found for notification type: {}", notificationDTO.getNotificationType());
				return;
			}
			MemberDetailsDto member = notificationRequestDto.getMember();

			logger.info("member details : {}", member);
			if (member == null) {
				throw new RuntimeException(ResponseContent.INVALID_MEMBER_EXCEPTION);
			}
			String memberName = member.getFirstname() != null ? member.getFirstname()
					: "".concat(member.getLastname() != null ? member.getLastname() : "");
			String deviceToken = member.getToken();
			Map<String, String> values = new HashMap<>();
			values.put(ResponseContent.USER_NAME, memberName != "" ? memberName : ResponseContent.USER);
			values.put(ResponseContent.ORDER_ID,
					notificationDTO.getOrderId() != null ? notificationDTO.getOrderId() : "");
			values.put(ResponseContent.TRACKING_LINK,
					notificationDTO.getTrackingLink() != null ? notificationDTO.getTrackingLink()
							: ResponseContent.YOUR_ORDERS);
			values.put(ResponseContent.DISCOUNT, notificationDTO.getDiscount() != null ? notificationDTO.getDiscount()
					: ResponseContent.DISCOUNT_UPPERCASE);
			values.put(ResponseContent.PROMO_CODE,
					notificationDTO.getPromoCode() != null ? notificationDTO.getPromoCode() : ResponseContent.NALAM);
			values.put(ResponseContent.ITEM_ID, notificationDTO.getItemId() != null ? notificationDTO.getItemId() : "");
			values.put(ResponseContent.BASKET_ID,
					notificationDTO.getBasketId() != null ? notificationDTO.getBasketId() : "");

			String resultTitle = TemplateEngine.replacePlaceholders(masterTemplate.getTitle(), values);
			String resultBody = TemplateEngine.replacePlaceholders(masterTemplate.getBody(), values);

			logger.info("Composed title: {}", resultTitle);
			logger.info("Composed body: {}", resultBody);
			List<MemberNotificationSettings> settingsList = memberNotificationSettingsRepo
					.findByMemberId(notificationDTO.getMemberId());

			for (MemberNotificationSettings setting : settingsList) {
				String channel = setting.getNotificationTypeId().getNotificationTypeName();
				ExecutorService executorService = Executors.newSingleThreadExecutor();

				executorService.submit(() -> {
					try {
						switch (channel) {
						case ResponseContent.EMAIL:
							sendEmail(resultTitle, resultBody, notificationDTO);
							break;
						case ResponseContent.PUSH:
							sendPushNotification(resultTitle, resultBody, notificationDTO, deviceToken);
							break;
						case ResponseContent.SMS:
							sendSMS(resultTitle, resultBody, notificationDTO);
							break; 
						case ResponseContent.WHATS_APP:
							sendWhatsApp(resultTitle, resultBody, notificationDTO);
							break;
						default:
							logger.warn("Unknown notification channel: {}", channel);
						}
					} catch (Exception e) {
						logger.error("Error while sending {} notification for memberId {}: {}", channel,
								notificationDTO.getMemberId(), e.getMessage(), e);
					}
				});
			}
		} catch (Exception ex) {
			logger.error("Exception in sendNotification: {}", ex.getMessage(), ex);
		}
	}




  public void sendPushNotification(String title, String body, NotificationDto dto , String deviceToken) throws Exception {
    logger.info("Sending Push Notification to token: {}", deviceToken);
    fcmPushNotification.sendPushNotification(deviceToken, title, body,dto);
  }

  public void sendWhatsApp(String title, String body, NotificationDto dto) {
	  sendWhatsAppNotification.sendWhatsApp(title,body,dto);
    logger.info("Sending WhatsApp message to: {}", dto.getMemberId());
    
    // WhatsApp sending logic here
  }

  public void sendEmail(String title, String body, NotificationDto dto) {
    logger.info("Sending Email to: {}", dto.getMemberId());
    // Email sending logic here
  }

  public void sendSMS(String title, String body, NotificationDto dto) {
    logger.info("Sending SMS to: {}", dto.getMemberId());
    // SMS sending logic here
  }

  @Override
  public void sendNotifications(OrderEventDto orderEventDto) {
    try {
      MasterNotificationsTemplate template = new MasterNotificationsTemplate();
      template.setType(ResponseContent.ORDER_CONFIRMATION);
      template.setTitle(ResponseContent.ORDER_CONFIRMATION_LOWERCASE);
      template.setBody(String.format(
        "Your order #%d has been confirmed. Total: $%.2f",
        orderEventDto.getOrderId(),
        orderEventDto.getSubTotal().subtract(orderEventDto.getDiscountAmount()).add(orderEventDto.getTaxAmount())
      ));
      template.setChannel(ResponseContent.EMAIL_UPPERCASE);
      template.setIsActive(true);
      template.setCreatedAt(LocalDateTime.now());
      template.setCreatedBy(orderEventDto.getMemberId());
      template.setModifiedAt(LocalDateTime.now());
      template.setModifiedBy(orderEventDto.getMemberId());

      masterNotificationsTemplateRepo.save(template);
      logger.info("Saved new order confirmation template for orderId: {}", orderEventDto.getOrderId());
    } catch (Exception ex) {
      logger.error("Error saving notification template: {}", ex.getMessage(), ex);
    }
  }

  public MemberDetailsDto getMemberDetails(Long memberId) {
    WebClient webClient = WebClient.create(userServiceUrl);
    return webClient.post()
      .uri(uriBuilder -> uriBuilder
        .path("/member/getMemberDetails")
        .queryParam("memberId", memberId)
        .build())
      .retrieve()
      .bodyToMono(MemberDetailsDto.class)
      .block(); // Blocking for simplicity (you can replace it with non-blocking if preferred)
  }


  public TxnNotificationResponse markNotificationAsRead(Long generalNotificationId) {
    try {
      Optional<TxnGeneralNotification> optionalNotification = txnGeneralNotificationRepo
        .findById(generalNotificationId);
      if (optionalNotification.isEmpty()) {
        return new TxnNotificationResponse(false, ResponseContent.NOTIFICATION_NOT_FOUND + generalNotificationId);
      }

      TxnGeneralNotification notification = optionalNotification.get();
      notification.setIsRead(true);
      notification.setReadAt(LocalDateTime.now());

      txnGeneralNotificationRepo.save(notification);

      return new TxnNotificationResponse(true, ResponseContent.NOTIFICATION_READ);

    } catch (Exception e) {
      e.printStackTrace();
      return new TxnNotificationResponse(false, ResponseContent.NOTIFICATION_UPDATE_ERRORMESSAGE + e.getMessage());
    }
  }

  public NotificationSummaryResponse getTxnGeneralNotification(Long toMemberId) {
    try {
      List<TxnGeneralNotification> notifications = txnGeneralNotificationRepo.findByToMemberId(toMemberId);

      int readCount = (int) notifications.stream().filter(TxnGeneralNotification::getIsRead).count();
      int unreadCount = notifications.size() - readCount;

      return new NotificationSummaryResponse(notifications, readCount, unreadCount);
    } catch (Exception e) {
      e.printStackTrace();
      return new NotificationSummaryResponse(Collections.emptyList(), 0, 0);
    }
  }

}
