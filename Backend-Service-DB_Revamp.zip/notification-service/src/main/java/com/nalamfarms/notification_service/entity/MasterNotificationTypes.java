package com.nalamfarms.notification_service.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "master_notification_types")
public class MasterNotificationTypes {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "notification_types_id")
  private Long notificationTypesId;

  @Column(name = "notification_type_name")
  private String notificationTypeName;

  @Column(name = "description")
  private String description;

  @Column(name = "is_active")
  private Boolean isActive;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @Column(name = "modified_at")
  private LocalDateTime modifiedAt;


}
