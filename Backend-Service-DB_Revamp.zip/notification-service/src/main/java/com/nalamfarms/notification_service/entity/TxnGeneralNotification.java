package com.nalamfarms.notification_service.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name="notification_txn_general_notification")
@Data
public class TxnGeneralNotification {
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "general_notification_id")
	  private Long generalNotificationId; 
	  
	  @Column(name="notification_type_id")
	  private Long notificationTypeId;
	
	  @Column(name="item_id")
	  private Long itemId;
	  
	  @Column(name="basket_id")
	  private Long basketId;
	  
	  @Column(name="from_member_id")
	  private Long fromMemberId; 
	  
	  @Column(name="to_member_id")
	  private Long toMemberId;
	  
	  @Column(name="message")
	  private String message;
	 
	  @Column(name = "is_active")
	  private Boolean isActive;

	  @Column(name = "created_at")
	  private LocalDateTime createdAt;

	  @Column(name = "modified_at")
	  private LocalDateTime modifiedAt;

	  @Column(name = "created_by")
	  private Long createdBy;

	  @Column(name = "modified_by")
	  private Long modifiedBy;
	  
	  @Column(name = "is_read")
	  private Boolean isRead;

	  @Column(name = "read_at")
	  private LocalDateTime readAt;
	  
	  @Column(name="title")
	  private String title;
}
