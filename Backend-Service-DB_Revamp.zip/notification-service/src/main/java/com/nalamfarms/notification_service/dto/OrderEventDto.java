package com.nalamfarms.notification_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OrderEventDto {
    @JsonProperty("orderId")
    private Long orderId;

    @JsonProperty("memberId")
    private Long memberId;

    @JsonProperty("subTotal")
    private BigDecimal subTotal;

    @JsonProperty("discountAmount")
    private BigDecimal discountAmount;

    @JsonProperty("taxAmount")
    private BigDecimal taxAmount;

    @JsonProperty("grandTotal")
    private BigDecimal grandTotal;

    @JsonProperty("status")
    private String status;

    @JsonProperty("paymentStatus")
    private String paymentStatus;

    @JsonProperty("paymentMethod")
    private String paymentMethod;

    @JsonProperty("deliveryCharge")
    private BigDecimal deliveryCharge;

    @JsonProperty("surCharge")
    private BigDecimal surCharge;

    @JsonProperty("customerOrderId")
    private String customerOrderId;
    
    @JsonProperty("eventStatus")
    private String eventStatus;

    @JsonProperty("items")
    private List<OrderItemDto> items;
}
