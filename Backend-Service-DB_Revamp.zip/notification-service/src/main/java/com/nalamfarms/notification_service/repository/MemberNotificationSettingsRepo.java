package com.nalamfarms.notification_service.repository;


import com.nalamfarms.notification_service.entity.MemberNotificationSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberNotificationSettingsRepo extends JpaRepository<MemberNotificationSettings,Long> {

  List<MemberNotificationSettings> findByMemberId(Long memberId);
}
