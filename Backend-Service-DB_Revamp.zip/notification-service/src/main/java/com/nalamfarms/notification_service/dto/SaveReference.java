package com.nalamfarms.notification_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveReference {
    private Long notificationTypeId;
    private Long itemId;
    private Long basketId;
    private Long fromMemberId;
    private Long toMemberId;
    private String message;
    private String toPhoneNumber;  
}
