package com.nalamfarms.notification_service.controller;

import com.nalamfarms.notification_service.dto.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.notification_service.service.NotificationService;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/notification")
public class NotificationController {


	private final NotificationService notificationService;

//    @PostMapping("/sendNotification")
//    public void SendNotficiation(@RequestBody NotificationDTO notificationDTO)
//    {
//       notificationService.sendNotification(notificationDTO);
//	}

	@PostMapping("/sendNotification")
	public void SendNotficiation(@RequestBody NotificationRequestDto notificationDTO) {
		// System.out.println("notification-->noti"+notificationDTO.getNotification().getOrderId());
		notificationService.__sendNotification(notificationDTO);
	}


  @MutationMapping
	public TxnNotificationResponse markNotificationAsRead(@Argument Long generalNotificationId) {
		return notificationService.markNotificationAsRead(generalNotificationId);
	}

	@QueryMapping
	public NotificationSummaryResponse getTxnGeneralNotification(@Argument Long toMemberId) {
	    return notificationService.getTxnGeneralNotification(toMemberId);
	}


}
