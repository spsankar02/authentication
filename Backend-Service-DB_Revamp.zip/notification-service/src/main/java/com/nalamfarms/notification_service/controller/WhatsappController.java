package com.nalamfarms.notification_service.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.notification_service.dto.SendMessageRequest;
import com.nalamfarms.notification_service.dto.SendMessageResponse;
import com.nalamfarms.notification_service.service.GreenApiClient;

import lombok.AllArgsConstructor;
import reactor.core.publisher.Mono;


@RestController
@RequestMapping("/api/whatsapp")
@AllArgsConstructor
public class WhatsappController {

    private final GreenApiClient client;

    @PostMapping("/sendSync")
    public ResponseEntity<SendMessageResponse> sendSync(@RequestBody SendMessageRequest req) {
        String phoneNumber = req.getPhoneNumber()
                .replaceAll("\\D+", "");

        // Remove leading 91 if present
        if (phoneNumber.startsWith("91") && phoneNumber.length() > 10) {
            phoneNumber = phoneNumber.substring(2);
        }

        String chatId = phoneNumber + "@c.us";

        // Response placeholder
        SendMessageResponse[] responseHolder = new SendMessageResponse[1];

        // Run inside a separate thread
        Thread thread = new Thread(() -> {
            try {
                String id = client.sendMessage(chatId, req.getMessage()).block(); // blocking call inside thread
                responseHolder[0] = new SendMessageResponse(true, id, null);
            } catch (Exception ex) {
                responseHolder[0] = new SendMessageResponse(false, null, ex.getMessage());
            }
        });

        thread.start();
        try {
            thread.join(); // wait for thread to finish
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return ResponseEntity.internalServerError()
                    .body(new SendMessageResponse(false, null, "Thread interrupted"));
        }

        return ResponseEntity.ok(responseHolder[0]);
    }

}