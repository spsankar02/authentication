package com.nalamfarms.notification_service.entity;

import jakarta.persistence.*;
import lombok.Data;


@Data
@Entity
@Table(name = "member_mapping_notification_settings")
public class MemberNotificationSettings {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "member_notification_settings_id")
  private Long memberNotificationSettingsId;

  @Column(name = "member_id")
  private Long memberId;

  @ManyToOne
  @JoinColumn(name = "notification_type_id")
  private MasterNotificationTypes notificationTypeId;

  @Column(name = "setting_name")
  private String settingName;

  @Column(name = "is_active")
  private Boolean isActive;

  @Column(name = "setting_value")
  private Boolean settingValue;


}
