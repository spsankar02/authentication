package com.nalamfarms.notification_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;


@Data
@RequiredArgsConstructor
public class NotificationRequestDto {
  private NotificationDto notification;
  private MemberDetailsDto member;


}
