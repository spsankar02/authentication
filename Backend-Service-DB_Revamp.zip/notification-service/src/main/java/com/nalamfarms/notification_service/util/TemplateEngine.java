package com.nalamfarms.notification_service.util;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class TemplateEngine {

  public static String replacePlaceholders(String template, Map<String, String> values) {
    Pattern pattern = Pattern.compile("\\{\\{(.+?)\\}\\}");
    Matcher matcher = pattern.matcher(template);
    StringBuffer buffer = new StringBuffer();

    while (matcher.find()) {
      String key = matcher.group(1); // e.g., user_name
      String replacement = values.getOrDefault(key, ""); // or keep it as-is if not found
      matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement));
    }
    matcher.appendTail(buffer);
    return buffer.toString();
  }
}
