package com.nalamfarms.notification_service.exception;

import java.util.List;

import org.springframework.graphql.execution.DataFetcherExceptionResolver;
import org.springframework.stereotype.Component;


import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;
import reactor.core.publisher.Mono;

@Component
public class CustomGraphQLExceptionResolver implements DataFetcherExceptionResolver {

    @Override
    public Mono<List<GraphQLError>> resolveException(Throwable exception, DataFetchingEnvironment env) {
        AuditLoggerUtil.log(exception);

        return Mono.just(List.of(
            GraphqlErrorBuilder.newError(env)
                .message(
                    exception instanceof IllegalArgumentException
                    ? exception.getMessage()
                    : "Unexpected error occurred"
                )
                .build()
        ));
    }
}
