package com.nalamfarms.notification_service.dto;

import java.util.List;

import com.nalamfarms.notification_service.entity.TxnGeneralNotification;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class NotificationSummaryResponse {
	private List<TxnGeneralNotification> notifications;
	private int readCount;
	private int unreadCount;
}
