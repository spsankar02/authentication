package com.nalamfarms.notification_service.service;

import java.util.concurrent.CompletableFuture;

import com.nalamfarms.notification_service.dto.OrderEventDto;
import com.nalamfarms.notification_service.dto.OrderHistoryEventDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import com.nalamfarms.notification_service.util.ResponseContent;


@Service
public class NotificationProducer {

  private static final Logger logger = LoggerFactory.getLogger(NotificationProducer.class);
  private final KafkaTemplate<String, Object> kafkaTemplate;
  private final KafkaTopicVerifier topicVerifier;

  public NotificationProducer(KafkaTemplate<String, Object> kafkaTemplate, KafkaTopicVerifier topicVerifier) {
    this.kafkaTemplate = kafkaTemplate;
    this.topicVerifier = topicVerifier;
  }

  public boolean sendNotificationSend(OrderEventDto orderEvent) {
    String topic  = ResponseContent.NOTIFICATION_SEND;
    if (!topicVerifier.doesTopicExist(topic)) {
      logger.error("Topic {} does not exist!", topic);
      return false;
    }
    try {
      CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, orderEvent.getOrderId().toString(), orderEvent);
      future.whenComplete(
        (result, ex) -> {
          if (ex == null) {
            logger.info("Published notification send event to topic {}: orderId={}", topic, orderEvent.getOrderId());
          } else {
            logger.error("Failed to send message to topic {}: {}", topic, ex.getMessage(), ex);
          }
        }
      );
      return true;
    } catch (Exception e) {
      logger.error("Failed to send message to topic {}: {}", topic, e.getMessage(), e);
      return false;
    }
  }

public boolean sendOrderAuditEvent(String topic, OrderHistoryEventDto orderEventAudit) {
		if (!topicVerifier.doesTopicExist(topic)) {
			logger.error("Topic {} does not exist!", topic);
			return false;
		}

		try {
			CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic,
					orderEventAudit.getOrderId().toString(), orderEventAudit);

			future.whenComplete((result, ex) -> {
				if (ex == null) {
					logger.info("✅ Successfully published audit event to topic '{}': orderId={}, event={}", topic,
							orderEventAudit.getOrderId(), orderEventAudit.getEventName());
				} else {
					logger.error("❌ Failed to publish audit event to topic '{}': {}", topic, ex.getMessage(), ex);
				}
			});

			return true;

		} catch (Exception e) {
			logger.error("❌ Exception while publishing audit event to topic '{}': {}", topic, e.getMessage(), e);
			return false;
		}
	}
}
