package com.nalamfarms.notification_service.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;

@Service
public class GreenApiClient {

    private final WebClient webClient;

    //@Value("${greenapi.instance-id}")
    private String instanceId;

    //@Value("${greenapi.api-token}")
    private String apiToken;

    public GreenApiClient(WebClient.Builder builder) {
        this.webClient = builder.baseUrl("https://api.green-api.com").build();
    }

    public Mono<String> sendMessage(String chatId, String message) {
       // String chatId = phoneNumber.replace("+", "").replaceAll("\\s+", "") + "@c.us";

        return webClient.post()
                .uri("/waInstance" + instanceId + "/sendMessage/" + apiToken)
                .bodyValue(Map.of(
                        "chatId", chatId,
                        "message", message
                ))
                .retrieve()
                .bodyToMono(Map.class)
                .map(resp -> (String) resp.get("idMessage"));
    }
}