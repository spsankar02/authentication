package com.nalamfarms.notification_service.dto;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "greenapi")
public class GreenApiProperties {
    private String baseUrl;
    private String instanceId;
    private String token;
    private boolean pollingEnabled;
    private long pollingDelayMs;
}