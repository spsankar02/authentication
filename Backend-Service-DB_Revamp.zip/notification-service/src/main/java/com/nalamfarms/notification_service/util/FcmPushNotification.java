package com.nalamfarms.notification_service.util;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.gson.Gson;
import com.nalamfarms.notification_service.dto.NotificationDto;
import org.json.JSONObject;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;

@Component
public class FcmPushNotification {
  private static final String PROJECT_ID = "nalam-bd96c";  // Replace
  private static final String FCM_ENDPOINT = "https://fcm.googleapis.com/v1/projects/" + PROJECT_ID + "/messages:send";
  ClassPathResource resource = new ClassPathResource("nalam-bd96c-eeb08ea25399.json");


  public void sendPushNotification(String deviceToken, String title, String body, NotificationDto dto) throws Exception{
    try {
      String FCM_TOKEN = deviceToken;
      String BODY_CONTENT = body;
      // Load service account and get access token
      InputStream serviceAccount = resource.getInputStream();
      GoogleCredentials credentials = GoogleCredentials.fromStream(serviceAccount)
        .createScoped(Collections.singleton("https://www.googleapis.com/auth/firebase.messaging"));
      credentials.refreshIfExpired();
      String accessToken = credentials.getAccessToken().getTokenValue();

      // Construct the JSON payload
      JSONObject message = new JSONObject();

      JSONObject message_body = new JSONObject();
      message_body.put("title",title);

      message_body.put("body", BODY_CONTENT);
      message_body.put("memberId",dto.getMemberId()!= null?dto.getMemberId():"");
      message_body.put("orderId",dto.getOrderId()!= null?dto.getOrderId():"");
      message_body.put("notificationType",dto.getNotificationType()!= null?dto.getNotificationType():"");
      message_body.put("promoCode",dto.getPromoCode()!= null?dto.getPromoCode():"");
      message_body.put("itemId",dto.getItemId()!= null?dto.getItemId():"");
      message_body.put("basketId",dto.getBasketId()!= null?dto.getBasketId():"");

      JSONObject notification = new JSONObject();
      notification.put("title",title);
      Gson gson = new Gson();
      notification.put("body", gson.toJson(message_body));
      message.put("token", FCM_TOKEN);
      message.put("data", notification);
      System.out.println(message.toString()+FCM_TOKEN+"hi");


//      message.put("data", notification);


      JSONObject android = new JSONObject();
      android.put("priority", "high");
      message.put("android", android);

      JSONObject aps = new JSONObject();
      aps.put("content-available", 1);

      JSONObject payload = new JSONObject();
      payload.put("aps", aps);

      JSONObject headers = new JSONObject();
      headers.put("apns-priority", "10");

      JSONObject apns = new JSONObject();
      apns.put("payload", payload);
      apns.put("headers", headers);
      message.put("apns", apns);

      JSONObject requestBody = new JSONObject();
      requestBody.put("message", message);

      System.out.println("payload"+requestBody.toString());

      // Send HTTP POST request
      URL url = new URL(FCM_ENDPOINT);
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      conn.setRequestMethod("POST");
      conn.setRequestProperty("Authorization", "Bearer " + accessToken);
      conn.setRequestProperty("Content-Type", "application/json; UTF-8");
      conn.setDoOutput(true);

      OutputStream os = conn.getOutputStream();
      os.write(requestBody.toString().getBytes("UTF-8"));
      os.flush();
      os.close();

      int responseCode = conn.getResponseCode();
      System.out.println("Response Code: " + responseCode);

      if (responseCode == 200) {
        System.out.println("✅ Reminder sent successfully!");
      } else {
        System.out.println("❌ Failed: " + conn.getResponseMessage());
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}



//
//import jakarta.annotation.PostConstruct;
//import lombok.RequiredArgsConstructor;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.nio.charset.StandardCharsets;
//
//@Component
//@RequiredArgsConstructor
//public class FcmPushNotification {
//
//  @Value("${fcm.server-key}")
//  private String serverKey;
//
//  @Value("${fcm.api-url}")
//  private String fcmApiUrl;
//
//  private static String SERVER_KEY;
//  private static String FCM_API_URL;
//
//  @PostConstruct
//  private void init() {
//    SERVER_KEY = serverKey;
//    FCM_API_URL = fcmApiUrl;
//  }
//
//  public static void sendPushNotification(String deviceToken, String title, String body) throws Exception {
//    // Prepare JSON payload
//    String payload = "{"
//      + "\"to\":\"" + deviceToken + "\","
//      + "\"notification\":{"
//      + "\"title\":\"" + title + "\","
//      + "\"body\":\"" + body + "\""
//      + "},"
//      + "\"priority\":\"high\""
//      + "}";
//
//    // Setup connection
//    URL url = new URL(FCM_API_URL);
//    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//    conn.setUseCaches(false);
//    conn.setDoOutput(true);
//    conn.setRequestMethod("POST");
//    conn.setRequestProperty("Authorization", "key=" + SERVER_KEY);
//    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
//
//    // Send payload
//    try (OutputStream outputStream = conn.getOutputStream()) {
//      outputStream.write(payload.getBytes(StandardCharsets.UTF_8));
//    }
//
//    // Read response
//    int responseCode = conn.getResponseCode();
//    System.out.println("FCM Response Code: " + responseCode);
//
//    BufferedReader in = new BufferedReader(new InputStreamReader(
//      responseCode == 200 ? conn.getInputStream() : conn.getErrorStream()
//    ));
//
//    String inputLine;
//    StringBuilder response = new StringBuilder();
//    while ((inputLine = in.readLine()) != null) {
//      response.append(inputLine);
//    }
//    in.close();
//
//    System.out.println("FCM Response Body: " + response.toString());
//
//    conn.disconnect();
//  }
//}
