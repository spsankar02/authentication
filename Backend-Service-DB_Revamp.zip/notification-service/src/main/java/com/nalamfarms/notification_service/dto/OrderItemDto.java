package com.nalamfarms.notification_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OrderItemDto {
  @JsonProperty("itemId")
  private Long itemId;

  @JsonProperty("basketId")
  private Long basketId;

  @JsonProperty("quantity")
  private Integer quantity;

  @JsonProperty("pricePerUnit")
  private BigDecimal pricePerUnit;

  @JsonProperty("discountPerUnit")
  private BigDecimal discountPerUnit;

  @JsonProperty("totalPrice")
  private BigDecimal totalPrice;

  @JsonProperty("type")
  private String type;

  @JsonProperty("variantTypeId")
  private Long variantTypeId;

  @JsonProperty("productId")
  private Long productId;

  @JsonProperty("dealPrice")
  private BigDecimal dealPrice;

  @JsonProperty("dealDiscount")
  private BigDecimal dealDiscount;


}
