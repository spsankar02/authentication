package com.nalamfarms.notification_service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.notification_service.entity.TxnGeneralNotification;

@Repository
public interface TxnGeneralNotificationRepository extends JpaRepository<TxnGeneralNotification, Long> {
	Optional<TxnGeneralNotification> findById(Long id);
	List<TxnGeneralNotification> findByToMemberId(Long toMemberId);
}
