package com.nalamfarms.notification_service.aop;

import java.time.Instant;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger auditLogger = LoggerFactory.getLogger("AUDIT_LOGGER");

    @Pointcut("execution(* com.nalamfarms.notification_service.serviceimpl..*(..))")
    public void allServiceMethods() {}

    @Around("allServiceMethods()")
    public Object logMethodDetails(ProceedingJoinPoint joinPoint) throws Throwable {
        Instant startTime = Instant.now();
        long startMillis = System.currentTimeMillis();

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        String className = signature.getDeclaringTypeName();
        String methodName = signature.getName();
        String simpleClassName = signature.getDeclaringType().getSimpleName();
        Class<?> returnType = signature.getReturnType();
        String[] paramNames = signature.getParameterNames();
        Object[] args = joinPoint.getArgs();

        StringBuilder argsBuilder = new StringBuilder();
        for (int i = 0; i < paramNames.length; i++) {
            argsBuilder.append(paramNames[i])
                       .append("=")
                       .append(args[i]);
            if (i < paramNames.length - 1) {
                argsBuilder.append(", ");
            }
        }

        // No Spring Security
        String username = "n/a";

        // Example: get trace IDs if using Sleuth/Micrometer
        String traceId = org.slf4j.MDC.get("traceId");
        String spanId = org.slf4j.MDC.get("spanId");

        auditLogger.info("START | {} | {}.{}() | Args: [{}] | ReturnType: {} | User: {} | TraceId: {} | SpanId: {} | Thread: {}",
                startTime, className, methodName, argsBuilder, returnType.getSimpleName(), username, traceId, spanId,
                Thread.currentThread().getName());

        Object result;
        try {
            result = joinPoint.proceed();
            long duration = System.currentTimeMillis() - startMillis;

            auditLogger.info("SUCCESS | {} | {}.{}() | Result: {} | Duration: {} ms",
                    Instant.now(), className, methodName, result, duration);

            return result;
        } catch (Throwable ex) {
            long duration = System.currentTimeMillis() - startMillis;

            auditLogger.error("ERROR | {} | {}.{}() | Exception: {} | Duration: {} ms",
                    Instant.now(), className, methodName, ex, duration);

            throw ex;
        }
    }
}