package com.nalamfarms.notification_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Data
public class MemberDetailsDto {

  private Long memberId;
  private String firstname;
  private String lastname;
  private String emailAddress;
  private Boolean isActive;
  private String token;

}
