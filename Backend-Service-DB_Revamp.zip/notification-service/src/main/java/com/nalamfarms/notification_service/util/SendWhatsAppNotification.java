package com.nalamfarms.notification_service.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nalamfarms.notification_service.dto.NotificationDto;
import com.nalamfarms.notification_service.service.GreenApiClient;

import reactor.core.publisher.Mono;
@Component
public class SendWhatsAppNotification {
	@Autowired
    private  GreenApiClient greenApiClient;

	private static final Logger logger = LoggerFactory.getLogger(SendWhatsAppNotification.class);

	public void sendWhatsApp(String title, String body, NotificationDto dto) {
	    try {
	        // Construct the full message
	        StringBuilder message = new StringBuilder();
	        message.append(title).append("\n");
	        message.append(body).append("\n\n");

	        if (dto.getMemberId() != null) message.append("MemberId: ").append(dto.getMemberId()).append("\n");
	        if (dto.getOrderId() != null) message.append("OrderId: ").append(dto.getOrderId()).append("\n");
	        if (dto.getTrackingLink() != null) message.append("Tracking: ").append(dto.getTrackingLink()).append("\n");
	        if (dto.getDiscount() != null) message.append("Discount: ").append(dto.getDiscount()).append("\n");
	        if (dto.getPromoCode() != null) message.append("PromoCode: ").append(dto.getPromoCode()).append("\n");
	        if (dto.getItemId() != null) message.append("ItemId: ").append(dto.getItemId()).append("\n");
	        if (dto.getBasketId() != null) message.append("BasketId: ").append(dto.getBasketId()).append("\n");
	        if (dto.getReferredMemberId() != null) message.append("ReferredMemberId: ").append(dto.getReferredMemberId()).append("\n");

	        // Get the WhatsApp number from dto (or member object if available)
	        String phoneNumber = dto.getPhoneNumber();
	        if (phoneNumber == null) {
	            logger.warn("No phone number found for member, skipping WhatsApp notification");
	            return;
	        }

	        // Convert phone number to GreenAPI chatId format
	        String chatId = phoneNumber.replace("+91", "")  // Remove country code if required
	                                   .replaceAll("\\s+", "") + "@c.us";
	        
	            String id = greenApiClient.sendMessage(chatId, message.toString()).block(); // blocks and waits for result
	            if (id != null) {
	                logger.info("✅ WhatsApp message sent successfully, id: {}", id);
	            } else {
	                logger.warn("❌ Failed to send WhatsApp message to {}", chatId);
	            }
	        
	    }catch (Exception e) {
	            logger.error("Error sending WhatsApp message: {}", e.getMessage(), e);
	        }

	    }
	}

