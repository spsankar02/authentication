package com.nalamfarms.notification_service.service;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.nalamfarms.notification_service.dto.OrderEventDto;
import com.nalamfarms.notification_service.dto.OrderHistoryEventDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;


@Component
public class NotificationConsumer {

  private static final Logger logger = LoggerFactory.getLogger(NotificationConsumer.class);
  private final NotificationService notificationService;
  private final NotificationProducer notificationProducer;
  private final ObjectMapper objectMapper;


  public NotificationConsumer(NotificationService notificationService, NotificationProducer notificationProducer, ObjectMapper objectMapper) {
    this.notificationService = notificationService;
    this.notificationProducer = notificationProducer;
    this.objectMapper = objectMapper;
    
  }
//
//  @KafkaListener(topics = "payment.initiated", groupId = "notification-service-group")
//  public void consumeNotificationSend(OrderEventDto orderEventDto) {
//    logger.info("Consumed message from notification.send: {}", orderEventDto);
//    try {
//      notificationService.sendNotification(orderEventDto);
//      logger.info("Notification sent for orderId: {}", orderEventDto.getOrderId());
//
//      boolean sent = notificationProducer.sendOrderStatusUpdated("payment.initiated",orderEventDto);
//      if (sent) {
//        logger.info("Successfully sent order.status.updated event for orderId: {}", orderEventDto.getOrderId());
//      } else {
//        logger.error("Failed to send order.status.updated event for orderId: {}", orderEventDto.getOrderId());
//      }
//    } catch (Exception e) {
//      logger.error("Failed to process notification.send for orderId: {}", orderEventDto != null ? orderEventDto.getOrderId() : "unknown", e);
//      throw new RuntimeException("Failed to process notification.send message", e);
//    }

  @KafkaListener(topics = "payment.initiated", groupId = "notification-service-group")
  public void consumeInventoryUpdated(String message) {
      logger.info("Received message from payment.initiated: {}", message);

      OrderEventDto orderEventDto = null;
      boolean auditResult = true;
      String errorMessage=null;
      try {
          logger.debug("Attempting to parse message to OrderEventDto");
          String json = message.replaceFirst("^payment.initiated for order: ", "");
          orderEventDto = objectMapper.readValue(json, OrderEventDto.class);
          logger.info("Parsed OrderEventDto: orderId={}", orderEventDto.getOrderId());

          logger.debug("Updating notification for orderId: {}", orderEventDto.getOrderId());
          // notificationService.sendNotifications(orderEventDto);
          logger.info("Notification initiated for orderId: {}", orderEventDto.getOrderId());

      } catch (Exception ex) {
          auditResult = false;
          logger.error("Exception occurred while processing payment.initiated message: {}", message, ex);
          StringWriter sw = new StringWriter();
          ex.printStackTrace(new PrintWriter(sw));
          String fullStackTrace = sw.toString();
          errorMessage=fullStackTrace;

      }

      // Only proceed with events if parsing succeeded
      if (orderEventDto != null) {
          OrderHistoryEventDto auditEvent = new OrderHistoryEventDto();
          auditEvent.setOrderId(orderEventDto.getOrderId());
          auditEvent.setPayload(orderEventDto.toString());
          auditEvent.setEventName("payment.initiated");
          auditEvent.setTriggeredBy("inventory.updated");
          auditEvent.setStatus(auditResult);
          auditEvent.setErrorMessage(errorMessage);
          auditEvent.setCustomOrderId(orderEventDto.getCustomerOrderId());

          try {
              boolean auditSent = notificationProducer.sendOrderAuditEvent("event.audit", auditEvent);
              if (auditSent) {
                  logger.info("Audit event sent successfully for orderId={}", auditEvent.getOrderId());
              } else {
                  logger.error("Failed to send audit event for orderId={}", auditEvent.getOrderId());
              }
          } catch (Exception e) {
              logger.error("Failed to send audit event for orderId={}", orderEventDto.getOrderId(), e);
          }

          try {
              boolean sent = notificationProducer.sendNotificationSend(orderEventDto);
              if (sent) {
                  logger.info("Successfully sent notification event for orderId: {}", orderEventDto.getOrderId());
              } else {
                  logger.error("Failed to send notification event for orderId: {}", orderEventDto.getOrderId());
              }
          } catch (Exception e) {
              logger.error("Exception while sending notification event for orderId: {}", orderEventDto.getOrderId(), e);
          }

      } else {
          logger.warn("Skipping audit and notification event sending — orderEventDto is null");
      }
  }
  
  
	@KafkaListener(topics = "notification.send", groupId = "notification-service-group")
	public void consumeOrderStatusUpdated(String message) {
		logger.info("Received message from notification.send: {}", message);

		OrderEventDto orderEventDto = null;
		boolean auditResult = true;
		boolean kafkaSendSuccess = false;
		String errorMessage = null;
		try {
			// Parse the JSON from the message
			String json = message.replaceFirst("^notification send for order: ", "");
			orderEventDto = objectMapper.readValue(json, OrderEventDto.class);
			logger.info("Parsed OrderEventDto: orderId={}", orderEventDto.getOrderId());

			logger.info("Order status updated for orderId={}", orderEventDto.getOrderId());

			System.out.println("📩 Sending notification to memberId=" + orderEventDto.getMemberId() + " for orderId="
					+ orderEventDto.getOrderId());

		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Error processing notification.send message: {}", message, ex);
			auditResult = false;
			StringWriter sw = new StringWriter();
			ex.printStackTrace(new PrintWriter(sw));
			String fullStackTrace = sw.toString();
			errorMessage = fullStackTrace;

		}

		if (orderEventDto != null) {
			OrderHistoryEventDto auditEvent = new OrderHistoryEventDto();
			auditEvent.setOrderId(orderEventDto.getOrderId());
			auditEvent.setPayload(orderEventDto.toString());
			auditEvent.setEventName("notification.send");
			auditEvent.setTriggeredBy(orderEventDto.getEventStatus());
			auditEvent.setStatus(auditResult);
			auditEvent.setErrorMessage(errorMessage);
			auditEvent.setCustomOrderId(orderEventDto.getCustomerOrderId());

			try {
				boolean auditSent = notificationProducer.sendOrderAuditEvent("event.audit", auditEvent);
				if (auditSent) {
					logger.info("Audit event sent successfully for orderId={}", auditEvent.getOrderId());
				} else {
					logger.error("Failed to send audit event for orderId={}", auditEvent.getOrderId());
				}
			} catch (Exception auditEx) {
				logger.error("Failed to send audit event for orderId={}, reason: {}", orderEventDto.getOrderId(),
						auditEx.getMessage(), auditEx);
			}
		} else {
			logger.warn("Skipping audit event; orderEventDto is null");
		}

}
}


