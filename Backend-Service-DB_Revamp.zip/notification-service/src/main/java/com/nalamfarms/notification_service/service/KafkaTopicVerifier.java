package com.nalamfarms.notification_service.service;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.concurrent.ExecutionException;

@Component
public class KafkaTopicVerifier {

  private static final Logger logger = LoggerFactory.getLogger(KafkaTopicVerifier.class);
  private final AdminClient adminClient;

  public KafkaTopicVerifier(AdminClient adminClient) {
    this.adminClient = adminClient;
  }

  public boolean doesTopicExist(String topic) {
    try {
      ListTopicsResult topicsResult = adminClient.listTopics();
      Set<String> topics = topicsResult.names().get();
      boolean exists = topics.contains(topic);
      logger.info("Topic {} exists: {}", topic, exists);
      return exists;
    } catch (InterruptedException | ExecutionException e) {
      logger.error("Failed to verify topic {}: {}", topic, e.getMessage(), e);
      return false;
    }
  }
}
