Backend-Service
Backend-Service repository
1.api-gateway : 8080
2.cart-service:8001
3.discovery-service:8761
4.inventory-service:53748
5.logistic-service:8003
6.notification-service:8010
7.order-service:8004
8.payment-service:8005
9.product-service: 8006
10.user-behaviour-service:8007
11.user-service:8000
12.Orchestrator-service:8002
13.ElasticSearch: 9200
14.Zookeeper:2181
15.Kafka:9092

################################### Installation Elastic Search In Ubuntu #########################################
sudo apt update
sudo apt install openjdk-17-jdk -y
curl -fsSL https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo gpg --dearmor -o /usr/share/keyrings/elasticsearch-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/elasticsearch-keyring.gpg] https://artifacts.elastic.co/packages/8.x/apt stable main" | sudo tee /etc/apt/sources.list.d/elastic-8.x.list
sudo apt update
sudo apt install elasticsearch -y

sudo systemctl enable elasticsearch
sudo systemctl start elasticsearch

sudo systemctl status elasticsearch

Edit Configuration
sudo nano /etc/elasticsearch/elasticsearch.yml

SECURITY
Enable security features
xpack.security.enabled: true
xpack.security.enrollment.enabled: true

LOG
sudo tail -n 50 /var/log/elasticsearch/elasticsearch.log

From your app server, try:

curl -v http://localhost:9200

or if SSL is enabled:

curl -vk https://localhost:9200

################################### KAFKA #########################################
Installation KafkaIn Ubuntu
wget https://downloads.apache.org/kafka/3.8.0/kafka_2.13-3.8.0.tgz
tar -xvzf kafka_2.13-3.8.0.tgz
sudo mv kafka_2.13-3.8.0 /opt/kafka
cd /opt/kafka

RUN KAFKA IN BACKGROUND - Zookeeper 768160 Server 769039
nohup /opt/kafka/bin/zookeeper-server-start.sh /opt/kafka/config/zookeeper.properties > /opt/kafka/zookeeper.log 2>&1 &
nohup /opt/kafka/bin/kafka-server-start.sh /opt/kafka/config/server.properties > /opt/kafka/kafka.log 2>&1 &

STOP KAFKA
./bin/kafka-server-stop.sh

CHECK RUN
ps aux | grep kafka.Kafka
ps aux | grep zookeeper

KAFKA Restart
pkill -f kafka.Kafka

Kafka's Data Directory
dataDir=/opt/kafka/logs/zookeeper
log.dirs=/opt/kafka/logs/server

Kafka log ## "KafkaServer started"
tail /opt/kafka/kafka.log
tail -n 50 /opt/kafka/kafka.log

Topic test
/opt/kafka/bin/kafka-topics.sh --list --bootstrap-server localhost:9092

Topics
event.audit
inventory.reserved
inventory.updated
logistics.created
notification.send
order.cancelled
order.confirmed
order.created
order.status.updated
payment.initiated
payment.status.updated
refund.initiated
shipment.created