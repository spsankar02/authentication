package com.nalamfarms.api_gateway.websecurity.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.nalamfarms.api_gateway.dto.MemberDetails;
import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {


    @Value("${api.auth-service}")
    private String authService;

    @Value("${api.auth-service-path}")
    private String authServiceContextPath;

    public List<String> openAPIEndPoints;

    public AuthenticationFilter() {
        super(Config.class);
       // System.out.println("Auth Service URL Constructor: " + authService);
    }

    @PostConstruct
    public void init() {
        //System.out.println("Auth Service URL after init: " + authService); // Should print the correct value
        openAPIEndPoints = List.of(authServiceContextPath+"/auth/validatetoken",authServiceContextPath+"/api/authsession","/eureka/web");
    }

    @Autowired
    WebClient webclient;

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {


            String path = exchange.getRequest().getURI().getPath();

            if (openAPIEndPoints.contains(path)) {

                return chain.filter(exchange); // Continue processing without token validation

            }else {
                HttpHeaders headers = exchange.getRequest().getHeaders();
                String token = headers.getFirst(HttpHeaders.AUTHORIZATION);

                // Token Validation Comes Here
                if (token == null || !token.startsWith("Bearer ")) {
                    // Token Validation Comes Here
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }


                System.out.println("----> TOKEN" + token);

                Map<String, Object> requestBodyMap = new HashMap<>();
                requestBodyMap.put("deviceToken", token.replace("Bearer ", ""));

                ObjectMapper mapper = new ObjectMapper();
                String requestBody ="";
                try {
                    requestBody =  mapper.writeValueAsString(requestBodyMap);
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }

                // Validate token logic here using reactive programming
                return webclient.post()
                            .uri(authService + "auth/validatetoken")
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(requestBody)
                        .retrieve()
                        .bodyToMono(String.class)
                        .flatMap(memberDetails -> {
                            try {

                                System.out.println("------>" +  memberDetails);
                                ObjectMapper objectMapper = new ObjectMapper();
                                JsonNode root = objectMapper.readTree(memberDetails);

                                MemberDetails memberDetailsObj = new MemberDetails();
                                memberDetailsObj.setMemberId(root.path("memberId").asLong());
                                memberDetailsObj.setPhoneNumber(root.path("phoneNumber").asText());

                                System.out.println("------>" +  memberDetailsObj.getMemberId().toString());


                                ServerHttpRequest mutatedRequest = exchange.getRequest()
                                        .mutate()
                                        .header("X-Member-Id", memberDetailsObj.getMemberId().toString())
                                        .header("X-Username", memberDetailsObj.getPhoneNumber())
                                        .build();

                                ServerWebExchange mutatedExchange = exchange.mutate()
                                        .request(mutatedRequest)
                                        .build();

                                return chain.filter(mutatedExchange);

                            /*if (Boolean.TRUE.equals(isValidateToken)) {
                                // Token is valid, continue with the filter chain

                                return chain.filter(exchange);
                             } else {
                                // Token is invalid
                                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                                return exchange.getResponse().setComplete();
//                            }*/
                            }catch (Exception e){
                                e.printStackTrace();
                                exchange.getResponse().setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                                return exchange.getResponse().setComplete();
                            }

                        })
                        .onErrorResume(e -> {
                            // Handle error during token validation
                            e.printStackTrace();
                            exchange.getResponse().setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
                            return exchange.getResponse().setComplete();
                        });
            }
            //return chain.filter(exchange);

        };
    }

    public static class Config {
        // Configuration properties
    }
}

