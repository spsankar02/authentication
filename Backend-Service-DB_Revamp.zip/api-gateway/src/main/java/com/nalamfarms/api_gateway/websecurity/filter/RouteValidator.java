package com.nalamfarms.api_gateway.websecurity.filter;

import java.util.List;
import java.util.function.*;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

@Component
public class RouteValidator {

	public static final List<String> openAPIEndPoints = List.of("api/authsession");
	
	public Predicate<ServerHttpRequest> isSecured= request->openAPIEndPoints.stream().noneMatch(uri->request.getURI().getPath().contains(uri));
}
