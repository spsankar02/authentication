package com.nalamfarms.api_gateway.dto;

import lombok.Data;

@Data
public class MemberDetails {
    private Long memberId;
    private String phoneNumber;
}
