import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.nalamfarms.orchestrators_service.dto.InventoryMasterPurchaseShippingStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TxnInventoryPurchaseItem {
	private Long purchaseItemId;
	private Long skuId;
	private Long productOriginInfo;
	private Long rackId;
	private BigDecimal price;
	private BigDecimal stock;
	private Long unit;
	private LocalDateTime mfgDate;
	private LocalDateTime expDate;
	private Long statusId;
	private String notes;
	private Long shippingAmount;
	private String qrPath;
	private BigDecimal taxPercentage;
	private BigDecimal tax;
	private BigDecimal unitCost;
	private Long purchaseMasterId;
	private Long certificateStatus;
	private Boolean inventoryStatus;

	private InventoryMasterPurchaseShippingStatus shippingStatus;

}
