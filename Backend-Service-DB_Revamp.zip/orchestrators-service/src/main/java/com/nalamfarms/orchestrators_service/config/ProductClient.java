package com.nalamfarms.orchestrators_service.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nalamfarms.orchestrators_service.dto.AllBasketDetails;
import com.nalamfarms.orchestrators_service.dto.BasketDetailsResponse;
import com.nalamfarms.orchestrators_service.dto.BasketInput;
import com.nalamfarms.orchestrators_service.dto.CartServiceException;
import com.nalamfarms.orchestrators_service.dto.GetProductDetailsRequestDTO;
import com.nalamfarms.orchestrators_service.dto.GraphQLResponse;
import com.nalamfarms.orchestrators_service.dto.ItemListResponse;
import com.nalamfarms.orchestrators_service.dto.MappingBasketItemsDto;
import com.nalamfarms.orchestrators_service.dto.MappingItemDeals;
import com.nalamfarms.orchestrators_service.dto.MappingProductItemVariantSkuDto;
import com.nalamfarms.orchestrators_service.dto.MasterSkuPrice;
import com.nalamfarms.orchestrators_service.dto.MemberCategoryOfferItemBasket;
import com.nalamfarms.orchestrators_service.dto.MemberCategoryOfferItemBasketDto;
import com.nalamfarms.orchestrators_service.dto.MemberIdResponse;
import com.nalamfarms.orchestrators_service.dto.MemberInput;
import com.nalamfarms.orchestrators_service.dto.MemberOffersRedeemed;
import com.nalamfarms.orchestrators_service.dto.MoveInventoryResponse;
import com.nalamfarms.orchestrators_service.dto.MoveToInventoryRequest;
import com.nalamfarms.orchestrators_service.dto.OrderServiceException;
import com.nalamfarms.orchestrators_service.dto.Result;
import com.nalamfarms.orchestrators_service.dto.WishlistResponse;
import com.nalamfarms.orchestrators_service.exception.GraphQLServiceException;
import com.nalamfarms.orchestrators_service.query.ProductOrchestratorQuery;
//import com.nalamfarms.orchestrators_service.dto.GraphQLWrapper;
import com.nalamfarms.orchestrators_service.util.ResponseContent;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import reactor.core.publisher.Mono;

@Component
public class ProductClient {
  private final ObjectMapper objectMapper;
  private final WebClient webClient;
  private final WebClient.Builder webClientBuilder;

  private static final String GRAPHQL_PATH = "/graphql";

  @Value("${product.service.url}")
  private String productServiceUrl;

  public ProductClient(
	        WebClient.Builder webClientBuilder,
	        ObjectMapper objectMapper,
	        @Value("${product.service.url}") String productServiceUrl
	) {
	    this.webClientBuilder = webClientBuilder; // this line required!
	    this.objectMapper = objectMapper;
	    this.productServiceUrl = productServiceUrl;
	    this.webClient = webClientBuilder.baseUrl(productServiceUrl).build();
	}
  private static final Logger log = LoggerFactory.getLogger(ProductClient.class);
  //WebClient webClient = WebClient.create(productServiceUrl);



  public JsonNode getPriceDetails(GetProductDetailsRequestDTO request) {
    if (request == null) {
      throw new IllegalArgumentException(ResponseContent.REQUEST_CANNOT_BE_NULL);
    }

    try {
      String query = ProductOrchestratorQuery.getPriceDetails();


      ObjectNode variables = objectMapper.createObjectNode();
//      variables.putPOJO("input", request);

      ObjectNode requestBody = objectMapper.createObjectNode();
      ArrayNode itemInputArray = null;
      ArrayNode basketInputArray = null;

//      if (request.getItemInput() != null) {
//        for (ItemInput item : request.getItemInput()) {
//          ObjectNode itemNode = objectMapper.createObjectNode();
//          itemNode.put("itemId", item.getItemId());
//          itemNode.put("variantTypeId", item.getVariantTypeId());
//          itemInputArray.add(itemNode);
//        }
//      }

      if (request.getBasketInput() != null) {
        for (BasketInput basket : request.getBasketInput()) {
          itemInputArray = objectMapper.createArrayNode();
          basketInputArray = objectMapper.createArrayNode();

          ObjectNode basketNode = objectMapper.createObjectNode();
          basketNode.put("basketId", basket.getBasketId());
          basketNode.put("variantTypeId", basket.getVariantTypeId());
          basketNode.put("itemId", basket.getItemId());
          if (basket.getItemId() != null) {
            itemInputArray.add(basketNode);
          }
          if (basket.getBasketId() != null) {
            basketInputArray.add(basketNode);
          }
        }
      }

      variables.put("type", request.getType());
      variables.put("memberId", request.getMemberId());
      variables.set("itemInput", itemInputArray);
      variables.set("basketInput", basketInputArray); // can be empty []

      requestBody.put("query", query); // your query string method
      requestBody.set("variables", variables);


//      variables.put("cartId", request.getCartId());
//      variables.put("memberId", request.getMemberId());
//      variables.put("status", request.getStatus());
      System.out.println("requestBody---------------->" + requestBody);
      return webClient.post()
        .uri(productServiceUrl + GRAPHQL_PATH)
        .bodyValue(requestBody)
        .retrieve()
        .onStatus(
          status -> status.isError(),
          response -> response.bodyToMono(String.class)
            .flatMap(body -> Mono.error(new OrderServiceException(
              "Cart service error. Status: " + response.statusCode() + ResponseContent.BODY + body
            )))
        )
        .bodyToMono(JsonNode.class)
        .blockOptional()
        .orElseThrow(() -> new OrderServiceException(ResponseContent.NO_RESPONSE_PRODUCTSERVICE));

    } catch (WebClientResponseException e) {
      throw new OrderServiceException(ResponseContent.HTTP_ERROR_FROM_PRODUCT + e.getStatusCode() + ResponseContent.MESSAGE + e.getResponseBodyAsString(), e);
    } catch (Exception e) {
      throw new OrderServiceException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
    }
  }


 


    @CircuitBreaker(name = "productServiceCircuitBreaker", fallbackMethod = "fallbackGetItemsByProductId")
    public List<ItemListResponse> getItemsByProductId(Long productId, Long memberId, Long classificationId,List<Long> allergies,int type) {
		try {
			String formattedAllergies = allergies.toString();

			String query = ProductOrchestratorQuery.getItemsByProductIdQuery(productId, memberId, classificationId, formattedAllergies, type);

			Map<String, String> requestBody = Map.of("query", query);

			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetItemsByProductId();
			} else {
				return Collections.emptyList();
			}
		} catch (Exception e) {
               e.printStackTrace();
		}
		return null;
	}
    
    public List<ItemListResponse> fallbackGetItemsByProductId(Long productId, Long memberId, Long classificationId, List<Long> allergies, int type,Throwable t) {
        log.error("Fallback for getItemsByProductId triggered due to {}", t.toString());
        return Collections.emptyList(); 
    }

	public ItemListResponse getItemsByItemId(Long skuId, Long memberId, List<Long> allergies) {
		String formattedAllergies = allergies.toString();
		String query =ProductOrchestratorQuery.getItemsByItemIdQuery(skuId, memberId, formattedAllergies);
		Map<String, String> requestBody = Map.of("query", query);

		GraphQLResponse response = webClientBuilder.build().post().uri(productServiceUrl + "/graphql")
				.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
				.bodyToMono(GraphQLResponse.class).block();

		if (response != null && response.getData() != null) {
			return response.getData().getGetItemDetails();
		} else {
			return (ItemListResponse) Collections.emptyList();
		}

	}
	public List<ItemListResponse> getListOfItemDetails(Long itemId, Long memberId, List<Long> allergies) {
		String formattedAllergies = allergies.toString();
		String query =ProductOrchestratorQuery.getListOfItemDetailsQuery(itemId, memberId, formattedAllergies);

		Map<String, String> requestBody = Map.of("query", query);

		GraphQLResponse response = webClientBuilder.build().post().uri(productServiceUrl + "/graphql")
				.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
				.bodyToMono(GraphQLResponse.class).block();
		if (response != null && response.getData() != null) {
	        ItemListResponse singleItem = response.getData().getGetItemDetails();
	        if (singleItem != null) {
	            return List.of(singleItem);
	        } else {
	            return Collections.emptyList();
	        }
	    } else {
	        return Collections.emptyList();
	    }
	}
	public List<ItemListResponse> getDealOfTheWeekByProducts(Long productId, Long memberId, List<Long> allergies,int activeType) {
		String formattedAllergies = allergies.toString();
		String query = ProductOrchestratorQuery.getDealOfTheWeekByProductsQuery(productId, memberId, formattedAllergies, activeType);

		Map<String, String> requestBody = Map.of("query", query);

		GraphQLResponse response = webClientBuilder.build().post().uri(productServiceUrl + "/graphql")
				.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
				.bodyToMono(GraphQLResponse.class).block();

		if (response != null && response.getData() != null) {
			return response.getData().getGetDealOfTheWeekByProducts();
		} else {
			return Collections.emptyList();
		}

	}
	public  BasketDetailsResponse getBasketDetails(Long skuId, Long memberId, List<Long> allergies) {
		String formattedAllergies = allergies.toString();

		String query = ProductOrchestratorQuery.getBasketDetailsQuery(skuId, memberId, formattedAllergies);

		Map<String, String> requestBody = Map.of("query", query);

		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetBasketDetilsByBasketId();
			} else {
				return null;
			}

		} catch (WebClientResponseException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	
	public  BasketDetailsResponse getBasketDetailsByBasketId(Long basketId, Long memberId, List<Long> allergies) {
		String formattedAllergies = allergies.toString();

		String query = ProductOrchestratorQuery.getBasketDetailsByBasketIdQuery(basketId, memberId, formattedAllergies);

		Map<String, String> requestBody = Map.of("query", query);

		System.out.println(query);

		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			System.out.println("Errors: " + response.getErrors());
			System.out.println("Data: " + response.getData());

			if (response != null && response.getData() != null) {
				return response.getData().getGetBasketDetilsByBasketId();
			} else {
				return null;
			}



		} catch (WebClientResponseException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public List<AllBasketDetails> getAllBaskets(int limit, String type, Long memberId, List<Long> allergies,int activeType) {
		String formattedAllergies = allergies.toString(); // example: [1, 2, 3]

		String query = ProductOrchestratorQuery.getAllBasketsQuery(limit, type, memberId, formattedAllergies, activeType);


		Map<String, String> requestBody = Map.of("query", query);

		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetAllBaskets();
			} else {
				return Collections.emptyList();
			}
		} catch (WebClientResponseException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public List<AllBasketDetails> searchItemBasket(String keyword, Long memberId, List<Long> allergies) {
		if (keyword == null || keyword.trim().isEmpty() || memberId == null) {
			return Collections.emptyList();
		}

		String formattedAllergies = allergies == null ? "null" : allergies.toString(); // "[1, 2, 3]" or null

		String query = ProductOrchestratorQuery.searchItemBasket(keyword, memberId, formattedAllergies);

		Map<String, String> requestBody = Map.of("query", query);

		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetItemBasketSearch(); // adjust if different in your GraphQLResponse
			} else {
				System.err.println("GraphQL returned no data");
				return Collections.emptyList();
			}
		} catch (WebClientResponseException e) {
			System.err.println("HTTP error: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
			throw new RuntimeException(e);
		} catch (Exception e) {
			System.err.println("Unexpected error: " + e.getMessage());
			throw new RuntimeException(e);
		}
	}




	public List<BasketDetailsResponse> getSimilarBaskets(Long skuId, Long memberId, List<Long> allergies) {
		String formattedAllergies = (allergies == null) ? "null" : allergies.toString();

		String query =ProductOrchestratorQuery.getSimilarBasketsQuery(skuId, memberId, formattedAllergies);

		Map<String, String> requestBody = Map.of("query", query);

		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetSimilarBaskets();
			} else {
				return null;
			}

		} catch (WebClientResponseException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public List<BasketDetailsResponse> getSuggestionBaskets( Long memberId, List<Long> allergies,List<Long>skuIds) {
		String formattedItemIds = skuIds.toString();
		String formattedAllergies = (allergies == null) ? "null" : allergies.toString();

		String query = ProductOrchestratorQuery.getSuggestionBasketsQuery(memberId, formattedAllergies, formattedItemIds);

		Map<String, String> requestBody = Map.of("query", query);

		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetSuggestionBaskets(); // Replace with actual getter method
			} else {
				return null;
			}

		} catch (WebClientResponseException e) {
			throw new RuntimeException(e);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}


	public MemberIdResponse getMemberId(Long inputMemberId) {
	        return webClientBuilder.build()
	                .get()
	                .uri(productServiceUrl + "/getMemberId/" + inputMemberId)
	                .retrieve()
	                .bodyToMono(MemberIdResponse.class)
	                .block();
	    }
	@CircuitBreaker(name="productServiceCircuitBreaker",fallbackMethod="fallbackGetOffersByMemberCategory")
		public List<MemberCategoryOfferItemBasket> getOffersByMemberCategory(MemberInput input,
				List<MemberOffersRedeemed> redeemedList, List<Long> allergyIds) {

			String graphqlQuery =ProductOrchestratorQuery.getOffersByMemberCategoryQuery();

			Map<String, Object> variables = new HashMap<>();
			variables.put("memberId", input.getMemberId());
			variables.put("categoryId", input.getCategoryId());
			List<Map<String, Object>> redeemedListMap = redeemedList.stream()
				    .map(item -> {
				        Map<String, Object> map = new HashMap<>();
				        map.put("memberOffersRedeemedId", item.getMemberOffersRedeemedId());
				        map.put("memberId", item.getMemberId());
				        map.put("mappingOfferId", item.getMappingOfferId());
				        map.put("orderId", item.getOrderId());
				        map.put("createdAt", item.getCreatedAt().toString()); // or formatted string
				        map.put("modifiedAt", item.getModifiedAt() != null ? item.getModifiedAt().toString() : null);
				        map.put("createdBy", item.getCreatedBy());
				        map.put("modifiedBy", item.getModifiedBy());
				        map.put("offerId", item.getOfferId());
				        return map;
				    })
				    .collect(Collectors.toList());
			variables.put("redeemed", redeemedListMap);
			variables.put("allergyIds", allergyIds);

			Map<String, Object> requestBody = Map.of("query", graphqlQuery, "variables", variables);

			return webClientBuilder.build().post().uri(productServiceUrl + "/graphql").bodyValue(requestBody).retrieve()
					.bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {
					}).map((Map<String, Object> response) -> {
						@SuppressWarnings("unchecked")
						Map<String, Object> data = (Map<String, Object>) response.get("data");
						Object offers = data.get("getMemberOffer");
						return convertToOfferList(offers);
					}).block();
		}
	public List<MemberCategoryOfferItemBasket> fallbackGetOffersByMemberCategory(MemberInput input,
				List<MemberOffersRedeemed> redeemedList, List<Long> allergyIds,Throwable t){
		 log.error("Fallback Get Offers By Member Category triggered by due to:",t.toString());
		return Collections.emptyList();
	}

		private List<MemberCategoryOfferItemBasket> convertToOfferList(Object data) {
			if (data == null || !(data instanceof List<?>)) {
				return Collections.emptyList();
			}

			ObjectMapper mapper = new ObjectMapper();

			return ((List<?>) data).stream().map(item -> mapper.convertValue(item, MemberCategoryOfferItemBasket.class))
					.collect(Collectors.toList());
		}

	public List<ItemListResponse> searchItemsByKeyword(String keyword, Long memberId, List<Long> allergies) {
	    String query =ProductOrchestratorQuery.searchItemsByKeywordQuery();

	    Map<String, Object> variables = new HashMap<>();
	    variables.put("keyword", keyword);
	    variables.put("memberId", String.valueOf(memberId)); // ID must be string or number
	    variables.put("allergies", allergies);

	    Map<String, Object> requestBody = Map.of(
	        "query", query,
	        "variables", variables
	    );

	    GraphQLResponse response = webClientBuilder.build()
	        .post()
	        .uri(productServiceUrl + "/graphql")
	        .contentType(MediaType.APPLICATION_JSON)
	        .bodyValue(requestBody)
	        .retrieve()
	        .bodyToMono(GraphQLResponse.class)
	        .block();

	    if (response != null && response.getData() != null) {
	        return response.getData().getGetItemSearch();
	    }
	    return Collections.emptyList();
	}
@CircuitBreaker(name="cartServiceCircuitBreaker",fallbackMethod="fallbackFetchDealDetails")
	public MappingItemDeals fetchDealDetails(Long productId, Long skuId) {
        String query = ProductOrchestratorQuery.getDealDetailsQuery();

        Map<String, Object> variables = Map.of("productId", productId, "skuId", skuId);
        Map<String, Object> requestBody = Map.of("query", query, "variables", variables);

        try {
            JsonNode response = webClient.post()
                    .uri(productServiceUrl + GRAPHQL_PATH)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(JsonNode.class)
                    .block();

            JsonNode dealNode = response.path("data").path("getDealDetails");

            return new MappingItemDeals(
                dealNode.path("itemPrice").decimalValue(),
                dealNode.path("discountPrice").decimalValue(),
                dealNode.path("isItemDeal").asBoolean(false)
            );

        } catch (Exception e) {
            throw new RuntimeException("ProductService call failed: " + e.getMessage());
        }
    }
 public MappingItemDeals fallbackFetchDealDetails(Long productId, Long itemId,Throwable t) {
	 log.error("Fallback orchestrator triggered for productId {}, reason: {}", productId, t.toString());
	return null;
 }
    public List<MemberCategoryOfferItemBasketDto> getMemberOffers(Long memberId) {
	    try {
	        String query = ProductOrchestratorQuery.getMemberOffersQuery();

	        Map<String, Object> requestBody = new HashMap<>();
	        requestBody.put("query", query);
	        requestBody.put("variables", Map.of("memberId", memberId));

	        WebClient webClient = WebClient.builder()
	                .baseUrl(productServiceUrl+ GRAPHQL_PATH)
	                .build();

	        Map<String, Object> response = webClient.post()
	        	    .bodyValue(requestBody)
	        	    .retrieve()
	        	    .onStatus(
	        	        status -> status.isError(),
	        	        clientResponse -> clientResponse.bodyToMono(String.class)
	        	            .map(body -> new RuntimeException(ResponseContent.ERROR_MEMBEROFFER_SERVICE + body))
	        	    )
	        	    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
	        	    .blockOptional()
	        	    .orElseThrow(() -> new RuntimeException(ResponseContent.NORESPONSE_MEMBEROFFER_SERVICE));

	        Object data = ((Map<?, ?>) response.get("data")).get("getMemberOffer");

	        if (!(data instanceof List<?> resultList)) {
	            return Collections.emptyList();
	        }

	        List<MemberCategoryOfferItemBasketDto> dtoList = new ArrayList<>();
	        for (Object obj : resultList) {
	            Map<?, ?> map = (Map<?, ?>) obj;
	            MemberCategoryOfferItemBasketDto dto = new MemberCategoryOfferItemBasketDto();
	            dto.setMappingOfferItemBasketId(getLong(map.get("mappingOfferItemBasketId")));
	            dto.setOfferId(getLong(map.get("offerId")));
	            dto.setBasket(map.get("basket") != null ? getLong(map.get("basket")) : null);
	            dto.setVarientTypeId(getLong(map.get("varientTypeId")));
	            dto.setMemberCategoryId(getLong(map.get("memberCategoryId")));
	            dtoList.add(dto);
	        }

	        return dtoList;

	    } catch (Exception e) {
	        log.error("Error fetching member offers: {}", e.getMessage(), e);
	        throw new RuntimeException(ResponseContent.FAILED_TO_FETCH_MEMBEROFFER, e);
	    }
	}

    private Long getLong(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return Long.valueOf(value.toString());
        } catch (NumberFormatException e) {
            // handle error: maybe log it, or return null
            return null;
        }
    }
@CircuitBreaker(name="productServiceCircuitBreaker",fallbackMethod="fallbackFetchProductDetails")
	public List<Result> fetchProductDetails(List<Long> skuIds,
			String type, Long memberId) {
		try {
			String query = ProductOrchestratorQuery.buildGraphQLQuery();
			ObjectNode variables = objectMapper.createObjectNode();

			List<ObjectNode> itemInput = new ArrayList<>();
			variables.putPOJO("skuIds", skuIds);
			variables.put("type", type);
			variables.put("memberId", memberId);

			ObjectNode requestBody = objectMapper.createObjectNode();
			requestBody.put("query", query);
			requestBody.set("variables", variables);

			Map<String, Object> response = webClient.post()
			        .uri(productServiceUrl + "/graphql")
			        .bodyValue(requestBody)
			        .retrieve()
			        .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
			        .block();

			    if (response == null || response.get("data") == null) {
			        throw new RuntimeException(ResponseContent.NO_DATA_RETURNED_FROM_GRAPHQL);
			    }

			    Object dataObj = response.get("data");
			    if (!(dataObj instanceof Map<?, ?> dataMap)) {
			        throw new RuntimeException(ResponseContent.INVALID_DATA_STRUCTURE);
			    }

			    Object productData = dataMap.get("getProductDetails");
			    if (!(productData instanceof Map<?, ?> productMap)) {
			        throw new RuntimeException(ResponseContent.MALFORMED_PRODUCT_DETAILS);
			    }

			    Object results = productMap.get("results");
			    if (!(results instanceof List<?>)) {
			        throw new RuntimeException(ResponseContent.PRODUCT_DETAILS_MISSING);
			    }

			    // Convert to List<Result>
			    ObjectMapper objectMapper = new ObjectMapper();
			    return objectMapper.convertValue(results,
			            objectMapper.getTypeFactory().constructCollectionType(List.class, Result.class));

		} catch (Exception e) {
			log.error("Error fetching product details: {}", e.getMessage());
			throw new CartServiceException(ResponseContent.FAILED_TO_FETCH_PRODUCT, e);
		}
	}
public List<Result> fallbackFetchProductDetails(Map<Long, Long> itemIdToVariantTypeId, Map<Long, Long> basketIdToVariantTypeId,
		String type, Long memberId,Throwable t){
	log.error("Fallback for Getch Product Details details triggered due to {}",t.toString());
	return Collections.emptyList();
}

	

	public WishlistResponse getWishlist(Long memberId, String type, List<Long> allergyIds) {
		String query =ProductOrchestratorQuery.getWishlistQuery();
		Map<String, Object> variables = Map.of(
	        "memberId", memberId,
	        "type", type,
	        "allergyIds", allergyIds
	    );
	    Map<String, Object> requestBody = Map.of("query", query, "variables", variables);

	    String rawJson = webClientBuilder.build()
	        .post()
	        .uri(productServiceUrl + "/graphql")
	        .contentType(MediaType.APPLICATION_JSON)
	        .bodyValue(requestBody)
	        .retrieve()
	        .bodyToMono(String.class)
	        .block();

	    try {
	        JsonNode root = objectMapper.readTree(rawJson);
	        JsonNode getWishlistNode = root.path("data").path("getWishlist");
	        if (getWishlistNode.isMissingNode() || getWishlistNode.isNull()) return null;
	        return objectMapper.treeToValue(getWishlistNode, WishlistResponse.class);
	    } catch (Exception e) {
	        throw new RuntimeException(ResponseContent.FAILED_TO_PARSE_RESPONSE, e);
	    }
	}


	public List<ItemListResponse> getItemsListBySeasonal(Long memberId, List<Long> allergies,int activeType) {
		String formattedAllergies = allergies.toString();
		String query = ProductOrchestratorQuery.getItemsListBySeasonalQuery(memberId, formattedAllergies, activeType);

		Map<String, String> requestBody = Map.of("query", query);

		try {
		
		GraphQLResponse response = webClientBuilder.build().post().uri(productServiceUrl + "/graphql")
				.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
				.bodyToMono(GraphQLResponse.class).block();

		if (response != null && response.getData() != null) {
			return response.getData().getGetItemsListBySeasonal();
		} else {
			return Collections.emptyList();
		}} catch (Exception ex) {
			ex.printStackTrace();
		    throw new GraphQLServiceException(ex.toString());
}
	}
	public List<BasketDetailsResponse> getBasketDetails(List<Long> basketIds, Long memberId, List<Long> allergies) {
	    String formattedAllergies = allergies.toString();
	    List<BasketDetailsResponse> results = new ArrayList<>();

	    for (Long basketId : basketIds) {
	        String query =ProductOrchestratorQuery.getBasketDetails(basketId, memberId, formattedAllergies);
	        Map<String, String> requestBody = Map.of("query", query);

	        try {
	            GraphQLResponse response = webClientBuilder.build()
	                    .post()
	                    .uri(productServiceUrl + "/graphql")
	                    .contentType(MediaType.APPLICATION_JSON)
	                    .bodyValue(requestBody)
	                    .retrieve()
	                    .bodyToMono(GraphQLResponse.class)
	                    .block();

	            if (response != null && response.getData() != null) {
	                BasketDetailsResponse basketDetails = response.getData().getGetBasketDetilsByBasketId();
	                if (basketDetails != null) {
	                    results.add(basketDetails);
	                }
	            }

	        } catch (WebClientResponseException e) {
	            throw new RuntimeException("GraphQL call failed for basketId: " + basketId, e);
	        } catch (Exception e) {
	            throw new RuntimeException("Unexpected error for basketId: " + basketId, e);
	        }
	    }

	    return results;
	}
	
	public List<MappingProductItemVariantSkuDto> getItemsOrBasketDetailsBySkuId(List<BasketInput> basketInputs, List<Long> skuIdList) {
		String formattedSkuWithCodeList = toGraphQLBasketInputs(basketInputs);
		String formattedSkuList = toGraphQLIdList(skuIdList);


		String query = ProductOrchestratorQuery.getItemsOrBasketDetailsBySkuIdQuery(formattedSkuWithCodeList, formattedSkuList);

		Map<String, String> requestBody = Map.of("query", query);

		try {
			GraphQLResponse response = webClientBuilder.build().post().uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
					.bodyToMono(GraphQLResponse.class).block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetItemsOrBasketDetailsBySkuId();
		} else {
				return Collections.EMPTY_LIST ;
			}
		} catch (WebClientResponseException e) {
			e.printStackTrace();
			throw new RuntimeException("GraphQL call failed for skuList: " + skuIdList, e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Unexpected error for skuList: " + skuIdList, e);
		}
	}

	public MoveInventoryResponse saveMasterSkuPrice(List<MoveToInventoryRequest> moveToInventoryRequest) {
		return webClientBuilder.build().post().uri(productServiceUrl + "/saveMasterSkuPrice")
				.bodyValue(moveToInventoryRequest).retrieve().bodyToMono(MoveInventoryResponse.class).block();
	}

	public List<MasterSkuPrice>  getSkuMasterSkuPrice (List<Long> skuIds) {
		String formattedSkuList = skuIds.toString();

		Map<String, Object> requestBody = ProductOrchestratorQuery.getSkuMasterSkuPrice(skuIds);
		try {
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(productServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetSkuMasterSkuPrice();
			} else {
				return Collections.emptyList();
			}
		} catch (WebClientResponseException e) {
			throw new RuntimeException("GraphQL call failed for skuList: " + skuIds, e);
		} catch (Exception e) {
			throw new RuntimeException("Unexpected error for skuList: " + skuIds, e);
		}


	}

	private String toGraphQLBasketInputs(List<BasketInput> basketInputs) {
		return basketInputs.stream()
				.map(input -> {
					List<String> fields = new ArrayList<>();
					if (input.getBasketId() != null) fields.add("basketId: " + input.getBasketId());
					if (input.getVariantTypeId() != null) fields.add("variantTypeId: " + input.getVariantTypeId());
					if (input.getItemId() != null) fields.add("itemId: " + input.getItemId());
					if (input.getSkuId() != null) fields.add("skuId: " + input.getSkuId());
					if (input.getBatchCode() != null) fields.add("batchCode: \"" + input.getBatchCode() + "\"");
					return "{ " + String.join(", ", fields) + " }";
				})
				.collect(Collectors.joining(", ", "[", "]"));
	}

	private String toGraphQLIdList(List<Long> ids) {
		return ids == null ? "null" : ids.stream()
				.map(String::valueOf)
				.collect(Collectors.joining(", ", "[", "]"));
	}


	 public List<MappingBasketItemsDto> findByBasketIdIn(List<Long> basketIds) {
	        if (basketIds == null || basketIds.isEmpty()) {
	            return Collections.emptyList();
	        }

	        String query = ProductOrchestratorQuery.findByBasketIdIn();

	        Map<String, Object> requestBody = Map.of(
	                "query", query,
	                "variables", Map.of("basketIds", basketIds)
	        );

	        try {
	            GraphQLResponse response = webClientBuilder.build()
	                    .post()
	                    .uri(productServiceUrl + "/graphql")
	                    .contentType(MediaType.APPLICATION_JSON)
	                    .bodyValue(requestBody)
	                    .retrieve()
	                    .bodyToMono(GraphQLResponse.class)
	                    .block();

	            if (response != null &&
	                response.getData() != null &&
	                response.getData().getGetBasketItemsList() != null) {
	                return response.getData().getGetBasketItemsList();
	            }

	        } catch (WebClientResponseException e) {
	            throw new RuntimeException("GraphQL call failed for basketIds: " + basketIds + " - " + e.getResponseBodyAsString(), e);
	        } catch (Exception e) {
	            throw new RuntimeException("Unexpected error for basketIds: " + basketIds, e);
	        }

	        return Collections.emptyList();
	    }
	
}