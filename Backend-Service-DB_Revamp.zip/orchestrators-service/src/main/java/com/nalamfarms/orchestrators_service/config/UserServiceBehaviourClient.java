package com.nalamfarms.orchestrators_service.config;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.nalamfarms.orchestrators_service.dto.MemberIdResponse;
import com.nalamfarms.orchestrators_service.dto.NotificationWhatsAppRequestDto;
import com.nalamfarms.orchestrators_service.dto.RecentEntriesDetailsInput;
import com.nalamfarms.orchestrators_service.dto.RecentEntriesResponse;
import com.nalamfarms.orchestrators_service.dto.RecommendInput;
import com.nalamfarms.orchestrators_service.dto.RecommendItemListResponse;
import com.nalamfarms.orchestrators_service.dto.RegisterDto;
import com.nalamfarms.orchestrators_service.dto.RegisterResponse;
import com.nalamfarms.orchestrators_service.dto.SendMessageResponse;

@Component
public class UserServiceBehaviourClient {

	@Autowired
    private  WebClient webClient;

    @Value("${user.behaviour.service.url}")
    private String userBehaviourBaseUrl;
    @Value("${user.service.url}")
    private String userServiceUrl;
    @Value("${notification.service.url}")
    private String notificationServcieUrl;
    public List<RecentEntriesResponse> getRecentEntries(RecentEntriesDetailsInput input) {
        return webClient.post()
                .uri(userBehaviourBaseUrl + "/api/recent-entries/")
                .bodyValue(input)
                .retrieve()
                .bodyToFlux(RecentEntriesResponse.class)
                .collectList()
                .block();
    }
    
    public List<RecommendItemListResponse> getRecommendedEntries(RecommendInput input){
    	 return webClient.post()
                 .uri(userBehaviourBaseUrl + "/api/recommend-products/")
                 .bodyValue(input)
                 .retrieve()
                 .bodyToFlux(RecommendItemListResponse.class)
                 .collectList()
                 .block();
     }
    
    public void saveRecentViewDetails(RecentEntriesResponse input) {
        try {
            webClient.post()
                .uri(userBehaviourBaseUrl + "/api/track/")
                .bodyValue(input)
                .retrieve()
                .toBodilessEntity()
                .block();

        } catch (WebClientResponseException e) {
            throw new RuntimeException("Failed to save recent view: " + e.getResponseBodyAsString());
        } catch (Exception ex) {
            throw new RuntimeException("Unexpected error while saving recent view", ex);
        }
    }


    public Map<String, Object> getSelfRegister(RegisterDto registerDto) {
        try {
            return webClient.post()
                    .uri(userServiceUrl + "/auth/selfRegistration")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(registerDto)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, response ->
                        response.bodyToMono(String.class)
                            .map(body -> new RuntimeException(
                                "Error " + response.statusCode() + " body: " + body))
                    )
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .block();

        } catch (WebClientResponseException e) {
            System.err.println("Error Response: " + e.getStatusCode() + " - " + e.getResponseBodyAsString());
            throw e;
        }
    }


    
    		public SendMessageResponse sendWhatsAppMessage(NotificationWhatsAppRequestDto dto) {
    			return webClient.post()
    	                .uri(notificationServcieUrl+ "/api/whatsapp/sendSync")
    	                .bodyValue(dto)
    	                .retrieve()
    	                .bodyToMono(SendMessageResponse.class)
    	                .block();
    		}
    		
    		

    		public Long getMemberIdByPhoneNumber(String phoneNumber) {
    		    MemberIdResponse response = webClient.get()
    		            .uri(userServiceUrl + "/member/getMemberIdByPhoneNumber?phoneNumber=" + phoneNumber)
    		            .retrieve()
    		            .bodyToMono(MemberIdResponse.class)
    		            .block();

    		    return response != null ? response.getMemberId() : null;
    		}

    		public RegisterResponse generateReferralCode(Long memberId, String jwtToken) {
    		    return webClient.post()
    		            .uri(userServiceUrl + "/referral/generateReferralCode?memberId=" + memberId)
    		            .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtToken)  // pass token
    		            .retrieve()
    		            .bodyToMono(RegisterResponse.class)
    		            .block();
    		}

    	


}

    


