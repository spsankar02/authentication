package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InventoryTxnDemandDTO {
    private Long demandId;
    private String demandCode;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    private String demandStatus;
    private String notes;
    private String demandEndDate;
    private String previousEndDate;
    private List<DemandItemDTO> demandItems;
}
