package com.nalamfarms.orchestrators_service.dto;


import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class MappingItemDealsResponseDTO {
	private Long itemDealId;
    private Long productId;
    private Long itemId;
    private String itemCode;
    private Long dealId;
    private boolean active;
}

