package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@RequiredArgsConstructor
public class Item {
  private Long itemId;
  private String itemName;
  private String itemCode;

  private Long productId;
  private String imageUrl;
  private BigDecimal price;
  private BigDecimal discount;
  private BigDecimal realPrice;
  private Boolean wishList;
  private double rating;

  @JsonProperty("isStockAvailable")
  private boolean isStockAvailable;

  private BigDecimal stockQuantity;
  private List<String> allergies;
  private Integer size;
  private String unitName;
  private Boolean isActive;

  private Product products;
}
