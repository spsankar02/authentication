package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

@Data
public class MemberIdResponse {
	   private Long memberId;
	}
