package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberCategoryOfferItemBasketDto {
	private Long mappingOfferItemBasketId;
    private Long offerId;
    private Long basket;
    private Long varientTypeId;
    private Long memberCategoryId;
}
