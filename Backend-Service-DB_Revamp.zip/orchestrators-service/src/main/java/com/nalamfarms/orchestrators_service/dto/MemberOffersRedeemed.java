package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberOffersRedeemed  {
	private Long memberOffersRedeemedId;
    private Long memberId;
    private Long mappingOfferId;
    private Long orderId;
    private String createdAt;     
    private String modifiedAt;    
    private Long createdBy;
    private Long modifiedBy;     
    private Long offerId;
}
