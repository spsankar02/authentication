package com.nalamfarms.orchestrators_service.config;

import java.util.Collections;
import java.util.List;
import java.util.*;

import com.fasterxml.jackson.core.type.TypeReference;
import com.nalamfarms.orchestrators_service.dto.*;
import com.nalamfarms.orchestrators_service.dto.payment.PaymentSummary;
import com.nalamfarms.orchestrators_service.query.OrderOrchestratorQuery;
import com.nalamfarms.orchestrators_service.query.PaymentOrchestratorQuery;

import com.nalamfarms.orchestrators_service.query.ProductOrchestratorQuery;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nalamfarms.orchestrators_service.util.ResponseContent;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class PaymentClient {

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${payment.service.url}")
    private String paymentServiceUrl;

    @Autowired
    private WebClient webClient;

    private static final Logger log = LoggerFactory.getLogger(PaymentClient.class);

    private final WebClient.Builder webClientBuilder;

    @PostConstruct
    private void init() {
        this.webClient = webClientBuilder
                .baseUrl(paymentServiceUrl)
                .build();
    }


    public JsonNode getPaymentDetails(Long orderId) {
        if (orderId == null) {
            throw new IllegalArgumentException(ResponseContent.ORDERID_NOT_BE_CALL);
        }

        try {
            String query = PaymentOrchestratorQuery.paymentDetailsQuery();
            log.info("Calling Payment Service URL: {}", paymentServiceUrl);
            ObjectNode variables = objectMapper.createObjectNode();
            variables.put("orderId", orderId);

            ObjectNode requestBody = objectMapper.createObjectNode();
            requestBody.put("query", query);
            requestBody.set("variables", variables);

            return webClient.post().uri(paymentServiceUrl + "/graphql").bodyValue(requestBody).retrieve()
                    .onStatus(status -> status.isError(), response -> response.bodyToMono(String.class)
                            .flatMap(body -> Mono.error(new OrderServiceException(ResponseContent.PAYMENTSERVICE_ERROR
                                    + response.statusCode() + ResponseContent.BODY + body))))
                    .bodyToMono(JsonNode.class).blockOptional()
                    .orElseThrow(() -> new OrderServiceException(ResponseContent.NO_RESPONSE_PAYMENTSERVICE));

        } catch (WebClientResponseException e) {
            log.error("HTTP error from payment service: {}, message: {}", e.getStatusCode(),
                    e.getResponseBodyAsString(), e);
            throw new OrderServiceException(ResponseContent.HTTP_ERROR_FROM_PRODUCT + e.getStatusCode()
                    + ResponseContent.MESSAGE + e.getResponseBodyAsString(), e);
        } catch (Exception e) {
            log.error("Unexpected error while fetching payment details", e);
            throw new OrderServiceException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
        }

    }

    public PaymentDetailsDto getPaymentDetailsByRazorpay(String razorpayOrderId) {
        if (razorpayOrderId == null) {
            throw new IllegalArgumentException(ResponseContent.RAZRORORDERID_NOT_BE_CALL);
        }

        try {
            String query = PaymentOrchestratorQuery.getPaymentDetailsRazorPayQuery();
            log.info("Calling Payment Service URL: {}", paymentServiceUrl);
            ObjectNode variables = objectMapper.createObjectNode();
            variables.put("razorpayOrderId", razorpayOrderId);

            ObjectNode requestBody = objectMapper.createObjectNode();
            requestBody.put("query", query);
            requestBody.set("variables", variables);

            JsonNode paymentJsonNode = webClient.post().uri(paymentServiceUrl + "/graphql").bodyValue(requestBody).retrieve()
                    .onStatus(status -> status.isError(), response -> response.bodyToMono(String.class)
                            .flatMap(body -> Mono.error(new OrderServiceException(ResponseContent.PAYMENTSERVICE_ERROR
                                    + response.statusCode() + ResponseContent.BODY + body))))
                    .bodyToMono(JsonNode.class).blockOptional()
                    .orElseThrow(() -> new OrderServiceException(ResponseContent.NO_RESPONSE_PAYMENTSERVICE));

            JsonNode detailsNode = paymentJsonNode.path("data").path("findOrderByRazorpayOrderId");
            return objectMapper.treeToValue(detailsNode, PaymentDetailsDto.class);

        } catch (WebClientResponseException e) {
            e.printStackTrace();
            log.error("HTTP error from payment service: {}, message: {}", e.getStatusCode(),
                    e.getResponseBodyAsString(), e);
            throw new OrderServiceException(ResponseContent.HTTP_ERROR_FROM_PRODUCT + e.getStatusCode()
                    + ResponseContent.MESSAGE + e.getResponseBodyAsString(), e);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Unexpected error while fetching payment details", e);
            throw new OrderServiceException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
        }

    }

    public void savePaymentDetails(CreateOrderRequest req, com.razorpay.Order order) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            Map<String, Object> orderMap = order.toJson().toMap();
            RazorpayOrderDto orderDto = mapper.convertValue(orderMap, RazorpayOrderDto.class);

            SavePaymentRequest savePaymentRequest = new SavePaymentRequest();
            savePaymentRequest.setCreateOrderRequest(req);
            savePaymentRequest.setRazorpayOrder(orderDto);

            SaveResponse response = webClient.post().uri(paymentServiceUrl + "/api/payments/savePayments")
                    .bodyValue(savePaymentRequest).retrieve().bodyToMono(SaveResponse.class).block();

            log.info("Payment details saved successfully, response: {}", response);

        } catch (Exception e) {
            log.error("Error while saving payment details", e);
            throw new RuntimeException("Failed to save payment details", e);
        }
    }

    public SubscriptionResponseDto createSubscription(SaveSubscriptionRequestDto requestDto) {
        return webClient.post()
                .uri(paymentServiceUrl + "/api/subscription/create")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestDto)
                .retrieve()
                .bodyToMono(SubscriptionResponseDto.class)
                .block(); // remove .block() if you want a reactive Mono
    }


    public PaymentSummary getAdminPaymentSummary() {

        try {
            String query = PaymentOrchestratorQuery.adminPaymentsSummary();

            Map<String, String> requestBody = Map.of("query", query);

            GraphQLResponse response = webClientBuilder.build().post()
                    .uri(paymentServiceUrl + "/graphql")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(GraphQLResponse.class)
                    .block();

            if (response.getErrors() != null && !response.getErrors().isEmpty()) {
                throw new RuntimeException("GraphQL errors: " + response.getErrors());
            }

            // Map response to PaymentSummary
            return Optional.ofNullable(response.getData())
                    .map(GraphQLData::getAdminPaymentsSummary) // GraphQLData DTO should have getPaymentSummary()
                    .orElse(new PaymentSummary(0,0,0,0));
        } catch (Exception ex) {
            ex.printStackTrace();
            return new PaymentSummary();
        }

    }


//    public PagedResponse<PaymentDetailsDto> getPayments(int page, int pageSize) {
//        // Build GraphQL query dynamically
//        String query = """
//    query GetPayments($page: ID!, $pageSize: ID!) {
//      getPayments(page: $page, pageSize: $pageSize) {
//        totalNumberOfPages
//        totalNumberOfRecords
//        content {
//          paymentsId
//          memberId
//          orderId
//          paymentType
//          subscriptionId
//          transactionId
//          amount
//          currency
//          paymentGateway
//          paymentMode
//          paymentTime
//          createdAt
//          modifiedAt
//          createdBy
//          modifiedBy
//          active
//          razorpayOrderId
//          razorpayPaymentId
//          razorpayStatus
//          razorPayRefundId
//          refundAmount
//          paymentStatus {
//            statusCode
//            statusName
//            description
//          }
//        }
//      }
//    }
//    """;
//
//
//        Map<String, Object> variables = Map.of(
//                "page", page,
//                "pageSize", pageSize
//        );
//
//        Map<String, Object> requestBody = Map.of(
//                "query", query,
//                "variables", variables
//        );
//
//        return webClient.post()
//                .uri(paymentServiceUrl + "/graphql")
//                .contentType(MediaType.APPLICATION_JSON)
//                .bodyValue(requestBody)
//                .retrieve()
//                .bodyToMono(GraphQLResponse.class)  // no generics needed
//                .map(response -> {
//                    if (response.getErrors() != null && !response.getErrors().isEmpty()) {
//                        throw new RuntimeException("GraphQL errors: " + response.getErrors());
//                    }
//                    return response.getData().getGetPayments();  // now works!
//                })
//                .block();
//
//    }

    public PagedResponse<PaymentDetailsDto> getFilterPayments(
            Integer page,
            Integer pageSize,
            String startDate,
            String endDate,
            List<Long> paymentStatusIds,
            List<Long> orderIds
    ) {
        int safePage = (page != null && page > 0) ? page : 1;
        int safePageSize = (pageSize != null && pageSize > 0) ? pageSize : 10;

        Map<String, Object> variables = new HashMap<>();
        variables.put("page", safePage);
        variables.put("pageSize", safePageSize);
        variables.put("startDate", startDate);
        variables.put("endDate", endDate);
        variables.put("paymentStatusIds", paymentStatusIds);
        variables.put("orderIds", orderIds);

        // ✅ Get query string
        String query = PaymentOrchestratorQuery.getFilterPayments();

        // ✅ Include both query and variables
        Map<String, Object> requestBody = Map.of(
                "query", query,
                "variables", variables
        );

        return webClient.post()
                .uri(paymentServiceUrl + "/graphql")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(GraphQLResponse.class)
                .map(response -> {
                    if (response.getErrors() != null && !response.getErrors().isEmpty()) {
                        throw new RuntimeException("GraphQL errors: " + response.getErrors());
                    }
                    return Optional.ofNullable(response.getData())
                            .map(GraphQLData::getFilterPayments)
                            .orElse(new PagedResponse<>(Collections.emptyList(), 0, 0));
                })
                .block();
    }


}