package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;
import java.util.List;



import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class SubscriptionDetailsDto {
  private Long subscriptionId;

  private Long memberId;

  private LocalDateTime startDate;

  private LocalDateTime endDate;

  private SubscriptionStatusEnum status ;

  private LocalDateTime nextBillingDate;

  private LocalDateTime createdAt =  LocalDateTime.now();

  private LocalDateTime modifiedAt;

  private Boolean isActive;

  private Long createdBy;

  private Long modifiedBy;

  private MasterSubscriptionDuration subscriptionDurationId;

  private List<MasterSubscriptionDays> subscriptionDay;

  private List<MasterSubscriptionDeliveryTimeSlot> subscriptionDeliveryTimeSlot;



}
