package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Invoice {

	private Long invoiceId;

	private Long purchaseMasterId;

	private TxnInventoryPurchaseMaster txnInventoryPurchaseMaster;

	private String invoiceNumber;

	private BigDecimal totalAmount;

	private LocalDate invoiceDate;

	private Long invoiceStatusId;

	private MasterInventoryInvoiceStatus masterInventoryInvoiceStatus;

	private LocalDateTime createdDate = LocalDateTime.now();

	private LocalDateTime modifiedDate = LocalDateTime.now();

	private Long createdBy = 1l;

	private Long modifiedBy = 1l;

}
