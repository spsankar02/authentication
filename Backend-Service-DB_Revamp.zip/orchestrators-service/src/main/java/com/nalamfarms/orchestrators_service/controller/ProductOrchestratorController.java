package com.nalamfarms.orchestrators_service.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.orchestrators_service.dto.AllBasketDetails;
import com.nalamfarms.orchestrators_service.dto.BasketDetailsResponse;
import com.nalamfarms.orchestrators_service.dto.GenerateRequest;
import com.nalamfarms.orchestrators_service.dto.GenerateResponse;
import com.nalamfarms.orchestrators_service.dto.ImageRequest;
import com.nalamfarms.orchestrators_service.dto.ItemListResponse;
import com.nalamfarms.orchestrators_service.dto.MemberCategoryOfferItemBasket;
import com.nalamfarms.orchestrators_service.dto.WishlistResponse;
import com.nalamfarms.orchestrators_service.exception.GraphQLServiceException;
import com.nalamfarms.orchestrators_service.service.ProductOrchestratorService;



@RestController
//@RequestMapping("/orchestrator/product")
public class ProductOrchestratorController {

	@Autowired
	private ProductOrchestratorService productOrchestratorService;
	
	
	@QueryMapping
	public List<ItemListResponse> getItemsByProductId(@Argument Long productId, @Argument Long memberId, @Argument Long classificationId ,@Argument int type) {
		return productOrchestratorService.orchsetrateItemsByProductId(productId,memberId,classificationId,type);
	}
	
	
	@QueryMapping
	public ItemListResponse getItemDetails(@Argument Long skuId,@Argument Long memberId) {
		return productOrchestratorService.getItemsByItemId(skuId,memberId);
	} 
	
	@QueryMapping
	public List<ItemListResponse> getListOfItemDetails(@Argument List<Long> itemIds, @Argument Long memberId) {
	    return productOrchestratorService.getListOfItemDetails(itemIds, memberId);
	}

	
	@QueryMapping
	public List<ItemListResponse> getDealOfTheWeekByProducts(@Argument Long productId, @Argument Long memberId,@Argument int activeType ) throws GraphQLServiceException {
		return productOrchestratorService.getDealOfTheWeekByProducts(productId, memberId,activeType);
	}
	
	@QueryMapping
	public List<ItemListResponse> getItemsListBySeasonal(@Argument Long memberId,@Argument int activeType) throws GraphQLServiceException  {
		return productOrchestratorService.getItemsListBySeasonal(memberId,activeType);
	}
	

	@QueryMapping
	public BasketDetailsResponse getBasketDetails(@Argument Long skuId, @Argument Long memberId) throws GraphQLServiceException {
		return productOrchestratorService.getBasketDetails(skuId,memberId);
	}
	
	
	@QueryMapping
	public BasketDetailsResponse getBasketDetilsByBasketId(@Argument Long basket, @Argument Long memberId) {
		System.out.println("Basket Id : " + basket +"******* memberId" + memberId);
		return productOrchestratorService.getBasketDetilsByBasketId(memberId, basket);
	}

	@QueryMapping
	public List<BasketDetailsResponse> getListOfBasketDetails(@Argument List<Long> basketIds, @Argument Long memberId) throws GraphQLServiceException {
		return productOrchestratorService.getListOfBasketDetails(basketIds,memberId);
	}

	@QueryMapping
	public List<AllBasketDetails> getAllBaskets(@Argument int limit, @Argument String type, @Argument Long memberId, @Argument int activeType) throws GraphQLServiceException {
		return productOrchestratorService.getAllBaskets(limit,type,memberId,activeType);
	}


	@QueryMapping
	public List<BasketDetailsResponse> getSimilarBaskets(@Argument Long skuId, @Argument Long memberId) throws GraphQLServiceException {
		return productOrchestratorService.getSimilarBaskets(skuId,memberId);
	}

//	@GetMapping("/offers/{memberId}")
//	    public List<MemberCategoryOfferItemBasket> getFinalOffers(@PathVariable Long memberId) {
//	        return productOrchestratorService.getFinalOffers(memberId);
//	    }

	@QueryMapping
	public List<ItemListResponse> getItemSearch(@Argument String keyword,@Argument Long  memberId) {
		return productOrchestratorService.searchItemsByKeyword(keyword,memberId);
	}

	@QueryMapping
	public List<BasketDetailsResponse> getSuggestionBaskets( @Argument Long memberId,@Argument List<Long> skuIds) throws GraphQLServiceException {
		return productOrchestratorService.getSuggestionBaskets(memberId,skuIds);
	}

	@QueryMapping
	public List<MemberCategoryOfferItemBasket> getMemberOfferDetails(@Argument Long memberId) {
		return productOrchestratorService.getMemberOfferDetails(memberId);
	}

	@QueryMapping
	public List<AllBasketDetails> getItemBasketSearch(@Argument String keyword, @Argument Long memberId) {
		return productOrchestratorService.getItemBasketSearch(keyword, memberId);
	}
	@QueryMapping
	public WishlistResponse getWishlist(@Argument Long memberId, @Argument String type) {
	    return productOrchestratorService.getWishlist(memberId, type);
	}
	
	  @PostMapping(value = "/getProductsWithImage")
	    public List<ItemListResponse> getProductsWithImage(@RequestBody ImageRequest request) {
		  String base64Image = request.getBase64Image(); // from request body
		  byte[] imageBytes = Base64.getDecoder().decode(base64Image);
	        return productOrchestratorService.processImage(imageBytes,request.getMemberId());
	    }
	  
	  @PostMapping("/getChatbot")
	    public ResponseEntity<GenerateResponse> getChatBotGenerator(@RequestBody GenerateRequest generateRequest) {
	        GenerateResponse response = productOrchestratorService.getchatBotGenerator(generateRequest);	                	   
	        return ResponseEntity.ok(response);
	    }
}
