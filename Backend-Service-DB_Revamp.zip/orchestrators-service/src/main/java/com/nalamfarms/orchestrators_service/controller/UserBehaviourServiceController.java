package com.nalamfarms.orchestrators_service.controller;

import java.util.List;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nalamfarms.orchestrators_service.dto.RecentEntriesDetailsInput;
import com.nalamfarms.orchestrators_service.dto.RecentEntriesResponse;
import com.nalamfarms.orchestrators_service.dto.RecentViewedDetailsResponse;
import com.nalamfarms.orchestrators_service.dto.RegisterDto;
import com.nalamfarms.orchestrators_service.service.UserBehaviourService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class UserBehaviourServiceController {
 private final UserBehaviourService  userBehaviourService;
	
 @QueryMapping
 public List<RecentEntriesResponse> getRecentEntries(@Argument("input") RecentEntriesDetailsInput input) {
     return userBehaviourService.getRecentEntries(input);
 }
// @QueryMapping
// public List<RecommendItemListResponse> getRecommendedEntries(@Argument("input") RecommendInput input) {
//     return userBehaviourService.getRecommendedEntries(input);
// }
 @QueryMapping
 public RecentViewedDetailsResponse getRecentViewedDetails(@Argument RecentEntriesDetailsInput input) {
     return userBehaviourService.getRecentViewedDetails(input);
 }
// @QueryMapping
// public RecentViewedDetailsResponse getRecommendDetails(@Argument  RecommendInput input ){
//	return  userBehaviourService.getRecommendDetails(input);
//}

 @PostMapping("/saveRecentView")
 @ResponseBody
 public String saveRecentViewDetails(@RequestBody RecentEntriesResponse recentEntriesResponse) throws JsonProcessingException {
   return userBehaviourService.saveRecentViewDetails(recentEntriesResponse);
 }
 @PostMapping("/register")
 public String registerAndNotify(@RequestBody RegisterDto registerDto) {
	 userBehaviourService.registerAndNotify(registerDto);
     return "Registration request submitted and notification queued!";
 }
}
