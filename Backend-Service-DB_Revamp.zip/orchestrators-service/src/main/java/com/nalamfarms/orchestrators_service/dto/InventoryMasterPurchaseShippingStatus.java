package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryMasterPurchaseShippingStatus {

	private Long shippingStatusId;

	private String shippingStatus;

	private LocalDateTime createdAt;

	private LocalDateTime modifiedAt;

	private Long createdBy;

	private Long modifiedBy;

	private Boolean isActive;

	private String description;

}
