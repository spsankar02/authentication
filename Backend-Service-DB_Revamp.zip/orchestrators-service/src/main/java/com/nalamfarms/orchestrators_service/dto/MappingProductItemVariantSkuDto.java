package com.nalamfarms.orchestrators_service.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MappingProductItemVariantSkuDto {
	
	private Long skuId;
	private String skuCode;
	private ItemSkuDto itemSkuDto;
//	private Long productOriginInfo;
	private BasketSkuDto basketSkuDto;
	private variantTypeSkuDto variantTypeSkuDto;
//	private WareHouseDto wareHouseDto;
//	private VendorDto vendorDto;
//	private Long rackId;
	

}
