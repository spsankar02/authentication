package com.nalamfarms.orchestrators_service.dto;

public class OrderServiceException extends RuntimeException{
  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * Constructs a new CartServiceException with the specified detail message.
   *
   * @param message the detail message
   */
  public OrderServiceException(String message) {
    super(message);
  }

  /**
   * Constructs a new CartServiceException with the specified detail message and cause.
   *
   * @param message the detail message
   * @param cause   the cause of the exception
   */
  public OrderServiceException(String message, Throwable cause) {
    super(message, cause);
  }

  /**
   * Constructs a new CartServiceException with the specified cause.
   *
   * @param cause the cause of the exception
   */
  public OrderServiceException(Throwable cause) {
    super(cause);
  }

}


