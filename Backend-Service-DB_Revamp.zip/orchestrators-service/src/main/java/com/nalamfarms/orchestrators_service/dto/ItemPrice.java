package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;

@Data
@RequiredArgsConstructor
public class ItemPrice {

	 private BigDecimal price;
	 private BigDecimal discount;
	 private BigDecimal realPrice;
	 private Boolean isDealItem;
	 private BigDecimal dealPrice;
	 private BigDecimal dealDiscount;
	 private String batchCode;

}
