package com.nalamfarms.orchestrators_service.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.nalamfarms.orchestrators_service.dto.NotificationRequestDto;


@Component
public class NotificationClient {


  @Value("${notification.service.url}")
  private String notificationServiceUrl;
  
  private static final Logger log = LoggerFactory.getLogger(NotificationClient.class);


  public void sendNotification(NotificationRequestDto notificationRequestDto) {
	  log.info("Sending notification: {}", notificationRequestDto.getNotification());
    WebClient webClient = WebClient.create(notificationServiceUrl);
    webClient.post()
      .uri("/api/notification/sendNotification")
      .bodyValue(notificationRequestDto) // Send notification as request body
      .retrieve()
      .bodyToMono(NotificationRequestDto.class)
      .block(); // Blocking for simplicity

  }
}
