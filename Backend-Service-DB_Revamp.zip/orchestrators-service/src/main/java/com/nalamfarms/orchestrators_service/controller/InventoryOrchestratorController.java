package com.nalamfarms.orchestrators_service.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.nalamfarms.orchestrators_service.dto.*;
import com.nalamfarms.orchestrators_service.dto.inventory.InvoiceDetailsPayload;
import com.nalamfarms.orchestrators_service.dto.inventory.InvoiceResponseDTO;
import com.nalamfarms.orchestrators_service.dto.inventory.PurchaseOrderRequest;
import com.nalamfarms.orchestrators_service.dto.inventory.QuotationDetailsDTO;
import com.nalamfarms.orchestrators_service.dto.inventory.ResponseDto;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.orchestrators_service.config.InventoryClient;
import com.nalamfarms.orchestrators_service.config.ProductClient;
import com.nalamfarms.orchestrators_service.dto.BasketSkuDto;
import com.nalamfarms.orchestrators_service.dto.ClassificationSkuDto;
import com.nalamfarms.orchestrators_service.dto.DemandQuotationResponse;
import com.nalamfarms.orchestrators_service.dto.FilteredOverviewResponse;
import com.nalamfarms.orchestrators_service.dto.InventoryTxnDemandDTO;
import com.nalamfarms.orchestrators_service.dto.InventoryTxnPurchaseOrder;
import com.nalamfarms.orchestrators_service.dto.ItemSkuDto;
import com.nalamfarms.orchestrators_service.dto.MappingProductItemVariantSkuDto;
import com.nalamfarms.orchestrators_service.dto.MoveInventoryResponse;
import com.nalamfarms.orchestrators_service.dto.MoveToInventoryRequest;
import com.nalamfarms.orchestrators_service.dto.ProductSkuDto;
import com.nalamfarms.orchestrators_service.dto.PurchaseMaster;
import com.nalamfarms.orchestrators_service.dto.PurchaseMasterDto;
import com.nalamfarms.orchestrators_service.dto.PurchaseOrderResponse;
import com.nalamfarms.orchestrators_service.dto.PurchaseOverviewFilterType;
import com.nalamfarms.orchestrators_service.dto.Quotation;
import com.nalamfarms.orchestrators_service.dto.QuotationItem;
import com.nalamfarms.orchestrators_service.dto.TxnInventoryPurchaseItem;
import com.nalamfarms.orchestrators_service.dto.TxnInventoryPurchaseItemsDTO;
import com.nalamfarms.orchestrators_service.dto.TxnInventoryQuotation;
import com.nalamfarms.orchestrators_service.dto.variantTypeSkuDto;
import com.nalamfarms.orchestrators_service.service.InventoryOrchestratorService;

@RestController
public class InventoryOrchestratorController {
	
	
	@Autowired
	private InventoryClient inventoryClient;
	
	@Autowired
	private ProductClient productClient;
	
	@Autowired
	private InventoryOrchestratorService inventoryOrchestratorService;
	
	
	@PostMapping(value = "/moveToInventory")
	private ResponseEntity<MoveInventoryResponse> moveToInventoryFromPurchase(
			@RequestBody List<MoveToInventoryRequest> moveToInventoryRequest) {
		MoveInventoryResponse moveToInventoryResponse = inventoryClient.moveToInventory(moveToInventoryRequest);
		if (!moveToInventoryResponse.isStatus())
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(moveToInventoryResponse);

		 MoveInventoryResponse saveMasterSkuPriceResponse = productClient.saveMasterSkuPrice(moveToInventoryRequest);
	        if (!saveMasterSkuPriceResponse.isStatus())
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(moveToInventoryResponse);
	        return ResponseEntity.status(HttpStatus.OK).body(new MoveInventoryResponse("Moved Sucessfully",true));

	}
	
	
	
	   @QueryMapping
	    public PagedResponse<InventoryTxnDemandDTO> getDemandList(
	            @Argument List<Long> demandId,
	            @Argument int page,
				@Argument int pageSize) {

	        return inventoryOrchestratorService.fetchDemandList(demandId, page,pageSize);
	    }


		/**DEMAND API**/
		@QueryMapping
		public List<PurchaseOrderResponse> getPOByDemandId(@Argument List<Long> demandIds) {

			return inventoryOrchestratorService.getPOByDemandId(demandIds);
		}


	   /**VENDOR CAPACITY DEMAND API**/
		@QueryMapping
		public List<DemandQuotationResponse> getVendorCapacityByDemandIds(@Argument List<Long> demandIds) {
			return inventoryOrchestratorService.getVendorCapacityByDemandIds(demandIds);

		}


	//@RequestBody InvoiceDetailsPayload invoiceDetailsPayload



	@PostMapping("/getInvoiceDetails")
	//public void getInvoiceDetails(@Argument Long demandId,@Argument int page,@Argument int pageSize) {
	public InvoiceResponseDTO getInvoiceDetails(@RequestBody InvoiceDetailsPayload invoiceDetailsPayload) {

		return inventoryClient.getInvoiceDetails(invoiceDetailsPayload.getDemandIds(), invoiceDetailsPayload.getPage(),
				invoiceDetailsPayload.getPageSize());
	}


	@QueryMapping
	public PagedResponse<QuotationDetailsDTO> getQuotationList(@Argument List<Long> quotationIds, @Argument List<Long> demandIds, @Argument int page, @Argument int pageSize) {

		return inventoryClient.getQuotationDetails(quotationIds,demandIds,page,pageSize);
	}
	
	@QueryMapping
	public PagedResponse<PurchaseOrderResponseDto> getInventoryByCategory(@Argument  List<String> categories, @Argument int page, @Argument int size) {
		return inventoryOrchestratorService.getInventoryByCategory(categories,page,size);
	}

	@QueryMapping
	public VendorDemandResponse getQuotationDemandItems(@Argument Long vendorId,@Argument Long demandId){
	return inventoryOrchestratorService.getDemandItemDetails(vendorId,demandId);
	}
	
	
	// Initiate Purchase Order and Generate QrPath.
	@PostMapping("/createPurchaseOrder")
	public ResponseDto createPurchaseOrder(@RequestBody PurchaseOrderRequest request) {
		return inventoryOrchestratorService.createPurchaseOrder(request);
	}
	
	@QueryMapping
	public List<DemandQuotationResponse> getDemandlistByVendor(@Argument List<Long> demandIds,@Argument Long vendorIds,@Argument Long actionType) {
			 return inventoryOrchestratorService.getDemandlistByVendor(demandIds,vendorIds,actionType);
		}
	
	@QueryMapping
	public InvoiceVendorSummaryResponse getInvoiceByVendorId(@Argument List<Long> demandIds,
			@Argument Long vendorIds) {
		return inventoryOrchestratorService.getInvoiceByVendorId(demandIds, vendorIds);

	}


}


