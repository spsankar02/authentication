package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreateOrderResponse {

	private String keyId;
	private String orderId;
	private Integer amountInPaise;
	private String currency;
	private String status;
	private String message;
	private String razorpaySubscriptionId;

	public CreateOrderResponse(String keyId, String orderId, Integer amountInPaise, String currency,String status,String message, String razorpaySubscriptionId) {
		this.keyId = keyId;
		this.orderId = orderId;
		this.amountInPaise = amountInPaise;
		this.currency = currency;
		this.status=status;
		this.message=message;
		this.razorpaySubscriptionId=razorpaySubscriptionId;
    }

}
