package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "member")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "member_id")
    private Long memberId;

    @Column(name = "firstname")
    private String firstname;

    @Column(name = "lastname")
    private String lastname;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "email_address")
    private String emailAddress;

    @OneToOne(optional = true)
    @JoinColumn(name = "referral_code_id")
    @JsonManagedReference
    private ReferralCode referralCodeId;

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "registered_by_org_id", referencedColumnName = "organization_id")
//    private Organization registeredByOrg;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt = LocalDateTime.now();

    @Column(name = "modified_by")
    private String modifiedBy;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "token")
    private String token;

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "member_group_id", referencedColumnName = "master_member_group_id")
//    private MasterMemberGroup memberGroup;


}
