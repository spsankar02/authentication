package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

@Data
public class ImageRequest {
	private String base64Image;
	private Long memberId;
}
