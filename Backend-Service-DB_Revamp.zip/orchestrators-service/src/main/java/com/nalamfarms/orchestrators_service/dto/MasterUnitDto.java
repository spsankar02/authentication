package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MasterUnitDto {

    private Long unitId;
    private String unitName;
    private Date createdAt;
    private boolean isActive;
    private String baseUnitName;
    private BigDecimal conversionFactorToBase;
}