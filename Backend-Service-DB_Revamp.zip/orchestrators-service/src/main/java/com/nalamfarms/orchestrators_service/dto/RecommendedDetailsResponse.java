package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import lombok.Data;

@Data
public class RecommendedDetailsResponse {
    private List<RecommendItemListResponse> recommenditemDetails;

}
