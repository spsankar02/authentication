package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;


import lombok.Data;

@Data
public class MappingItemSeasonalDTO {
	
	private Long seasonalItemId;
    private Long productId;
    private Long itemId;
    private String itemCode;
    private String seasonName;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private Boolean isActive;

}
