package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseMaster {

	private Long purchaseMasterId;

	private Long warehouseId;

	private Long vendorId;

	private String batchCode;

	private LocalDateTime purchaseDate;

	private Boolean invoiceGenerated;

	private Long shippingStatusId;

	private Boolean inventoryStatus;

	private Long certificateStatus;

	private Long quotationId;

	private DeliveryLocationStatus deliveryLocationStatus;

	private TxnInventoryQuotation quotation;

	private MasterInventoryCertificateStatus certificationStatus;
	
	private InventoryMasterPurchaseShippingStatus shippingStatus;
	
	private InventoryInvoice invoice;
	
	private PurchaseItem   purchaseItems;
	
	private PurchaseItemsDeliveryLocationDto deliveryLocation;
	
	private MasterCertificateType certificateType;

}
