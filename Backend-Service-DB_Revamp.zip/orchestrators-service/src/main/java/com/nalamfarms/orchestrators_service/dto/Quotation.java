package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Quotation {

	private Long id;

	private Long vendorId;

	private LocalDateTime quotationDate;

	private LocalDateTime expiryDate;

	private Double totalAmount;

	private MasterVendor masterVendor;

	private QuotationStatus status;

	private String quotationCode;

	private String country;

	private String city;

	private String state;

	private boolean active;
	
	private List<QuotationItem> items;

}
