package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name="master_subscription_days")
@Entity
public class MasterSubscriptionDays {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="days_id",unique=true,nullable=false)
	private Long daysId;

	@Column(name="day_name",nullable=false)
	private String dayName;

	@Column(name="created_at",nullable=false)
	private LocalDateTime createdAt=LocalDateTime.now();

	@Column(name="is_active",nullable=false)
	private boolean isActive=true;

}
