package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;


import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class BasketPrice {
  private Long basketPriceId;
  private Long basketId;
  private BigDecimal price;
  private BigDecimal discount;
  private BigDecimal realPrice;
  private Boolean isActive;
  private String batchCode;

}

