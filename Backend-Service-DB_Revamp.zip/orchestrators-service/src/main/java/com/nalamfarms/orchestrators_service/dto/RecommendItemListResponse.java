package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RecommendItemListResponse {
        @JsonProperty("item_id")
	    private String itemId;
        @JsonProperty("item_name")
	    private String itemName;
	    private int confidence;
}
