package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterInventoryWareHouse {

	private Long wareHouseId;

	private String wareHouseCode;

	private String name;

	private String location;

	private String pincode;

	private String phoneNumber;

	private String email;

	private Boolean status;

	private BigDecimal latitude;

	private BigDecimal longitude;

	private Long capacity;

	private String managerName;

	private String notes;

	private LocalDateTime createdAt;

	private LocalDateTime updatedAt;

	private Long createdBy;

	private Long modifiedBy;
}
