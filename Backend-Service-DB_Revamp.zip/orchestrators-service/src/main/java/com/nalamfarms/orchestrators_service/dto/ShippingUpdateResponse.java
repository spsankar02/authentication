package com.nalamfarms.orchestrators_service.dto;

public class ShippingUpdateResponse {

}
