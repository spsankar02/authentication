package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;


@Data
public class Basketprices {
    private Long basketPriceId;
    private Long basketId;
    private Long variantId;
    private Long variantTypeId;
    private BigDecimal price;
    private BigDecimal discount;
    private Date createdAt=new Date();
    private Date modifiedAt=new Date();
    @JsonProperty("isActive")
    private boolean isActive=true;
    private Long createdBy=1l;
    private Long modifiedBy;
    private BigDecimal realPrice;
    private String batchCode;

}
