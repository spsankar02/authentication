package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder 
public class CartServiceResult {
	private Long cartId;
	private Boolean cartIsActive;
	private Boolean saveStatus;
	private Integer quantity;
	private BigDecimal priceAtAdd;
	private BigDecimal discountAtAdd;
	private String type;
	private Boolean isOfferItem;
	private Long skuId;
	private Long itemId;
	private String itemName;
	private String imageUrl;
	private String itemCode;
	private Boolean isActive;
	private Product product;
	private Long basketId;
	private String basketName;
	private Boolean upcoming;
	private String description;
	private String basketCode;
	private List<VariantList> variantLists;
	private boolean isSubscribed;
}
