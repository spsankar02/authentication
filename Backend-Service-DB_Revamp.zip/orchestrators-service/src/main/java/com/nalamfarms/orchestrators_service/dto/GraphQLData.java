package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import com.nalamfarms.orchestrators_service.dto.payment.PaymentSummary;
import org.springframework.data.domain.Page;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nalamfarms.orchestrators_service.dto.inventory.QuotationDetailsDTO;

import lombok.Data;

@Data
public class GraphQLData {
    private List<ItemListResponse> getItemsByProductId;
    private ItemListResponse getItemDetails;
    private List<ItemListResponse> getDealOfTheWeekByProducts;
    private BasketDetailsResponse getBasketDetails;
    private BasketDetailsResponse getBasketDetilsByBasketId;
    private List<ItemListResponse> getItemSearch;
    private List<AllBasketDetails>  getAllBaskets;
    private List<BasketDetailsResponse> getSimilarBaskets;
    private List<BasketDetailsResponse> getSuggestionBaskets;
    private List<AllBasketDetails>  getItemBasketSearch;
    private List<ItemListResponse> getItemsListBySeasonal;
    private List<OrderItem> getOrderItemDetails ;
    private List<TxnInventoryPurchaseItem> getPurchaseDetails;
    private List<MappingProductItemVariantSkuDto> getItemsOrBasketDetailsBySkuId;
    private FilteredOverviewResponse filterPurchaseOverview;
    private List<InventoryInput> getRecentInventory;


    //@JsonProperty("getShippingDetailsByShippingId")
    private ShippingDto shippingDetailsByShippingId;
    private List<Quotation> getAllQuotations;
    private List<InventoryTxnPurchaseOrder>getPurchaseOrdersByIds;
    private List<TxnInventoryQuotation> getQuotationByPurchaseOrdersIds;
    private PurchaseMasterDto getPurchaseMasterByQuotationId;
    private List<Order> filterOrders;
    private List<MasterSkuPrice> getSkuMasterSkuPrice;
    private List<SubscriptionPlansDTO> filterSubscription;
    private List<MappingBasketItemsDto> getBasketItemsList;
    private PagedResponse<InventoryTxnDemandDTO> getDemandList;
    private List<PurchaseOrderResponse> getPOByDemandId;
    private List<DemandQuotationResponse> getVendorCapacityByDemandIds;
    private PagedResponse<QuotationDetailsDTO> getQuotationList;
    private PagedResponse<PurchaseOrderResponseDto> getInventoryByCategory;
    private VendorDemandResponse getQuotationDemandItems;
    private List<DemandQuotationResponse> getDemandlistByVendor;
    private InvoiceVendorSummaryResponse getInvoiceByVendorId;
    private PaymentSummary adminPaymentsSummary;
    @JsonProperty("getFilterPayments")
    private PagedResponse<PaymentDetailsDto> filterPayments;

}
