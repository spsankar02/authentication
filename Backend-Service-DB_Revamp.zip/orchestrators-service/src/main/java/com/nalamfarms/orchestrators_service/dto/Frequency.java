package com.nalamfarms.orchestrators_service.dto;

public enum Frequency {
    WEEKLY, MONTHLY
}
