package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Table(name="master_subscription_delivery_time_slot")
@Entity
public class MasterSubscriptionDeliveryTimeSlot {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="time_slot",nullable = false,unique=true)
	private Long timeSlot;
	
	@Column(name="slot_name",nullable = false)
	private String slotName;
	
	@Column(name="start_time",nullable = false)
	private LocalDateTime startTime;
	
	@Column(name="end_time",nullable = false)
	private LocalDateTime EndTime;
	
	@Column(name="created_at",nullable = false)
	private LocalDateTime CreatedAt=LocalDateTime.now();
	
	@Column(name="is_active",nullable = false)
	private boolean isActive=true;

}

