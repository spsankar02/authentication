package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryTxnPurchaseOrder {

	private Long purchaseOrderId;

	private Long skuId;

	private LocalDateTime createdDate;

	private LocalDateTime modifiedDate;

	private Boolean isActive;

	private String skuCode;

	private Long itemId;

	private Long productId;

	private Long classificationId;

	private String itemCode;

	private String productCode;

	private String classificationCode;

	private Long variantTypeId;

	private String variantTypeCode;

	private String itemName;

	private String classificationName;

	private String productName;

	private String variantTypeName;
	
	private MasterInventoryWareHouse warehouse;
	
	private Long quantity;
	
    private String description;
    
    private String purchaseOrderCode;
   
    private String purchaseOrderDate;
    
    private Long basketId;
    
    private String basketName;
    
    private String basketCode;
    
    private Boolean quotationApproved;


}
