package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class DeleteCartRequestDto {
  private Long cartId;
  private Long memberId;
  private Long status;
}
