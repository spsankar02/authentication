package com.nalamfarms.orchestrators_service.config;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;
import graphql.schema.GraphQLScalarType;

public class LocalDateTimeScalar {

	public static final GraphQLScalarType LOCAL_DATE_TIME = GraphQLScalarType.newScalar()
	        .name("LocalDateTime")
	        .description("Custom scalar for Java LocalDateTime (ISO format)")
	        .coercing(new Coercing<LocalDateTime, String>() {

	            private final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

	            @Override
	            public String serialize(Object dataFetcherResult) {
	                if (dataFetcherResult instanceof LocalDateTime) {
	                    return ((LocalDateTime) dataFetcherResult).format(formatter);
	                } else if (dataFetcherResult instanceof String) {
	                    // Attempt to parse the string (if already serialized)
	                    try {
	                        return LocalDateTime.parse((String) dataFetcherResult, formatter).format(formatter);
	                    } catch (Exception e) {
	                        throw new CoercingSerializeException("Invalid LocalDateTime string: " + dataFetcherResult);
	                    }
	                }
	                throw new CoercingSerializeException("Unable to serialize object as LocalDateTime: " + dataFetcherResult);
	            }

	            @Override
	            public LocalDateTime parseValue(Object input) {
	                try {
	                    return LocalDateTime.parse(input.toString(), formatter);
	                } catch (Exception e) {
	                    throw new CoercingParseValueException("Invalid LocalDateTime input: " + input);
	                }
	            }

	            @Override
	            public LocalDateTime parseLiteral(Object input) {
	                try {
	                    return LocalDateTime.parse(input.toString(), formatter);
	                } catch (Exception e) {
	                    throw new CoercingParseLiteralException("Invalid LocalDateTime literal: " + input);
	                }
	            }
	        })
	        .build();
	}


