package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryInvoice {

	private Long invoiceId;

	private String invoiceNumber;

	private BigDecimal totalAmount;

	private LocalDateTime invoiceDate;

	private Long invoiceStatusId;

	private MasterInventoryInvoiceStatus masterInventoryInvoiceStatus;

}
