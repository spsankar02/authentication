package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
public class RegisterDto {
  private String phoneNumber;
  private String firstname;
  private String lastname;
  private String emailAddress;
  private List<Long> allergies;
  private String token;


}
