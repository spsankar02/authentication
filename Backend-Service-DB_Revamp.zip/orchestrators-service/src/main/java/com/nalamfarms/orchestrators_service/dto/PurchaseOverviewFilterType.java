package com.nalamfarms.orchestrators_service.dto;

public enum PurchaseOverviewFilterType {
	STOCK_MOVEMENT_PENDING, INVOICE_PENDING, CERTIFICATE_APPROVE_PENDING, STOCK_MOVEMENT_COMPLETED

}
