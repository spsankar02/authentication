package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;
import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PaymentDetailsDto {
  private Long paymentsId;
  private Long memberId;
  private Long orderId;
  private String paymentType;
  private Long subscriptionId;
  private String transactionId;
  private Double amount;
  private String currency;
  private PaymentStatusDto paymentStatus;
  private String paymentGateway;
  private String paymentMode;
  private LocalDateTime paymentTime;
  private LocalDateTime createdAt;
  private LocalDateTime modifiedAt;
  private Long createdBy;
  private Long modifiedBy;
  private Boolean active;
  private String razorpayOrderId;
  private String razorpayPaymentId;
  private String razorpayStatus;
  private Double refundAmount;
  private String razorPayRefundId;
  private List<OrderBasketItemDetails> orderItems;
  private MemberDetailsDto memberDetails;

}
