package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
 public class DemandItemDTO {
    private Long demandItemId;
    private Long skuId;
    private BigDecimal quantity;
    private LocalDateTime createdAt;
    private MappingProductItemVariantSkuDto skuDetails;

}