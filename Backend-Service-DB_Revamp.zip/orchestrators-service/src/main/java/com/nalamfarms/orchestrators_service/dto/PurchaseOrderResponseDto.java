package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderResponseDto {
	private String purchaseOrderCode;
	private Long purchaseOrderId;
	private Long demandId;
	private LocalDateTime purchaseOrderDate;
    private MasterVendor vendor;
    private List<PurchaseOrderItemDTO> purchaseOrderItems;
}
