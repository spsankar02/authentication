package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

@Data
public class MasterOfferType {
	private Long offerTypeId;
    private String type;
    private String description;
    private Boolean isActive;	
}
