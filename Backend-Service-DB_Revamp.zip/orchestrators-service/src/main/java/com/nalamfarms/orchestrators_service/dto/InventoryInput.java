package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class InventoryInput {
    private Long inventoryId;
    private BigDecimal quantityAvailable;
    private BigDecimal quantityReserved;
    private Long skuId;
    private String batchCode;
    private BigDecimal stockQuantity;
}
