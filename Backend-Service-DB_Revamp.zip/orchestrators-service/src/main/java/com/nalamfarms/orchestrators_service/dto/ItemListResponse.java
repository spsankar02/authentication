package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemListResponse {

	private Long itemId;
	private String itemName;
	private String itemCode;
	@JsonProperty("active")
	private boolean active;
	private Product products;
	private Long productId;
	private String image;
	private List<String> imageUrl;
	private List<VariantListItem> variantListItem;
	private List<MasterVendor> itemVendors;
	private MappingItemSeasonalDTO mappingItemSeasonal;
	private MappingItemDealsResponseDTO mappingItemDeals;
}
