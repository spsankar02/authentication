package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuotationItemsOriginInfoDTO {
	private Long purchaseItemOriginInfoId;
	private String city;
	private String state;
	private String country;
	private String itemInfo;

}
