package com.nalamfarms.orchestrators_service.dto;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class OrderDetailsRequest {
    private JsonNode paymentJsonNode;
    private List<OrderItem> orderItem;
    private Map<Long, JsonNode> itemDetailsMap;
    private Map<Long, JsonNode> basketDetailsMap;
    private MemberAddressDto deliveryAddress;
}
