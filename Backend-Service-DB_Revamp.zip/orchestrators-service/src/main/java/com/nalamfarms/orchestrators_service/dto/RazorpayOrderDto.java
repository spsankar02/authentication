package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RazorpayOrderDto {
	private String id;
    private String entity;
    private Integer amount;
    @JsonProperty("amount_paid")
    private Integer amountPaid;
    @JsonProperty("amount_due")
    private Integer amountDue;
    private String currency;
    private String receipt;
    private String status;
    private Integer attempts;
    private Object notes;
    @JsonProperty("created_at")
    private Object createdAt;

}
