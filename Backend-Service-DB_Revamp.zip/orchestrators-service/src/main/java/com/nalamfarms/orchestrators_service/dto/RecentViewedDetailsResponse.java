package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import lombok.Data;

@Data
public class RecentViewedDetailsResponse {
    private List<ItemListResponse> itemDetails;
    private List<BasketDetailsResponse> basketDetails;
}
