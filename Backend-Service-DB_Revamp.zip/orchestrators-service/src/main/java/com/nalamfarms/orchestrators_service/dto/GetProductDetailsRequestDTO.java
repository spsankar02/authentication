package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;


@Data
@RequiredArgsConstructor
public class GetProductDetailsRequestDTO {
  private String type;
  private List<BasketInput> itemInput;
  private List<BasketInput> basketInput;
  private Long memberId;
}

