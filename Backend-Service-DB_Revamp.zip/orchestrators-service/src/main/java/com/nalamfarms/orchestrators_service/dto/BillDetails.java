package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillDetails {
	private BigDecimal itemTotal;
    private BigDecimal totalSaving;
    private BigDecimal deliveryCharge;
    private BigDecimal handlingCharge;
    private BigDecimal grandTotal;
    private BigDecimal cartGrandTotal;
    private BigDecimal creditPointAmount;
    private int totalCreditPoints;
    private List<String> cartMessages;

}
