package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class AddToCartRequest {
	private Long memberId;
	private Long productId;
	private Integer quantity;
	private BigDecimal priceAtAdd;
	private BigDecimal discountAtAdd;
	private String type;
	private Boolean isOfferItem;
	private BigDecimal dealPrice;
	private BigDecimal dealDiscount;
	private Boolean isDealItem;
	private Long skuId;
}
