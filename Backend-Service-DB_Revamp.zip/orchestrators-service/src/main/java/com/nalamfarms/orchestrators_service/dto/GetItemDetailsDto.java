package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import lombok.Data;

@Data
public class GetItemDetailsDto {
	
	  private int itemId;
	  private String itemName;
	  private String itemCode;
	  private String productId; // nullable
	  private String image;
	  private List<String> imageUrl;
	  private Product products;
	  private List<VariantListItemDto> variantListItem;

}
