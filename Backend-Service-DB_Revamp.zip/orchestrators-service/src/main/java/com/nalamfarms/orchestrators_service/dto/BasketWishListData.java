package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BasketWishListData {
    private Long basketId;
    private String basketCode;
    private String basketName;
    private String imageUrl;
    private double rating;
    private List<VariantList> variantLists;
}
