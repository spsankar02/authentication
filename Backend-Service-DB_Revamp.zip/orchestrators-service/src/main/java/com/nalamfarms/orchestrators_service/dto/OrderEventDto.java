package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class OrderEventDto {
  private Long orderId;
  private Long memberId;
  private BigDecimal subTotal;
  private BigDecimal discountAmount;
  private BigDecimal taxAmount;
  private BigDecimal grandTotal;
  private String orderStatus;
  private String paymentStatus;
  private String paymentMethod;
  private BigDecimal deliveryCharge;
  private BigDecimal surCharge;
  private Integer rewardSpentPoints;
  private BigDecimal rewardSpentAmount;
  private BigDecimal transactionAmount;
  private List<OrderItem> items;
  private String customerOrderId;
  private String eventStatus;
  private String razorPayPaymentId;
  private String razorPayOrderId;
  private String currencyType;
  private String paymentGateway;
  private String razorPayStatus;

  public OrderEventDto(Order order, List<OrderItem> items) {
    System.out.println("items+------->"+items);
    this.orderId = order.getOrderId();
    this.memberId = order.getMemberId();
    this.subTotal = order.getSubTotal();
    this.discountAmount = order.getDiscountAmount();
    this.taxAmount = order.getTaxAmount();
    this.grandTotal = order.getGrandTotal();
    this.orderStatus = order.getOrderStatus()!=null?order.getOrderStatus().getStatusName():null;
    this.paymentStatus = order.getPaymentStatus();
    this.paymentMethod = order.getPaymentMethod();
    this.deliveryCharge = order.getDeliveryCharge();
    this.surCharge = order.getSurCharge();
    this.rewardSpentPoints = order.getRewardSpentPoints();
    this.rewardSpentAmount = order.getRewardSpentAmount();
    this.transactionAmount = order.getTransactionAmount();
    this.customerOrderId=order.getCustomOrderId();

    this.items = items.stream()
      .map(item -> new OrderItem(
    	item.getSkuId(),
        item.getQuantity(),
        item.getPricePerUnit(),
        item.getDiscountPerUnit(),
        item.getTotalPrice(),
        item.getType(),
        item.getDealPrice(),
        item.getDealDiscount(),
        item.getIsOfferItem(),
        item.getBatchCode()))
      .toList();
  }




}
