package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartDTO {
	private Long cartId;
    private Long memberId;

    private Integer quantity;
    private BigDecimal priceAtAdd;
    private Integer type;
    @JsonProperty("isActive")
    private Boolean isActive;
    private Integer saveStatus=1;
    private BigDecimal discountAtAdd;
    private BigDecimal dealPrice;
    private BigDecimal dealDiscount;
    private Boolean isOfferItem;
    private Long mappingOfferId;
    private Long offerId;
    private boolean isSubscribed=false;
    private Long skuId;
    
    
    

}
