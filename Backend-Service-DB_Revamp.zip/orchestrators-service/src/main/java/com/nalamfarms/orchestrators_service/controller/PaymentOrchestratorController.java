package com.nalamfarms.orchestrators_service.controller;
 
import java.util.List;
import java.util.stream.Collectors;
 
import com.nalamfarms.orchestrators_service.dto.*;
import com.nalamfarms.orchestrators_service.dto.payment.PaymentSummary;
import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nalamfarms.orchestrators_service.service.InventoryOrchestratorService;
import com.nalamfarms.orchestrators_service.service.OrderOrchestratorService;
import com.nalamfarms.orchestrators_service.service.PaymentOrchestratorService;
import com.nalamfarms.orchestrators_service.util.RazorpaySignature;
//import com.nalamfarms.order_service.serviceimpl.OrderServiceImplementation;
import com.razorpay.RazorpayClient;
 
 
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/payments/orchestrator")
public class PaymentOrchestratorController {
    

//    @Autowired
//    private PaymentOrchestratorService paymentOrchestratorService;
//
//    @Autowired
//    private OrderOrchestratorService orderOrchestratorService;
//
//    @Autowired
//    private  KafkaTemplate<String, Object> kafkaTemplate;
//
//    @Autowired
//    private InventoryOrchestratorService inventoryOrchestrator;
//
//    @Autowired
//    private ObjectMapper objectMapper;

    private final PaymentOrchestratorService paymentOrchestratorService;


    @PostMapping("/create-order")
    public ResponseEntity<?> createOrder(
            @RequestBody @Validated CreateOrderRequest req) {
//        try {
//            Order order = orderOrchestratorService.getOrderDetailsByOrderId(Long.valueOf(req.getReceipt()));
//
//            List<WishListRequest> requestList = order.getOrderItem().stream().map(orderItem -> {
//                WishListRequest request = new WishListRequest();
//                request.setSkuId(orderItem.getSkuId());
//                request.setBatchCode(orderItem.getBatchCode());
//                request.setQuantity(orderItem.getQuantity());
//                return request;
//            }).collect(Collectors.toList());
//
//            SaveResponse inventoryQuantityResponse = inventoryOrchestrator.checkInventoryQuantity(requestList);
//            CreateOrderResponse response=null;
//            if (!inventoryQuantityResponse.isAvailable()) {
//                 response = new CreateOrderResponse(null, null, null, null, "Failure",
//                        inventoryQuantityResponse.getMessage());
//                 return new ResponseEntity<>(response, HttpStatus.UNPROCESSABLE_ENTITY);
//            }
//
//            JSONObject orderRequest = new JSONObject();
//            orderRequest.put("amount", req.getAmountInPaise());
//            orderRequest.put("currency", req.getCurrency());
//            orderRequest.put("receipt", req.getReceipt());
//            orderRequest.put("payment_capture", 1);
//
//
//            com.razorpay.Order RazorPayOrder = client.orders.create(orderRequest);
//
//             response = new CreateOrderResponse(keyId, RazorPayOrder.get("id"),
//                    RazorPayOrder.get("amount"), RazorPayOrder.get("currency"),"Success","Order Created Successfuly");
//
//            paymentOrchestratorService.savePaymentDetails(req, RazorPayOrder);
//
//            return new ResponseEntity<>(response, HttpStatus.OK);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body("Error creating order: " + e.getMessage());
//        }
 
        return paymentOrchestratorService.savePaymentDetails(req);
    }
 
    
    @PostMapping("/verifyPayment")
    public ResponseEntity<?> verifyPayment(@RequestBody @Validated VerifyPaymentRequest req) {
//        try {
//
//            boolean isSignatureValid = RazorpaySignature.verifyPaymentSignature(req.getRazorpayOrderId(),
//                    req.getRazorpayPaymentId(), req.getRazorpaySignature(), razorpaySecret);
//
//            PaymentDetailsDto paymentDetails = paymentOrchestratorService
//                    .getPaymentDetailsByRazorpay(req.getRazorpayOrderId());
//
//            System.out.println("Payment Details Orchestration are:" + paymentDetails);
//
//            if (paymentDetails == null || paymentDetails.getOrderId() == null) {
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                        .body(new VerifyPaymentResponse(false, "Invalid Razorpay OrderId"));
//            }
//
//            Order order = orderOrchestratorService.getOrderDetailsByOrderId(paymentDetails.getOrderId());
//            if (order == null) {
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
//                        .body(new VerifyPaymentResponse(false, "Order not found"));
//            }
//
//            OrderEventDto orderEvent = new OrderEventDto(order, order.getOrderItem());
//            orderEvent.setRazorPayPaymentId(req.getRazorpayPaymentId());
//            orderEvent.setRazorPayOrderId(req.getRazorpayOrderId());
//            if (!isSignatureValid) {
//                logger.info("Payment Success for OrderId={} MemberId={}", order.getOrderId(), order.getMemberId());
//
//                orderEvent.setEventStatus("Payment.Sucess");
//
//                String orderEventJson = objectMapper.writeValueAsString(orderEvent);
//                kafkaTemplate.send("payment.status.updated", orderEventJson);
//                kafkaTemplate.send("inventory.reserved", orderEventJson);
//
//                return ResponseEntity.ok(new VerifyPaymentResponse(true, "Payment verified successfully"));
//            } else {
//                logger.info("Payment Failed for OrderId={} MemberId={}", order.getOrderId(), order.getMemberId());
//                orderEvent.setEventStatus("Payment.Failure");
//                String orderEventJson = objectMapper.writeValueAsString(orderEvent);
//                kafkaTemplate.send("payment.status.updated", orderEventJson);
//                kafkaTemplate.send("order.cancelled", orderEventJson);
//
//                return ResponseEntity.ok(new VerifyPaymentResponse(false, "Invalid payment signature"));
//            }
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//                    .body(new VerifyPaymentResponse(false, "Error: " + e.getMessage()));
//        }
 
        return paymentOrchestratorService.getPaymentDetailsByRazorpay(req);
    }


    @QueryMapping
    public PagedResponse<PaymentDetailsDto> getFilterPayments(  @Argument int page,
                                                                @Argument int pageSize,
                                                                @Argument String startDate,
                                                                @Argument String endDate,
                                                                @Argument List<Long> paymentStatusIds,
                                                                @Argument  List<Long> orderIds) {
        return paymentOrchestratorService.getFilterPayments(page,pageSize,startDate,endDate,paymentStatusIds,orderIds);
    }

    @QueryMapping
    public PaymentSummary adminPaymentsSummary()
    {
        return  paymentOrchestratorService.adminPaymentsSummary();
    }
}