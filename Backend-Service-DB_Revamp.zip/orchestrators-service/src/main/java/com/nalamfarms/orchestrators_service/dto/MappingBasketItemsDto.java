package com.nalamfarms.orchestrators_service.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MappingBasketItemsDto {

    private Long mapBasketItemId;
    private Long basketId;
    private Long productId;
    private Long itemId;
    private Integer size;
    private Integer unitId;
    private Long variantTypeId;
    private Long createdBy;
    private Long modifiedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createdAt;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date modifiedAt;
    private boolean isActive;

    // Nested DTOs for related entities
    private Baskets baskets;
    private Product product;
    private Item item;
    private MasterUnitDto masterUnit;
}