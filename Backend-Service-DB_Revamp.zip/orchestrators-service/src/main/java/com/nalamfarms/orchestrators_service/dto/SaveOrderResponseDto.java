package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

import java.util.List;

@Data
public class SaveOrderResponseDto {
  private Order order;
  private List<OrderSaveRequestDto> orderSaveRequestDto;
}
