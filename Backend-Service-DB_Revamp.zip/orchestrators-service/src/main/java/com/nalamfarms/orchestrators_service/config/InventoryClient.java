package com.nalamfarms.orchestrators_service.config;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.nalamfarms.orchestrators_service.dto.*;
import com.nalamfarms.orchestrators_service.dto.inventory.*;
import com.nalamfarms.orchestrators_service.query.InventoryOrchestratorQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.nalamfarms.orchestrators_service.query.InventoryOrchestratorQuery;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class InventoryClient {
	private final WebClient.Builder webClientBuilder;
	@Value("${inventory.service.url}")
	private String inventoryServiceUrl;

	@Autowired
	ProductClient productClient;

	private static final Logger log = LoggerFactory.getLogger(InventoryClient.class);

	@CircuitBreaker(name = "inventoryServiceCircuitBreaker", fallbackMethod = "fallbackCheckInventory")
	public SaveResponse checkInventory(WishListRequest request) {
		return webClientBuilder.build().post().uri(inventoryServiceUrl + "/inventory/checkQuantityInInventory")
				.bodyValue(request).retrieve().bodyToMono(SaveResponse.class).block();
	}
	
	public SaveResponse checkInventoryQuantity(List<WishListRequest> requestList) {
		return webClientBuilder.build().post().uri(inventoryServiceUrl + "/inventory/checkQuantity")
				.bodyValue(requestList).retrieve().bodyToMono(SaveResponse.class).block();

	}


	public SaveResponse fallbackCheckInventory(WishListRequest request, Throwable t) {
		log.error("Fallback for checkInventory triggered due to {}", t.toString());
		return new SaveResponse(t.toString(), false, BigDecimal.ZERO);
	}

	public MoveInventoryResponse moveToInventory(List<MoveToInventoryRequest> moveToInventoryRequest) {
		return webClientBuilder.build().post().uri(inventoryServiceUrl + "/inventory/moveToInventory")
				.bodyValue(moveToInventoryRequest).retrieve().bodyToMono(MoveInventoryResponse.class).block();
	}

	
	public List<InventoryInput> getRecentInventory(List<Long> skuIds) {
		// Format the GraphQL query
		String formattedSkuIds = skuIds.toString(); // [101, 102] → same as in your other method

		String query = InventoryOrchestratorQuery.getRecentInventoryQuery(formattedSkuIds);
		// Prepare request body
		Map<String, String> requestBody = Map.of("query", query);

		try {
			// Call the GraphQL endpoint
			GraphQLResponse response = webClientBuilder.build()
					.post()
					.uri(inventoryServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(requestBody)
					.retrieve()
					.bodyToMono(GraphQLResponse.class)
					.block();

			// Return parsed response (adapt to your DTO class)
			return response != null ? response.getData().getGetRecentInventory() : null;

		} catch (WebClientResponseException e) {
			e.printStackTrace();
			throw new RuntimeException("GraphQL call failed for skuIds: " + skuIds, e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Unexpected error for skuIds: " + skuIds, e);
		}
	}

	public ResponseEntity<?> generateQrPath(PurchaseMaster purchaseMasterResponse) {
		return webClientBuilder.build().post()
		.uri(inventoryServiceUrl + "/inventory/updateQrPath")
	     .bodyValue(purchaseMasterResponse).retrieve()
	     .toBodilessEntity()
	     .block();
		
	}

	public PagedResponse<InventoryTxnDemandDTO> fetchDemandList(List<Long> demandIds, int page, int pageSize) {
	    String graphqlQuery =InventoryOrchestratorQuery.fetchDemandListQuery(demandIds.size()>0? true :false);
	    Map<String, Object> variables = new HashMap<>();
	    variables.put("demandId", demandIds == null || demandIds.isEmpty() ? null : demandIds);
	    variables.put("page", page);
		variables.put("pageSize", pageSize);

	    Map<String, Object> requestBody = new HashMap<>();
	    requestBody.put("query", graphqlQuery);
	    requestBody.put("variables", variables);

	    GraphQLResponse response = webClientBuilder.build()
	            .post()
	            .uri(inventoryServiceUrl + "/graphql")
	            .contentType(MediaType.APPLICATION_JSON)
	            .bodyValue(requestBody)
	            .retrieve()
	            .bodyToMono(new ParameterizedTypeReference<GraphQLResponse>() {})
	            .block();

	    // Return parsed response
	    return response != null && response.getData() != null
	            ? response.getData().getGetDemandList()
	            : null;
	}
public List<PurchaseOrderResponse> getPurchaseOrdersByDemandIds(List<Long> demandIds) {


		String query=InventoryOrchestratorQuery.getPurchaseOrdersByDemandIds(demandIds);
		
	    Map<String, Object> variables = Map.of("demandIds", demandIds);
	    Map<String, Object> requestBody = Map.of(
	            "query", query,
	            "variables", variables
	    );
		
		GraphQLResponse response = webClientBuilder.build().post().uri(inventoryServiceUrl + "/graphql")
				.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
				.bodyToMono(GraphQLResponse.class).block();

		if (response != null && response.getData() != null) {
			return response.getData().getGetPOByDemandId();
		} else {
			return Collections.EMPTY_LIST;
		}

		
		
	}
public List<DemandQuotationResponse> getVendorCapacityByDemandIds(List<Long> demandIds) {
	String query = InventoryOrchestratorQuery.getVendorCapacityByDemandIds(demandIds);
	Map<String, Object> variables = Map.of("demandIds", demandIds);
	Map<String, Object> requestBody = Map.of("query", query, "variables", variables);

	GraphQLResponse response = webClientBuilder.build().post().uri(inventoryServiceUrl + "/graphql")
			.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
			.bodyToMono(GraphQLResponse.class).block();

	if (response != null && response.getData() != null) {
		return response.getData().getGetVendorCapacityByDemandIds();
	} else {
		return Collections.EMPTY_LIST;
	}

	}

public InvoiceResponseDTO getInvoiceDetails(List<Long> demands, int page, int pageSize) {
	 
    Map<String, Object> requestBody = new HashMap<>();
    requestBody.put("demandIds", demands);
    requestBody.put("page", page);
    requestBody.put("pageSize", pageSize);
 
    InvoiceResponseDTO response = webClientBuilder.build()
            .post()
            .uri(inventoryServiceUrl + "/inventory/getInvoiceDetails")
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(requestBody)
            .retrieve()
            .bodyToMono(InvoiceResponseDTO.class)
            .block();
 
    List<Long> skuIds = response.getContent().stream()
            .flatMap(invoice -> invoice.getItems().stream())
            .map(InvoiceItemDTO::getSkuId)
            .distinct()
            .collect(Collectors.toList());
 
    System.out.println("All skuIds from invoices: " + skuIds);
 
    List<MappingProductItemVariantSkuDto> skuDtos =
            productClient.getItemsOrBasketDetailsBySkuId(Collections.emptyList(), skuIds);
 
    System.out.println("SkuIds from productClient: " +
            skuDtos.stream().map(MappingProductItemVariantSkuDto::getSkuId).collect(Collectors.toList()));
 
    Map<Long, MappingProductItemVariantSkuDto> skuMap = skuDtos.stream()
            .collect(Collectors.toMap(MappingProductItemVariantSkuDto::getSkuId, dto -> dto));
 
    List<InvoiceDTO> enrichedInvoices = response.getContent().stream()
            .map(invoice -> {
                List<InvoiceItemDTO> enrichedItems = invoice.getItems().stream()
                        .map(item -> {
                            item.setSkuDetails(skuMap.get(item.getSkuId()));
                            return item;
                        })
                        .collect(Collectors.toList());
 
                invoice.setItems(enrichedItems);
                return invoice;
            })
            .collect(Collectors.toList());
 
    response.setContent(enrichedInvoices);
 
    return response;
}

public PagedResponse<QuotationDetailsDTO> getQuotationDetails(
        List<Long> quotationIds, 
        List<Long> demandIds, 
        int page, 
        int pageSize) {

    String query = InventoryOrchestratorQuery.getQuotationListQuery();
    Map<String, Object> variables = Map.of(
            "demandIds", demandIds,
            "quotationIds", quotationIds,
            "page", page,
            "pageSize", pageSize
    );

    Map<String, Object> requestBody = Map.of("query", query, "variables", variables);

    GraphQLResponse response = webClientBuilder.build()
            .post()
            .uri(inventoryServiceUrl + "/graphql")
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(requestBody)
            .retrieve()
            .bodyToMono(GraphQLResponse.class)
            .block();

    if (response == null || response.getData() == null) {
        return null;
    }

    PagedResponse<QuotationDetailsDTO> inventoryPagedResponse = response.getData().getGetQuotationList();
    if (inventoryPagedResponse == null || inventoryPagedResponse.getContent() == null) {
        return inventoryPagedResponse;
    }

    List<Long> skuIds = inventoryPagedResponse.getContent().stream()
            .filter(q -> q.getDemand() != null && q.getDemand().getDemandItems() != null)
            .flatMap(q -> q.getDemand().getDemandItems().stream())
            .map(DemandQuotationResponse.DemandItemDTO::getSkuId)
            .distinct()
            .collect(Collectors.toList());

    List<MappingProductItemVariantSkuDto> skuDtos = productClient.getItemsOrBasketDetailsBySkuId(Collections.emptyList(), skuIds);

 // 4. Build lookup map for SKU
    Map<Long, MappingProductItemVariantSkuDto> productMap = skuDtos.stream()
            .collect(Collectors.toMap(MappingProductItemVariantSkuDto::getSkuId, Function.identity()));

    
    inventoryPagedResponse.getContent().forEach(q -> {
    	q.setSkuDetails(productMap.get(q.getSkuId()));
        if (q.getDemand() != null && q.getDemand().getDemandItems() != null) {
            q.getDemand().getDemandItems().forEach(demandItem -> {
                MappingProductItemVariantSkuDto skuDetail = skuDtos.stream()
                        .filter(s -> s.getSkuId().equals(demandItem.getSkuId()))
                        .findFirst()
                        .orElse(null);
                demandItem.setSkuDetails(skuDetail);

                if (demandItem.getVendors() == null) {
                    demandItem.setVendors(new ArrayList<>());
                }
            });
        }
    });

    return inventoryPagedResponse;
}


	public PagedResponse<PurchaseOrderResponseDto> getInventoryByCategory(List<String> categories, int page, int size) {

		String query = InventoryOrchestratorQuery.getInventoryByCategory();
		Map<String, Object> variables =
				Map.of("categories", categories,
						"page", page,
						"size", size);

		Map<String, Object> requestBody = Map.of("query", query, "variables", variables);
		try
		{

		GraphQLResponse response = webClientBuilder.build().post().uri(inventoryServiceUrl + "/graphql")
				.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
				.bodyToMono(GraphQLResponse.class).block();

		if (response != null && response.getData() != null) {
			return response.getData().getGetInventoryByCategory();
		} else {
			return null;
		} 
		}
		catch (WebClientResponseException e) {
			e.printStackTrace();
			throw new RuntimeException("GraphQL call failed for skuIds: "+ e);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Unexpected error for skuIds: " +  e);
		}
	}

	 public VendorDemandResponse getDemandItemDetails(Long vendorId, Long demandId) {
		    String query = InventoryOrchestratorQuery.GetDemandItemDetails(vendorId,demandId); // query string builder
		    
		    Map<String, Object> variables = Map.of(
		            "vendorId", vendorId,
		            "demandId", demandId
		    );

		    GraphQLResponse response = webClientBuilder.build()
		            .post()
		            .uri(inventoryServiceUrl + "/graphql")
		            .contentType(MediaType.APPLICATION_JSON)
		            .bodyValue(Map.of(
		                    "query", query,
		                    "variables", variables
		            ))
		            .retrieve()
		            .bodyToMono(new ParameterizedTypeReference<GraphQLResponse>() {})
		            .block();

		    return response != null && response.getData() != null
		            ? response.getData().getGetQuotationDemandItems()
		            : new VendorDemandResponse();
		}

		public ResponseDto savePurchaseOrder(PurchaseOrderRequest request) {
			return webClientBuilder.build().post().uri(inventoryServiceUrl + "/inventory/createPurchaseOrder")
					.bodyValue(request).retrieve().bodyToMono(ResponseDto.class).block();
		}

		public List<DemandQuotationResponse> getDemandlistByVendor(List<Long> demandIds, Long vendorIds,
				Long actionType) {
			String query = InventoryOrchestratorQuery.getDemandListByVendor(demandIds,vendorIds,actionType);
			Map<String, Object> variables = Map.of("demandIds", demandIds,"vendorIds",vendorIds,"actionType",actionType);
			Map<String, Object> requestBody = Map.of("query", query, "variables", variables);

			GraphQLResponse response = webClientBuilder.build().post().uri(inventoryServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
					.bodyToMono(GraphQLResponse.class).block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetDemandlistByVendor();
			} else {
				return Collections.EMPTY_LIST;
			}

		}

		public InvoiceVendorSummaryResponse getInvoiceByVendorId(List<Long> demandIds, Long vendorIds) {
			String query = InventoryOrchestratorQuery.getInvoiceByVendorId(demandIds,vendorIds);
			Map<String, Object> variables = Map.of("demandIds", demandIds,"vendorIds",vendorIds);
			Map<String, Object> requestBody = Map.of("query", query, "variables", variables);

			GraphQLResponse response = webClientBuilder.build().post().uri(inventoryServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
					.bodyToMono(GraphQLResponse.class).block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetInvoiceByVendorId();
			} else {
				return new InvoiceVendorSummaryResponse();
			}
		}

}

