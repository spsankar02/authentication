package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.util.List;

//import com.nalamfarms.order_service.dto.BasketDetailsResponse;
//import com.nalamfarms.order_service.dto.GetItemDetailsDto;
//import com.nalamfarms.order_service.dto.MemberAddressDto;
//import com.nalamfarms.order_service.dto.PaymentDetailsDto;
////import com.nalamfarms.order_service.dto.SubscriptionDetailsDto;

import lombok.Data;
import lombok.RequiredArgsConstructor;




@Data
@RequiredArgsConstructor
public class OrderBasketItemDetails {
	
	  private Long orderId;
	  private Long memberId;
	  private BigDecimal subTotal;
	  private BigDecimal discountAmount;
	  private BigDecimal taxAmount;
	  private BigDecimal grandTotal;
	  private BigDecimal deliveryCharge;
	  private BigDecimal surCharge;
	  private String orderStatus;
	  private String paymentStatus;
	  private String paymentMethod; 
	  private String cancellationReason;
     private String customOrderId;
    private List<GetItemDetailsDto> items;
	  private List<BasketDetailsResponse> baskets;
	  private SubscriptionDetailsDto subscription;
	  private MemberAddressDto deliveryAddress;
	  private PaymentDetailsDto paymentDetails;
	  private Integer rewardSpentPoints;
	  private BigDecimal rewardSpentAmount;
	  private BigDecimal transactionAmount;
	  private Boolean orderReview;

}
