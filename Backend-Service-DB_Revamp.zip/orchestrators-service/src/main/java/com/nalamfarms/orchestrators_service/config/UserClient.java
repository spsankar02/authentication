
package com.nalamfarms.orchestrators_service.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.nalamfarms.orchestrators_service.dto.GenerateRequest;
import com.nalamfarms.orchestrators_service.dto.GenerateResponse;
import com.nalamfarms.orchestrators_service.dto.MemberAddressDto;
import com.nalamfarms.orchestrators_service.dto.MemberCategoryDto;
import com.nalamfarms.orchestrators_service.dto.MemberDetailsDto;
import com.nalamfarms.orchestrators_service.dto.PythonImageResponse;
import com.nalamfarms.orchestrators_service.dto.ResponseMember;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class UserClient {
  @Value("${user.service.url}")
  private String userServiceUrl;
  private final WebClient.Builder webClientBuilder;
  private WebClient webClient;
  @Value("${python.api.url}")
  private String pythonUrl;
  @Value("${chatBot.api.url}")
  private String chatBot;

  private static final Logger log = LoggerFactory.getLogger(ProductClient.class);

 
  @PostConstruct
  private void init() {
      this.webClient = webClientBuilder
              .baseUrl(userServiceUrl)
              .build();
  }
  public MemberDetailsDto getMemberDetails(Long memberId) {
    return webClient.post()
      .uri(uriBuilder -> uriBuilder
        .path("/member/getMemberDetails")
        .queryParam("memberId", memberId)
        .build())
      .retrieve()
      .bodyToMono(MemberDetailsDto.class)
      .block(); // Blocking for simplicity (you can replace it with non-blocking if preferred)
  }
 

    @CircuitBreaker(name = "userServiceCircuitBreaker", fallbackMethod = "fallbackGetMemberAllergies")
    public List<Long> getMemberAllergies(Long memberId) {

        log.info("Fetching member allergies for memberId={}", memberId);
       
        return webClientBuilder.build()
            .get()
            .uri(userServiceUrl + "/member/getMemberAllergy?memberId=" + memberId)
            .retrieve()
            .bodyToMono(new ParameterizedTypeReference<List<Long>>() {})
            .block();
        
    }
    
    public List<Long> fallbackGetMemberAllergies(Long memberId, Throwable t) {
        log.error("Fallback for getMemberAllergies triggered for memberId {} due to {}", memberId, t.toString());
        return Collections.emptyList(); 
    }
    public MemberCategoryDto getCategoryFromUserService(Long memberId) {
        return webClientBuilder.build()
            .post()
            .uri(userServiceUrl + "/member/getMemberCategory?memberId=" + memberId)
            .retrieve()
            .bodyToMono(new ParameterizedTypeReference<ResponseMember<MemberCategoryDto>>() {})
            .map(ResponseMember::getData)
            .block();
    }
    public com.nalamfarms.orchestrators_service.dto.MemberAddressDto getMemberAddressById(Long addressId) {
      WebClient webClient = WebClient.create(userServiceUrl);
      return webClient.post()
        .uri(uriBuilder -> uriBuilder
          .path("/member/getMemberAddressByAddressId")
          .queryParam("addressId", addressId)
          .build())
        .retrieve()
        .bodyToMono(com.nalamfarms.orchestrators_service.dto.MemberAddressDto.class)
        .block(); 
    }
	public PythonImageResponse sendImageToPython(byte[] imageBytes) {
		  ByteArrayResource resource = new ByteArrayResource(imageBytes) {
	            @Override
	            public String getFilename() {
	                return "image.jpg";
	            }
	        };

	        MultiValueMap<String, Object> multipartData = new LinkedMultiValueMap<>();
	        multipartData.add("file", resource);

	        return webClientBuilder.build()
	                .post()
	                .uri(pythonUrl)
	                .contentType(MediaType.MULTIPART_FORM_DATA)
	                .body(BodyInserters.fromMultipartData(multipartData))
	                .retrieve()
	                .bodyToMono(PythonImageResponse.class)
	                .block();
	    }
	
	
	public List<MemberAddressDto> getAllMemberAddress(List<Long> addressIds) {
        WebClient webClient = WebClient.create(userServiceUrl);
 
        return webClient.post()
            .uri(uriBuilder -> uriBuilder
                .path("/member/getAllMemberAddress") 
                .queryParam("addressIds", addressIds) 
                .build())
            .retrieve()
            .bodyToMono(new ParameterizedTypeReference<List<MemberAddressDto>>() {})
            .block();
    }
//	public Member validateToken(LoginDto loginDto) {
//	    return webClient.post()
//	            .uri("/validatetoken")
//	            .header(HttpHeaders.AUTHORIZATION, "Bearer " + loginDto.getDeviceToken()) // ✅ pass token
//	            .bodyValue(loginDto)   // ✅ send request body
//	            .retrieve()
//	            .onStatus(HttpStatusCode::isError, clientResponse ->
//	                clientResponse.bodyToMono(String.class)
//	                        .flatMap(errorBody ->
//	                            Mono.error(new RuntimeException("Token validation failed: " + errorBody))
//	                        )
//	            )
//	            .bodyToMono(Member.class)  // ✅ expect Member as response
//	            .block(); // ⚠️ block only if you're not using reactive flow
//	}
//    public LoginDto getMemberDetailsFromDeviceToken(String deviceToken) {
//        return webClientBuilder.build()
//                .post()
//                .uri(userServiceUrl + "/member/getMemberDetailsFromDeviceToken?deviceToken={token}", deviceToken)
//                .retrieve()
//                .bodyToMono(LoginDto.class)
//                .block();  // use async (subscribe) in production
//    }
	
	public GenerateResponse getchatBotGenerator(GenerateRequest request) {
        JsonNode jsonNode = webClient.post()
                .uri(chatBot)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(JsonNode.class)
                .block();

        return parseResponse(jsonNode);
    }

    private GenerateResponse parseResponse(JsonNode node) {
        GenerateResponse response = new GenerateResponse();

        if (node.isObject()) {
            // Case 1: Normal object { "message": "...", "products": [...] }
            response.setMessage(node.has("message") ? node.get("message").asText() : null);
            if (node.has("products") && node.get("products").isArray()) {
                List<GenerateResponse.Product> products = new ArrayList<>();
                for (JsonNode p : node.get("products")) {
                    products.add(new GenerateResponse.Product(
                            p.get("name").asText(),
                            p.get("image_url").asText()
                    ));
                }
                response.setProducts(products);
            }
        } else if (node.isArray()) {
            // Case 2: Array [ "Here are suggestions", {..}, {..} ]
            ArrayNode arr = (ArrayNode) node;
            if (arr.size() > 0) {
                response.setMessage(arr.get(0).asText()); // first element is message
            }
            List<GenerateResponse.Product> products = new ArrayList<>();
            for (int i = 1; i < arr.size(); i++) {
                JsonNode p = arr.get(i);
                products.add(new GenerateResponse.Product(
                        p.get("name").asText(),
                        p.get("image_url").asText()
                ));
            }
            response.setProducts(products);
        }

        return response;
    }
}

