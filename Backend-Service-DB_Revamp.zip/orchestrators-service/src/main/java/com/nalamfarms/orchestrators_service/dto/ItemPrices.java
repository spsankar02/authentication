package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemPrices {
	
	private BigDecimal price;
    private BigDecimal discount;
    private BigDecimal realPrice;
	@JsonProperty("isDealItem")
    private boolean  isDealItem;
    private BigDecimal dealPrice;
    private BigDecimal dealDiscount;
    private String batchCode;


}
