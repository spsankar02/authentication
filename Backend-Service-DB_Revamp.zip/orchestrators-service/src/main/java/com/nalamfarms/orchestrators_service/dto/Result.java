package com.nalamfarms.orchestrators_service.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Result {
	private Long itemId;
	private String itemName;
	private String imageUrl;
	private Boolean isActive;
	private String itemCode;
//	private BigDecimal price;
//	private BigDecimal discount;
	private Product product;
	private Long basketId;
	private String basketName;
	private Boolean upcoming;
	private String description;
	private String basketCode;
	private List<VariantList> variantLists;
}
	