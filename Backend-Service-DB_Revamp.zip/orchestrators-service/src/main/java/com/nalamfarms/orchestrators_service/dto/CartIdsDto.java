package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class CartIdsDto {

  private List<Long> cartIds;
  private Boolean isSubscribed;
  private Long durationId;
  private List<Long> subscriptionPlanDays;
  private List<Long> deliveryTimeslot;
  private Long deliveryAddressId;
  private Date subscriptionStartDate=new Date();
  private Boolean isUsedPoints;
  private List<Integer> deliveryDayOfMonth;
  private String durationInCycles;
  private BigDecimal amount;
  private String customerName;
  private String customerEmail;
  private String customerContact;
}
