package com.nalamfarms.orchestrators_service.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nalamfarms.orchestrators_service.dto.*;
import com.nalamfarms.orchestrators_service.query.OrderOrchestratorQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nalamfarms.orchestrators_service.util.ResponseContent;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class OrderClient {

      
	  @Value("${order.service.url}")
	  private String orderServiceUrl;

	  @Value("${payment.service.url}")
	  private String paymentServiceUrl;

	  private final WebClient.Builder webClientBuilder;
	  private final ObjectMapper objectMapper;

	  private WebClient webClient;

	  @PostConstruct
	  private void init() {
	    this.webClient = webClientBuilder
	        .baseUrl(orderServiceUrl)
	        .build();
	  }

//  public OrderClient(String orderServiceUrl) {
//      this.orderServiceUrl = orderServiceUrl;
//      this.webClient = WebClient.create(orderServiceUrl);
//  }

  private static final Logger logger = LoggerFactory.getLogger(OrderClient.class);

    private static final String GRAPHQL_PATH = "/graphql";



//  private String orderServiceUrl = "http://localhost:8004";

  public NotificationDto cancelOrder(CancelOrderRequestDto cancelOrderDto) {

    return webClient.post()
      .uri(orderServiceUrl+"/api/orders/cancelOrder")  // Adjust the URI path if needed
      .bodyValue(cancelOrderDto)
      .retrieve()
      .bodyToMono(NotificationDto.class)
      .block();

  }
  public List<BasketInput> checkIfSubscribed(List<BasketInput> requestDto) {
        try {
            String url = orderServiceUrl + "/api/orders/isSubscribed";
            logger.info("Calling Order Service at URL: {}", url);

            WebClient webClient = WebClient.create(orderServiceUrl);
			List<BasketInput> responseList = webClient.post()
                    .uri("/api/orders/isSubscribed")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(requestDto)
                    .retrieve()
					.bodyToFlux(BasketInput.class)
					.collectList()
                    .block();
			return responseList != null ? responseList : Collections.emptyList();
        } catch (WebClientResponseException e) {
            logger.error("HTTP error calling Order Service: Status={} Body={}",
                    e.getStatusCode(), e.getResponseBodyAsString(), e);
            throw new RuntimeException( ResponseContent.FAILED_CHECKSUBSCRIPTION_STATUS+ e.getMessage(), e);
        } catch (Exception e) {
        	e.printStackTrace();
            logger.error("Unexpected error calling Order Service", e);
            throw new RuntimeException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
        }
    }

  public OrderBasketItemDetails  getOrderItemDetails(Long orderId,OrderDetailsRequest request) {
      try {
          logger.info("Calling Order Service at URL: {}/api/orders/orderdetails?orderId={}", orderServiceUrl, orderId);
          WebClient webClient = WebClient.create(orderServiceUrl);
          return webClient.post()
                  .uri(uriBuilder -> uriBuilder
                          .path("/api/orders/orderdetails")
                          .queryParam("orderId", orderId)
                          .build())
                  .contentType(MediaType.APPLICATION_JSON)
                  .bodyValue(request)
                  .retrieve()
                  .bodyToMono(OrderBasketItemDetails.class)
                  .block();
      } catch (WebClientResponseException e) {
          logger.error("HTTP error calling Order Service: Status={} Body={}", e.getStatusCode(), e.getResponseBodyAsString(), e);
          throw new RuntimeException( ResponseContent.FAILED_TO_CALL_ORDERSERVICE+ e.getMessage(), e);
      } catch (Exception e) {
          logger.error("Unexpected error calling Order Service", e);
          e.printStackTrace();
          throw new RuntimeException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
      }
  }

  public Mono<RewardPointEntityDto> fetchMemberRewardPointById(Long memberId) {
		String query = OrderOrchestratorQuery.fetchMemberRewardPointByIdQuery(memberId);
		return webClient.post().uri(orderServiceUrl + GRAPHQL_PATH).contentType(MediaType.APPLICATION_JSON)
				.bodyValue(query).retrieve().bodyToMono(String.class).map(responseJson -> {
					try {
						JsonNode root = new ObjectMapper().readTree(responseJson);
						JsonNode data = root.path("data").path("getMemberRewardPointById");
						return new ObjectMapper().treeToValue(data, RewardPointEntityDto.class);
					} catch (Exception e) {
						throw new RuntimeException(ResponseContent.FAILED_TO_PARSE_RESPONSE, e);
					}
				});
	}

  public Mono<List<RewardPointAmountConfigDto>> getAllRewardPointAmountConfigs() {
		String query = OrderOrchestratorQuery.getAllRewardPointAmountConfigsQuery();
		return webClient.post().uri(orderServiceUrl + GRAPHQL_PATH).contentType(MediaType.APPLICATION_JSON)
				.bodyValue(query).retrieve().bodyToMono(String.class).map(responseJson -> {
					try {
						ObjectMapper mapper = new ObjectMapper();
						JsonNode root = mapper.readTree(responseJson);
						JsonNode dataNode = root.path("data").path("getAllRewardPointAmountConfigs");
						return Arrays.asList(mapper.treeToValue(dataNode, RewardPointAmountConfigDto[].class));
					} catch (Exception e) {
						throw new RuntimeException(ResponseContent.FAILED_TO_PARSE_RESPONSE, e);
					}
				});
	}

  



  public JsonNode getOrderItemByOrderId( Long orderId) {
    if (orderId == null) {
      throw new IllegalArgumentException(ResponseContent.ORDERID_NOT_BE_CALL);
    }

    try {
      String query = OrderOrchestratorQuery.getOrderItemByOrderIdQuery(orderId);
      ObjectNode variables = objectMapper.createObjectNode();
      variables.put("orderId", orderId);

      ObjectNode requestBody = objectMapper.createObjectNode();
      requestBody.put("query", query);
      requestBody.set("variables", variables);

      return webClient.post()
        .uri(orderServiceUrl + "/graphql")
        .bodyValue(requestBody)
        .retrieve()
        .onStatus(
          status -> status.isError(),
          response -> response.bodyToMono(String.class)
            .flatMap(body -> Mono.error(new OrderServiceException(
            		ResponseContent.PAYMENTSERVICE_ERROR + response.statusCode() + ResponseContent.BODY + body
            )))
        )
        .bodyToMono(JsonNode.class)
        .blockOptional()
        .orElseThrow(() -> new OrderServiceException(ResponseContent.NO_RESPONSE_PAYMENTSERVICE));

    } catch (WebClientResponseException e) {
      throw new OrderServiceException(ResponseContent.HTTP_ERROR_FROM_PRODUCT + e.getStatusCode() + ResponseContent.MESSAGE + e.getResponseBodyAsString(), e);
    } catch (Exception e) {
      e.printStackTrace();
      throw new OrderServiceException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
    }
  }


	



  
  
  
	

  public Order getMemberByOrderId(Long orderId) {
	    return webClientBuilder.build()
	        .post()
	        .uri(orderServiceUrl + "/api/orders/getMemberByOrderId?orderId=" + orderId)
	        .retrieve()
	        .bodyToMono(Order.class)
	        .block();
	}
  
  public Long getDeliveryAddressByOrderId(Long orderId) {
	    return webClientBuilder.build()
	        .post()
	        .uri(orderServiceUrl + "/api/orders/getdeliveryAddressByOrderId?orderId=" + orderId)
	        .retrieve()
	        .bodyToMono(Long.class)
	        .block();
	}
  

//	public Long getMemberByOrderId(Long orderId) {
//		return webClient.post()
//	            .uri(uriBuilder -> uriBuilder
//	                    .path("/api/orders/getMemberByOrderId")
//	                    .queryParam("orderId", orderId)
//	                    .build())
//	            .retrieve()
//	            .bodyToMono(Long.class)
//	            .block();
//	}


  public Mono<List<MemberOffersRedeemed>> getMemberOfferRedeemed(Long memberId) {
	    String query = OrderOrchestratorQuery.getMemberOfferRedeemedQuery();

	    // Pass memberId as a String to match GraphQL's ID type
	    Map<String, Object> variables = Map.of("memberId", String.valueOf(memberId));
	    WebClient webClient = WebClient.create(orderServiceUrl);

	    return webClient.post()
	        .uri(orderServiceUrl + GRAPHQL_PATH)
	        .contentType(MediaType.APPLICATION_JSON)
	        .bodyValue(Map.of("query", query, "variables", variables))
	        .retrieve()
	        .bodyToMono(String.class)
	        .flatMap(json -> {
	            try {
	                ObjectMapper mapper = new ObjectMapper();
	                JsonNode root = mapper.readTree(json);

	                if (root.has("errors")) {
	                    return Mono.error(new RuntimeException(ResponseContent.GRAPHQL_ERROR + root.get("errors")));
	                }

	                JsonNode dataNode = root.path("data").path("getMemberOffersRedeemed");

	                if (!dataNode.isArray()) {
	                    return Mono.empty();
	                }

	                List<MemberOffersRedeemed> result = new ArrayList<>();
	                for (JsonNode node : dataNode) {
	                    result.add(mapper.treeToValue(node, MemberOffersRedeemed.class));
	                }

	                return Mono.just(result);

	            } catch (Exception e) {
	                return Mono.error(new RuntimeException(ResponseContent.FAILED_TO_PARSE_RESPONSE, e));
	            }
	        });
	}


  public SaveOrderResponseDto saveOrder(SaveOrderRequestDto saveOrderRequestDto) {

    try {
      return webClient.post()
        .uri(orderServiceUrl+"/api/orders/saveOrder")
        .bodyValue(saveOrderRequestDto)
        .retrieve()
        .bodyToMono(SaveOrderResponseDto.class)
        .block();
    } catch (Exception e) {
      System.err.println(ResponseContent.SAVE_ORDER_EXCEPTION + e.getMessage());
      throw e;
    }

  }
  public ResponseEntity<Map<String, Object>> orderPriceProcess(OrderPriceProcessDto orderPriceProcessDto) {
       Map<String, Object> response = webClient.post()
      .uri(orderServiceUrl+"/api/orders/orderPriceProcess")  // Adjust the path if needed
      .bodyValue(orderPriceProcessDto)
      .retrieve()
      .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
      .block();

    return ResponseEntity.ok(response);

  }
  
  
	public List<OrderItem> getOrderItemDetails() {

		try {
			String query =OrderOrchestratorQuery.getOrderItemDetailsQuery();

			Map<String, String> requestBody = Map.of("query", query);

			GraphQLResponse response = webClientBuilder.build().post().uri(orderServiceUrl + "/graphql")
					.contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).retrieve()
					.bodyToMono(GraphQLResponse.class).block();

			if (response != null && response.getData() != null) {
				return response.getData().getGetOrderItemDetails();
			} else {
				return Collections.emptyList();
			}

		}

		catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

	public List<Order> filterOrders(String startDate, String endDate, List<Long> orderStatusId, List<Long> orderId) {
		 String query = OrderOrchestratorQuery.filterOrdersQuery();

		Map<String, Object> variables = new HashMap<>();
		variables.put("startDate", startDate);
		variables.put("endDate", endDate);
		variables.put("orderStatusId", orderStatusId);
		variables.put("orderId", orderId); 

		Map<String, Object> payload = new HashMap<>();
		payload.put("query", query);
		payload.put("variables", variables);

		GraphQLResponse response = webClient.post().uri(orderServiceUrl + "/graphql")
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).bodyValue(payload).retrieve()
				.bodyToMono(GraphQLResponse.class).onErrorResume(e -> {
					e.printStackTrace();
					return Mono.empty();
				}).block();

		return response != null && response.getData() != null && response.getData().getFilterOrders() != null
				? response.getData().getFilterOrders()
				: Collections.emptyList();
	}
	public List<SubscriptionPlansDTO> filterSubscriptions(
	        String startDate,
	        String endDate,
	        List<Long> subscriptionId,
	        String status,
	        List<Long> durationId) {
		String query = OrderOrchestratorQuery.filterSubscriptions();
	    Map<String, Object> variables = new HashMap<>();
	    variables.put("startDate", startDate);
	    variables.put("endDate", endDate);
	    variables.put("subscriptionId", subscriptionId);
	    variables.put("status", status);
	    variables.put("durationId", durationId);

	    Map<String, Object> payload = new HashMap<>();
	    payload.put("query", query);
	    payload.put("variables", variables);

	    GraphQLResponse response = webClient.post()
	            .uri(orderServiceUrl + "/graphql")
	            .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
	            .bodyValue(payload)
	            .retrieve()
	            .bodyToMono(GraphQLResponse.class)
	            .onErrorResume(e -> {
	                e.printStackTrace();
	                return Mono.empty();
	            })
	            .block();

	    return response != null && response.getData() != null && response.getData().getFilterSubscription() != null
	            ? response.getData().getFilterSubscription()
	            : Collections.emptyList();
	}

	public String saveSubscription(SaveSubscriptionRequestDto subscriptionRequest) {

		try {
			return webClient.post()
					.uri(orderServiceUrl + "/api/orders/saveSubscriptionDetails")
					.bodyValue(subscriptionRequest)
					.retrieve()
					.bodyToMono(String.class)
					.block();
		} catch (Exception e) {
			System.err.println(ResponseContent.SAVE_ORDER_EXCEPTION + e.getMessage());
			throw e;
		}
	}
}


