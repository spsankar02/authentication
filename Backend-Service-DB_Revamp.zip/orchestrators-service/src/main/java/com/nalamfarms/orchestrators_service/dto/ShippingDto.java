package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShippingDto {
    private Integer shippingId;
    private Long orderId;
    private Long shippingAddressId;
    private String shippingMethod;
    private String trackingNumber;
    private String carrierName;
    private String estimatedDelivery;
    private String shippedDate;
    private String deliveredDate;
    private String createdAt;
    private String modifiedAt;
    private Long createdBy;
    private Long modifiedBy;
    private Integer shippingCost;
    private Boolean returnStatus;
    private String remarks;
    private Long shippingStatusId;

    private ShippingStatusDto shipmentStatus;

    private List<ShipmentTrackingDto> shipmentTracking;
    private List<OrderBasketItemDetails> orders;
    private MemberAddressResponse memberAddress;
}
