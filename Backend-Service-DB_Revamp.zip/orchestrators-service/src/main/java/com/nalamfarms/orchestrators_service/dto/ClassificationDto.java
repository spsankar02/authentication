package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClassificationDto {
	
	    private Long classificationId;
	    private String classificationName;
		private String classificationCode;
	    private String imageUrl;

}
