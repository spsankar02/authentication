package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class CancelOrderRequestDto {
  private Long orderId;
}
