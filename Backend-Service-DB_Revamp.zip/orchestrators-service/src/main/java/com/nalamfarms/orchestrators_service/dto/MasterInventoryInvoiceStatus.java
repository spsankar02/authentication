package com.nalamfarms.orchestrators_service.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterInventoryInvoiceStatus {

	private Long invoiceStatusId;

	private String statusName;

	private Date createdDate;

	private String description;
}
