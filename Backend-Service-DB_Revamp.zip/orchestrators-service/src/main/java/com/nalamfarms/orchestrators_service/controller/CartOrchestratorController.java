package com.nalamfarms.orchestrators_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.orchestrators_service.dto.AddToCartRequest;
import com.nalamfarms.orchestrators_service.dto.BillDetails;
import com.nalamfarms.orchestrators_service.dto.BillDetailsRequest;
import com.nalamfarms.orchestrators_service.dto.CartDTO;
import com.nalamfarms.orchestrators_service.dto.CartDetailsResponse;
import com.nalamfarms.orchestrators_service.dto.GetAddCartDetailsRequest;
import com.nalamfarms.orchestrators_service.service.CartOrchestratorService;

@RestController
public class CartOrchestratorController {
	
	@Autowired
	private CartOrchestratorService cartService;

	@MutationMapping
	public List<CartDTO> addCartDetails(@Argument("input") List<AddToCartRequest> request) {
		return cartService.addCartDetails(request);
	}

	@QueryMapping
	public CartDetailsResponse getAddCartDetails(@Argument("input") GetAddCartDetailsRequest request) {
		return cartService.getAddCartDetails(request.getMemberId(), request.getType());
	}

	@QueryMapping
	public List<CartDTO> getCartDetailsByCartIds(@Argument("input") List<Long> cartIds) {
		return cartService.getCartDetailsBycartIds(cartIds);
	}
	
	@QueryMapping
	public BillDetails getCartSummary(@Argument("input") BillDetailsRequest request) {
		return cartService.getCartSummary(request.getMemberId(), request.getCartIds(),request.getType(),request.isUsedPoints());
	}
}
