package com.nalamfarms.orchestrators_service.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ItemWishlistData {
    private Long itemId;
    private String itemCode;
    private String itemName;
    private String imageUrlItem;
    private List<VariantList> variantLists;
}
