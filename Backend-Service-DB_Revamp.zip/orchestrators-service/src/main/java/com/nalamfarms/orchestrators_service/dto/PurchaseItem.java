package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseItem {
	
	private Long purchaseItemId;
	private  Long skuId;
	private  Long itemOriginInfoId;
	private Long rackId;
	private BigDecimal price;
	private BigDecimal quantity;
	private Long unit;
	private LocalDateTime mfgDate;
	private LocalDateTime expDate;
	private String notes;
	private String qrPath;
	private BigDecimal taxPercentage;
	private BigDecimal tax;
	private BigDecimal unitCost;
	private Long purchaseMasterId;
	private BigDecimal shippingAmount;

}
