package com.nalamfarms.orchestrators_service.dto;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class GraphQLResponse {
	 private GraphQLData data;
	private List<GraphQLError> errors;
    private Map<String, Object> datas;


	    }


