package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderItemDTO {
	
	private Long purchaseOrderItemId;
    private Boolean isInventoryMoved;
    private Long certificateTypeId;
    private String certificateTypeName;
    private String certificateCode;
    private String description;
    private Long shippingStatusId;
    private String shippingStatus;
    private Long skuId;
    private MappingProductItemVariantSkuDto skuDetails;
    private Long certificateStatusId;
    private String certificateStatusName;
    private String certificateStatusDescription;
    private LocalDateTime mfgDate;
    private LocalDateTime expDate;
    private String notes;
    private Long rackId;
    private BigDecimal pricePerUnit;
    private BigDecimal quantity;
    private BigDecimal totalPrice;
    private BigDecimal shippingAmount;
    private String batchCode;
    private String qrPath;
    

}
