package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

@Data
public class MasterOffers {
	
	private Long offerId;
    private String title;
    private String description;
    private MasterOfferType masterOfferType;

    private String startDate;

    private String endDate;

    private Integer minCartValue;
    private Boolean isActive;

}
