package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RecommendInput {
   private String type;
   @JsonProperty("item_id")
   private String itemId;
   @JsonProperty("number_of_recommendations")
   private int numberOfRecommendations;
}
