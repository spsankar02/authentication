package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterCertificateType {

	private Long certificateTypeId;

	private String certificateCode;

	private String certificateName;

	private String description;

	private Boolean isActive;

	private LocalDateTime createdAt;

	private LocalDateTime updatedAt;

}
