package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RecentEntriesResponse {

    @JsonProperty("member_id")
    private String memberId;

    @JsonProperty("user_location")
    private String userLocation;

    @JsonProperty("page_visited")
    private String pageVisited;

    @JsonProperty("category_type")
    private String categoryType;

    @JsonProperty("basket_id")
    private String basketId;

    @JsonProperty("basket_name")
    private String basketName;

    @JsonProperty("classification_id")
    private String classificationId;

    @JsonProperty("product_id")
    private String productId;

    @JsonProperty("item_id")
    private String itemId;

    @JsonProperty("item_name")
    private String itemName;

    @JsonProperty("varient_id")
    private String varientId;

    @JsonProperty("search_items")
    private String searchItems;

    @JsonProperty("basket_items")
    private String basketItems;

    @JsonProperty("page_in_time")
    private LocalDateTime pageInTime;

    @JsonProperty("page_out_time")
    private LocalDateTime pageOutTime;

    @JsonProperty("time_spent")
    private Integer timeSpent;

    @JsonProperty("action")
    private String action;

}
