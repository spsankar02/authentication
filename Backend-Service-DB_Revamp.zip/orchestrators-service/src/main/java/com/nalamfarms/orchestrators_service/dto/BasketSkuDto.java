package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BasketSkuDto {

	private Long basketId;

	private String basketName;

	private String basketCode;
	
	private String imageUrl;
	
	private PriceSkuDto basketSukPrice;
	

}
