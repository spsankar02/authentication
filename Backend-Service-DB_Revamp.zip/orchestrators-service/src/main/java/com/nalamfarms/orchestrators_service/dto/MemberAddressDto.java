package com.nalamfarms.orchestrators_service.dto;


import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Data
public class MemberAddressDto {

  private Long memberAddressId;

  private Long memberId;

  private String nearbyLandmark;

  private Long countryId;

  private String countryName;

  private Long stateId;

  private String stateName;

  private String cityName;

  private Long cityId;

  private String pincode;

  private boolean isActive;

  private String areaSectorlocality;

  private String flatHousenoBuilding;

  private Boolean isDefault;

  private String phoneNumber;

  private String memberName;

  private String addressLine1;

  private String addressLine2;

  private String rawAddress;
  
  


}
