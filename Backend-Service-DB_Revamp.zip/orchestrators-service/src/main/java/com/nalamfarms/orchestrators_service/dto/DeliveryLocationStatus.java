package com.nalamfarms.orchestrators_service.dto;

public enum DeliveryLocationStatus {

	NALAM, VENDOR

}
