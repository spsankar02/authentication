package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Baskets {
    private Long basketId;
    private String basketName;
    private String imageUrl;
    private Boolean isActive;
    private Boolean upcoming;
    private String description;
    private String basketCode;
    private double rating;
}
