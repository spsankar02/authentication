package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterVendor {
	    private Long vendorId;
	    private String vendorCode;
	    private String name;
	    private String email;
	    private String phone;
	    private String website;
	    private String address;
	    private String city;
	    private String state;
	    private String country;
	    private String postalCode;
	    private String logoUrl;
	    private String bannerUrl;
	    private boolean isActive;
	    private boolean isVerified;
	    private Integer rating;
	    private LocalDateTime createdAt;
	    private LocalDateTime updatedAt;
}
