package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class MasterSubscriptionDuration {


	private Long subscriptionDurationId;

	private String durationName;

	private Integer months;

	private LocalDateTime createdAt=LocalDateTime.now();

	private boolean isActive=true;

}
