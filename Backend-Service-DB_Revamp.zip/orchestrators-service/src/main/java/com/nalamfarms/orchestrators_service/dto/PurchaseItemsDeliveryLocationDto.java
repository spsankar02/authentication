package com.nalamfarms.orchestrators_service.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseItemsDeliveryLocationDto {
	private Long deliveryLocationId;
    private String address;
    private String pincode;
    private String city;
    private String state;
    private String country;
    private DeliveryLocationStatus deliveryLocationStatus;

}

