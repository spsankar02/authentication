package com.nalamfarms.orchestrators_service.config;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nalamfarms.orchestrators_service.dto.GraphQLRequest;
import com.nalamfarms.orchestrators_service.dto.ShippingDto;
import com.nalamfarms.orchestrators_service.query.LogisticOrchestratorQuery;

import lombok.RequiredArgsConstructor;
@Component
@RequiredArgsConstructor
public class LogisticClient {
    private final WebClient webClient = WebClient.builder().build();
    private final ObjectMapper objectMapper; 
    
    @Value("${logistic.service.url}")
    private String logisticServiceUrl;

    public List<ShippingDto> filterShipments(String startDate, String endDate, List<Long> categoryId, List<Integer> shipmentId,List<String> locationAreas) {
        String query =LogisticOrchestratorQuery.filterShipmentsQuery(startDate,endDate,categoryId,shipmentId,locationAreas);

		//String query ="LogisticOrchestratorQuery.filterShipmentsQuery()";

        try {
            Map<String, Object> variables = new HashMap<>();
            variables.put("startDate", startDate);
            variables.put("endDate", endDate);
            variables.put("categoryId", categoryId);
            variables.put("shipmentId", shipmentId);
            variables.put("locationAreas", locationAreas);

            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("query", query);
            requestBody.put("variables", variables);

            ObjectMapper objectMapper = new ObjectMapper();

            JsonNode responseNode = webClient.post()
                .uri(logisticServiceUrl+"/graphql")
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(JsonNode.class)
                .block();

            if (responseNode != null && responseNode.has("data")) {
                JsonNode dataNode = responseNode.get("data").get("filterShipments");

                if (dataNode != null && dataNode.isArray()) {
                    return objectMapper.readerForListOf(ShippingDto.class).readValue(dataNode);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return Collections.emptyList();
    }


	public List<ShippingDto> filterShipping(List<String> locationAreas, List<String> shipmentDateTypes) {

	    String query =LogisticOrchestratorQuery.filterShippingQuery(locationAreas,shipmentDateTypes);

	    Map<String, Object> variables = new HashMap<>();
	    variables.put("filterType", shipmentDateTypes);
	    variables.put("locationAreas", locationAreas);

	    Map<String, Object> payload = new HashMap<>();
	    payload.put("query", query);
	    payload.put("variables", variables);

	    try {
	        JsonNode response = webClient
	                .post()
	                .uri("http://localhost:8003/graphql")
	                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
	                .bodyValue(payload)
	                .retrieve()
	                .bodyToMono(JsonNode.class)
	                .block();

	        JsonNode shippingData = response.path("data").path("filterShippingByShipmentDateAndLocationArea");

	        if (shippingData.isArray()) {
	            List<ShippingDto> shippingList = new ArrayList<>();
	            for (JsonNode node : shippingData) {
	                ShippingDto dto = objectMapper.treeToValue(node, ShippingDto.class);
	                shippingList.add(dto);
	            }
	            return shippingList;
	        }

	        return Collections.emptyList();

	    } catch (Exception e) {
	        throw new RuntimeException("Error calling logistic-service GraphQL", e);
	    }
	}
}