package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GenerateRequest {
	
    @JsonProperty("prompt")
    private String prompt;
    @JsonProperty("user_id")
    private Long user_id;
   // String deviceToken;
}
