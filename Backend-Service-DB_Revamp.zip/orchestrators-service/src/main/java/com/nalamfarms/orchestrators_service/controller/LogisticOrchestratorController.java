package com.nalamfarms.orchestrators_service.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;


import com.nalamfarms.orchestrators_service.dto.ShippingDto;
import com.nalamfarms.orchestrators_service.dto.ShippingUpdateResponse;
import com.nalamfarms.orchestrators_service.service.LogisticOrhestratorService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class LogisticOrchestratorController {
	private final LogisticOrhestratorService logisticOrhestratorService;
	@QueryMapping
   List<ShippingDto> filterShipments(@Argument String startDate,@Argument String endDate,@Argument List<Long> categoryId,@Argument List<Integer> shipmentId,@Argument List<String> locationAreas){
	   return logisticOrhestratorService.filterShipments(startDate,endDate,categoryId,shipmentId,locationAreas);
   }
	
	@QueryMapping
	public List<ShippingDto> filterShippingByDateAndArea(
	        @Argument("filterType") List<String> shipmentDateTypes,
	        @Argument List<String> locationAreas) {

	    return logisticOrhestratorService.filterShippingByDateAndArea(locationAreas, shipmentDateTypes);
	}
	
	@QueryMapping
	public String qrPathBasedOnfilterShipments(@Argument String startDate, @Argument String endDate,
			@Argument List<Long> categoryId, @Argument List<Integer> shipmentId, @Argument List<String> locationAreas) {
		
		byte[] pngBytes = logisticOrhestratorService.QrPathBasedOnfilterShipments(startDate, endDate, categoryId,
				shipmentId, locationAreas);
		return Base64.getEncoder().encodeToString(pngBytes);

	}
	
//	public ResponseEntity<ShippingUpdateResponse> updateShippingStatusByShippingId(ShippingUpdate shippingUpdate) {
//		
//	}
	

}
