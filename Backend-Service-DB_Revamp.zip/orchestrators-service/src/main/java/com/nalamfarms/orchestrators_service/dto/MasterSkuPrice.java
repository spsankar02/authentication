package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MasterSkuPrice {

    private Long priceId;
    private Long skuId;
    private BigDecimal price;
    private BigDecimal discount;
    private BigDecimal realPrice;
    @JsonProperty("isActive")
    private boolean isActive=true;
    private String batchCode;
}
