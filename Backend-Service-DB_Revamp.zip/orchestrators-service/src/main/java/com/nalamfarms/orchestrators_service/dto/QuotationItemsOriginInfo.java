package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuotationItemsOriginInfo {

	private Long itemsOriginInfoId;

	private String city;

	private String state;

	private String country;

	private String description;
}
