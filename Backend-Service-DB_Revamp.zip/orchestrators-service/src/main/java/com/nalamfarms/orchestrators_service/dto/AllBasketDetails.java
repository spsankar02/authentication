package com.nalamfarms.orchestrators_service.dto;

 import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AllBasketDetails {
    private Long basketId;
    private String basketName;
    private String imageUrl;
    private String description;
    private boolean upcoming;
    @JsonProperty("active")
    private boolean active;
    private String basketCode;
    private List<VariantList> variantLists;
    private double ratings;
}
