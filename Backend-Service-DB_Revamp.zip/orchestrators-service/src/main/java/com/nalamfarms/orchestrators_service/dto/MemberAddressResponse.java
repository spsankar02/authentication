package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberAddressResponse {
	
	private Long memberAddressId;
    private String flatHouseNoBuilding;
    private String areaSectorLocality;
    private String nearbyLandmark;
    private String addressType;
    private String pincode;
    private Boolean isActive;
    private Boolean isDefault;
    private String memberName;
    private String phoneNumber;
    private String addressLine1;
    private String addressLine2;
    private String rawAddress;
    private String cityName;
    private CountryDto countryId;
    private StateDto stateId;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class CountryDto {
        private Long countryId;
        private String countryName;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class StateDto {
        private Long stateId;
        private String stateName;
    }

}
