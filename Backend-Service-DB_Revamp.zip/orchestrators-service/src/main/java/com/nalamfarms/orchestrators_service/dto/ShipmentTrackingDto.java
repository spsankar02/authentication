package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShipmentTrackingDto {

    private Integer shipmentTrackingId;

    private String status;

    private String location;

    private String updatedAt;

    private String remarks;

    private Long createdBy;

    private Long modifiedBy;

    private LocalDateTime createdAt;

    private LocalDateTime modifiedAt;
    
    private String pinCode;
}

