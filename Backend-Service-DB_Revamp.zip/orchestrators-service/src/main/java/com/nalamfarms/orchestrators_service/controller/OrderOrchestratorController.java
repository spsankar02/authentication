package com.nalamfarms.orchestrators_service.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nalamfarms.orchestrators_service.dto.CancelOrderRequestDto;
import com.nalamfarms.orchestrators_service.dto.CartIdsDto;
import com.nalamfarms.orchestrators_service.dto.OrderBasketItemDetails;
import com.nalamfarms.orchestrators_service.dto.OrderWithItemsDto;
import com.nalamfarms.orchestrators_service.dto.SubscriptionPlansDTO;
import com.nalamfarms.orchestrators_service.dto.orderdto.OrderFilterRequestDTO;
import com.nalamfarms.orchestrators_service.service.OrderOrchestratorService;
import com.razorpay.RazorpayException;

import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/orchestrator/order")
@RequiredArgsConstructor
public class OrderOrchestratorController {

  @Autowired
  private OrderOrchestratorService orchestratorService;


//    @PostMapping("/getOrderItemDetails")
//    public OrderBasketItemDetails getOrderBasketItemDetails(@RequestParam Long orderId) {
//        return orchestratorService.getOrderItemDetails(orderId);
//    }
  
	@GetMapping("/getOrderBasketItemDetailsMap")
	public Map<Long, OrderBasketItemDetails> getOrderBasketItemDetailsMap(@RequestParam("orderIds") List<Long> orderIds) {
		return orchestratorService.getOrderItemDetailsMap(orderIds);
	}
  
  @QueryMapping
  public  OrderBasketItemDetails getOrderBasketItemDetails(@Argument Long orderId) {
      return orchestratorService.getOrderItemDetails(orderId);
  }
  
  @QueryMapping
  public List<OrderBasketItemDetails> getOrderBasketItemDetailsList(@Argument List<Long> orderIds) {
      return orchestratorService.getOrderItemDetails(orderIds);
  }

  

  @PostMapping("/cancelOrder")
  public ResponseEntity<Map<String, Object>> cancelOrder(@RequestBody CancelOrderRequestDto request) {
    return orchestratorService.cancelOrder(request);
  }

	@PostMapping("/create-order")
	public ResponseEntity<?> saveOrder(@RequestBody CartIdsDto cartIdsDto)
			throws JsonProcessingException, RazorpayException {
		return orchestratorService.saveOrder(cartIdsDto);
	}
  
  @QueryMapping
  public List<com.nalamfarms.orchestrators_service.dto.TopOrderedBaskets> getItemOrBasketWiseSales() {
    return orchestratorService.getItemOrBasketWiseSales();

  }

  @QueryMapping
  public void searchOrders(@RequestBody OrderFilterRequestDTO orderFilterRequestDTO) {
     //return
     orchestratorService.searchOrders(orderFilterRequestDTO);
  }
  @QueryMapping
  public List<OrderWithItemsDto> filterOrders(@Argument String startDate,@Argument String endDate,@Argument List<Long> orderStatusId,@Argument List<Long> orderId){
	  return orchestratorService.filterOrders(startDate,endDate,orderStatusId,orderId);
  }
  
  @QueryMapping
	List<SubscriptionPlansDTO> filterSubscription(@Argument String startDate,@Argument String endDate,@Argument List<Long> subscriptionId,@Argument String status,@Argument List<Long> durationId){
		return orchestratorService.filterSubscription(startDate,endDate,subscriptionId,status,durationId);

	}
  
  
  }
