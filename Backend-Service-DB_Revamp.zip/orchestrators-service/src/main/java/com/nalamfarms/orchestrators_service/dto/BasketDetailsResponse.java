package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

import java.util.List;

@Data
public class BasketDetailsResponse {
    private Long basketId;
    private String basketName;
    private String imageUrl;
    private String description;
    private boolean upcoming;
    private boolean isActive;
    private String basketCode;
    private List<VariantList> variantLists;
    private double rating;

}
