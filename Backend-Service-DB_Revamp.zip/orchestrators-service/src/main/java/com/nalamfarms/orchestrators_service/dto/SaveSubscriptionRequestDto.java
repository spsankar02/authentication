package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Data
public class SaveSubscriptionRequestDto {

	private Long durationId;

	private List<Long> subscriptionPlanDays ;

	private List<Long> deliveryTimeslot ;

	private Long orderId;

	private Date subscriptionStartDate =new Date();

	private List<Integer> deliveryDaysOfMonth;

	private String durationInCycles;

	private Long memberId;

	//private LocalDateTime startDate;
	private Integer totalBillingCycles;

	private Frequency frequency;                 // WEEKLY / MONTHLY / YEARLY
	//private List<String> daysOfWeek;             // e.g. ["MONDAY","FRIDAY"] if WEEKLY
	//private List<Integer> datesOfMonth;          // e.g. [1,10,15] → bill on 1st, 10th, 15th each month
	//private List<Integer> monthsOfYear;          // e.g. [1,6,12] if YEARLY (1..12)

	// Amount/currency for each charge
	private BigDecimal amount;                   // e.g. 499.00
	private String currency = "INR";

	private String customerName;
	private String customerEmail;
	private String customerContact;

}
