
package com.nalamfarms.orchestrators_service.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nalamfarms.orchestrators_service.dto.AddToCartRequest;
import com.nalamfarms.orchestrators_service.dto.CartDTO;
import com.nalamfarms.orchestrators_service.dto.CartQuantityDetails;
import com.nalamfarms.orchestrators_service.dto.DeleteCartRequestDto;
import com.nalamfarms.orchestrators_service.dto.OrderServiceException;
import com.nalamfarms.orchestrators_service.query.CartOrchestratorQuery;
import com.nalamfarms.orchestrators_service.util.ResponseContent;

import reactor.core.publisher.Mono;

@Component
public class CartClient {

  @Autowired
  private ObjectMapper objectMapper;

  private static final String GRAPHQL_PATH = "/graphql";
  
  private static final Logger log = LoggerFactory.getLogger(CartClient.class);


  @Value("${cart.service.url}")
  private String cartServiceUrl;

  WebClient webClient = WebClient.create(cartServiceUrl);


  public JsonNode getCartDetails(List<Long> cartIds) {

    if (cartIds == null || cartIds.isEmpty()) {
      throw new IllegalArgumentException("Order item IDs cannot be null or empty");
    }

    try {
      String query = CartOrchestratorQuery.getCartDetailsByCartIds();

      ObjectNode variables = objectMapper.createObjectNode();
      variables.putPOJO("input", cartIds);

      ObjectNode requestBody = objectMapper.createObjectNode();
      requestBody.put("query", query);
      requestBody.set("variables", variables);
      log.info("Fetching cart details for cartIds: {}", cartIds);

      JsonNode response = webClient.post()
    	        .uri(cartServiceUrl + GRAPHQL_PATH)
    	        .bodyValue(requestBody)
    	        .retrieve()
    	        .bodyToMono(JsonNode.class)
    	        .blockOptional()
    	        .orElseThrow(() -> new OrderServiceException(ResponseContent.RESPONSE_NOT_FROM_CART));

    	      log.debug("Received cart details response: {}", response);
    	return response;
    } catch (WebClientResponseException e) {
        log.error("HTTP error while fetching cart details: status={}, body={}", e.getStatusCode(), e.getResponseBodyAsString());
      throw new OrderServiceException(ResponseContent.HTTP_ERROR_FROM_PRODUCT + e.getStatusCode() + ResponseContent.MESSAGE + e.getResponseBodyAsString(), e);
    } catch (Exception e) {
        log.error("Unexpected error while fetching cart details", e);
      throw new OrderServiceException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
    }
  }
 
  public JsonNode deleteCartDetails(DeleteCartRequestDto request) {
    if (request == null) {
      throw new IllegalArgumentException(ResponseContent.REQUEST_CANNOT_BE_NULL);
    }

    try {
      String query = CartOrchestratorQuery.deleteCartQuery();

      ObjectNode variables = objectMapper.createObjectNode();
      variables.putPOJO("input", request);

      ObjectNode requestBody = objectMapper.createObjectNode();
      requestBody.put("query", query);
      requestBody.set("variables", variables);
      variables.put("cartId", request.getCartId());
      variables.put("memberId", request.getMemberId());
      variables.put("status", request.getStatus());

      log.info("Deleting cart details: cartId={}, memberId={}, status={}", request.getCartId(), request.getMemberId(), request.getStatus());
      log.debug("Delete cart requestBody: {}", requestBody);
      return webClient.post()
        .uri(cartServiceUrl + GRAPHQL_PATH)
        .bodyValue(requestBody)
        .retrieve()
        .onStatus(
          status -> status.isError(),
          response -> response.bodyToMono(String.class)
            .flatMap(body -> Mono.error(new OrderServiceException(
            		ResponseContent.CARTSERVICE_ERROR_STATUS+ response.statusCode() + ResponseContent.BODY + body
            )))
        )
        .bodyToMono(JsonNode.class)
        .blockOptional()
        .orElseThrow(() -> new OrderServiceException(ResponseContent.NO_RESPONSE_PRODUCTSERVICE));

    } catch (WebClientResponseException e) {
        log.error("HTTP error while deleting cart details: status={}, body={}", e.getStatusCode(), e.getResponseBodyAsString());
      throw new OrderServiceException(ResponseContent.HTTP_ERROR_FROM_PRODUCT + e.getStatusCode() + ResponseContent.MESSAGE + e.getResponseBodyAsString(), e);
    } catch (Exception e) {
        log.error("Unexpected error while deleting cart details", e);
      throw new OrderServiceException(ResponseContent.SAVE_ORDER_EXCEPTION, e);
    }
  }





    //@CircuitBreaker(name = "cartServiceCircuitBreaker", fallbackMethod = "fallbackFetchCartQuantity")
    public List<CartQuantityDetails> fetchCartQuantity(Long memberId, List<Long> skuIdList) {
		Map<String, Object> variables = new HashMap<>();
		variables.put("memberId", memberId);
		variables.put("skuIds", skuIdList);

		String graphqlQuery = CartOrchestratorQuery.fetchCartQuantityQuery();

		Map<String, Object> requestBody = Map.of(
				"query", graphqlQuery,
				"variables", variables
		);

		log.info("Fetching cart quantity with variables: {}", variables);

		JsonNode response = webClient.post()
				.uri(cartServiceUrl + GRAPHQL_PATH)
				.bodyValue(requestBody)
				.retrieve()
				.bodyToMono(JsonNode.class)
				.blockOptional()
				.orElseThrow(() -> new RuntimeException("Cart service response was empty or failed."));

		log.debug("Received fetchCartQuantity response: {}", response);

		List<CartQuantityDetails> result = new ArrayList<>();
		JsonNode items = response.path("data").path("getCartQuantity");

		if (items.isArray()) {
			for (JsonNode item : items) {
				Long skuId = item.path("skuId").asLong();
				int cartQuanity = item.path("cartQuanity").asInt();
				result.add(new CartQuantityDetails(0, 0, skuId, cartQuanity));
			}
		}

		return result;
    }
    
//    public int fallbackFetchCartQuantity(Long memberId, Long itemId, Long basketId, Long variantTypeId, Throwable t) {
//        log.error("Fallback for fetchCartQuantity triggered due to {}", t.toString());
//        log.error("Fallback for fetchCartQuantity triggered due to {}", 0);
//        return 0;  
//    }
    
    public List<CartDTO> addToCart(List<AddToCartRequest> requestList) {
		String graphqlQuery = CartOrchestratorQuery.getAddToCartQuery();
		Map<String, Object> body = new HashMap<>();
		body.put("query", graphqlQuery);
		body.put("variables", Map.of("input", requestList));
		
	    log.info("Adding to cart: {} items", requestList.size());

		JsonNode response = webClient.post().uri(cartServiceUrl + "/graphql").bodyValue(body).retrieve()
				.bodyToMono(JsonNode.class).block();

		if (response == null || response.get("data") == null || response.get("data").get("addCartDetails") == null) {
		      log.error("Invalid or empty response from Cart Service while adding to cart");
			throw new RuntimeException(ResponseContent.INVALID_CARTSERVICVE_EXCEPTION);
		}

		JsonNode cartDetails = response.get("data").get("addCartDetails");

		List<CartDTO> cartDTOList = new ArrayList<>();
		for (JsonNode node : cartDetails) {
			CartDTO cart = objectMapper.convertValue(node, CartDTO.class);
			cartDTOList.add(cart);
		}
		 log.info("Added {} items to cart successfully", cartDTOList.size());
		return cartDTOList;
	}
    
    public List<CartDTO> getCartDetailsByMemberId(Long memberId) {
		String query = CartOrchestratorQuery.getCartDetailsByMemberIdQuery();
		Map<String, Object> request = Map.of("query", query, "variables", Map.of("memberId", memberId));
		log.info("Fetching cart details by memberId: {}", memberId);
		Map<String, Object> response = webClient.post().uri(cartServiceUrl + "/graphql").bodyValue(request).retrieve()
				.bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {
				}).block();

		if (response == null || response.get("data") == null) {
		      log.error("No data returned from GraphQL for memberId {}", memberId);
			throw new RuntimeException(ResponseContent.NO_DATA_RETURNED_GRAPHQL);
		}

		Object dataObj = response.get("data");
		if (!(dataObj instanceof Map<?, ?> dataMap)) {
		      log.error("Invalid data structure in GraphQL response for memberId {}", memberId);
			throw new RuntimeException(ResponseContent.INVALID_GRAPHQL_EXCEPTION);
		}

		Object cartListObj = dataMap.get("getCartDetailsByMemberId");
		if (!(cartListObj instanceof List<?> cartList)) {
		      log.error("Expected a list in getCartDetailsByMemberId field for memberId {}", memberId);
			throw new RuntimeException(ResponseContent.EXCEPTED_LIST_EXCEPTION);
		}

		ObjectMapper mapper = new ObjectMapper();
		return mapper.convertValue(cartList, new TypeReference<List<CartDTO>>() {
		});
	}
	
}
