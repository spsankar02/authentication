package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor  
@AllArgsConstructor 
public class OrderItem {
	public OrderItem(Long skuId, Integer quantity, Double pricePerUnit, Double discountPerUnit, Double totalPrice,
			String type, Double dealPrice, Double dealDiscount, Boolean isOfferItem,String batchCode) {
		this.skuId = skuId;
		this.quantity = quantity;
		this.pricePerUnit = pricePerUnit;
		this.discountPerUnit = discountPerUnit;
		this.totalPrice = totalPrice;
		this.type = type;
		this.dealPrice = dealPrice;
		this.dealDiscount = dealDiscount;
		this.isOfferItem = isOfferItem;
		this.batchCode=batchCode;
	}

	private Long orderItemId;
    private Integer quantity;
    private Double pricePerUnit;
    private Double discountPerUnit;
    private Double totalPrice;
    private String type;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS")
    private LocalDateTime modifiedAt;
    private String createdBy;
    private String modifiedBy;
    private Long productId;
    private Double dealPrice;
    private Double dealDiscount;
    private Boolean orderReview;
    private Boolean isOfferItem;
    private Long memberId;
    private Long skuId;
    private Order orderId;
    private Long itemId;
    private Long basketId;
    private Long variantTypeId;
    private String batchCode;
    private MappingProductItemVariantSkuDto skuDetails;
    private List<Item> basketItems = new ArrayList<>(); // Or List<MappingBasketItemsDto> if you prefer


}
