package com.nalamfarms.orchestrators_service.dto;
import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateOrderRequest {
	 @NotNull
	 private Long amountInPaise; 
	 
    @NotBlank
    private String currency = "INR";
    private String receipt; 
    private String notes; 
    private Long memberId;
    
   
    
}
