package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class MemberCategoryOfferItemBasket {
	private Long mappingOfferItemBasketId;
	private Long offerId;
//	private Long itemId;
	private Long basket;
	private Long varientTypeId;
	private Long memberCategoryId;
	private LocalDateTime createdAt;
	private LocalDateTime modifiedAt;
	private Long createdBy;
	private Long modifiedBy;
	private MasterOffers masterOffers;
	private Baskets baskets;
	private Long skuId;
	private VariantList variantType;
}