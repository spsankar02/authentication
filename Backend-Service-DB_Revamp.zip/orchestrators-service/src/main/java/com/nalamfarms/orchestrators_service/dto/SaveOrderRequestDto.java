package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
public class SaveOrderRequestDto {
  private CartIdsDto cartIdsDto;
  private JsonNode cartDetailsNode;
  List<InventoryInput> inventoryList;
  List<MasterSkuPrice> skuPrices;

}
