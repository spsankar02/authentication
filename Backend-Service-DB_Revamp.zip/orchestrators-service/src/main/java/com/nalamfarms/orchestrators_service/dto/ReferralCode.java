package com.nalamfarms.orchestrators_service.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "member_mapping_referral_code")
public class ReferralCode {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "referral_code_id")
  private Long referral_code_id;

  @Column(name = "code"  ,nullable = false, unique = true)
  private String code;

  @ManyToOne
  @JoinColumn(name = "generated_by_member_id")
  @JsonBackReference
  private Member generatedByMemberId;

//  @ManyToOne
//  @JoinColumn(name = "approved_status_id")
//  private MasterApprovalStatus approvedStatusId;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @Column(name = "is_active")
  private Boolean isActive;

}