package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Data
public class MemberDetailsDto {

  private Long memberId;
  private String firstname;
  private String lastname;
  private String emailAddress;
  private Boolean isActive;
  private String token;
  private String phoneNumber;
  private String referralCode;
  

 	public MemberDetailsDto(Member member) {
 		this.memberId = member.getMemberId();
 		this.firstname = member.getFirstname();
 		this.lastname = member.getLastname();
 		this.emailAddress = member.getEmailAddress();
 		this.isActive = member.getIsActive();
 		this.token = member.getToken();
 		this.phoneNumber = member.getPhoneNumber();
 		this.referralCode = member.getReferralCodeId() != null 
 			    ? member.getReferralCodeId().getCode() 
 			    : null;
 	}
}
