package com.nalamfarms.orchestrators_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuotationItem {

	private Long id;

	private Long skuId;
	
	private Long itemId;
	
	private Long productId;
	
	private Long classificationId;
	
	private String itemCode;
	
	private String productCode;
	
	private String classificationCode;
	
	private Long variantTypeId;
	
	private String variantTypeCode;
	
	private String itemName;
	
	private String classificationName;
	
	private String productName;
	
	private String variantTypeName;

	private Integer quantity;

	private Long unitId;

	private Double unitPrice;

	private Double totalPrice;

	private Double discount;

}
