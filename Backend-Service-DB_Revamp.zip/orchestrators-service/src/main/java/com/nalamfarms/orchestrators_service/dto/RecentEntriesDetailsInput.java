package com.nalamfarms.orchestrators_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class RecentEntriesDetailsInput {
    @JsonProperty("member_id")
	 private String memberId;
	    private int limit;
	    private String type;
}
