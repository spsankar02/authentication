package com.nalamfarms.orchestrators_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class Order {

  private Long orderId;
  private Long memberId;
  private Member member;
  private BigDecimal subTotal;
  private BigDecimal discountAmount;
  private BigDecimal taxAmount;
  private BigDecimal grandTotal;
  private OrderStatus orderStatus;
  private String cancellationReason;
  private String paymentStatus;
  private String paymentMethod;
  private LocalDateTime orderDate ;
  private LocalDateTime modifiedAt;
  private Boolean isSubscribed;
  private Long deliveryAddressId;
  private MemberAddressDto memberAddressDto;
  private String customOrderId;
  private BigDecimal deliveryCharge;
  private BigDecimal surCharge;
  private Integer rewardSpentPoints;
  private BigDecimal rewardSpentAmount;
  private BigDecimal transactionAmount;
  private Boolean orderReview;
  private Long basketId;
  private List<OrderItem> orderItem;


}
