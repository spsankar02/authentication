package com.nalamfarms.orchestrators_service.dto;


import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InventoryMappingQuotationDemandItemsDto {

    private Long quotationId;

    private MasterVendor vendor;

    private Long vendorId;

    private Long skuId;

    private BigDecimal pricePerUnit;

    private LocalDateTime deliveryDate;

    private LocalDateTime createdAt;

    private LocalDateTime modifiedAt;

    private Long createdBy;

    private Long modifiedBy;

    private Long quotationStatusId;

    private QuotationStatus quotationStatus;

    private BigDecimal availableQuantity;

    private LocalDateTime approvedDate;

    private BigDecimal approvedQuantity;

    private InventoryTxnDemandDTO demand;

    private Long demandId;

    private String batchCode;

    private Long deliveryLocationId;
    private MappingProductItemVariantSkuDto skuDetails; // << added this

}
