package com.nalamfarms.orchestrators_service.dto;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class OrderSaveRequestDto {
    private Long cartId;
    private Long memberId;
    private Integer quantity;
    private BigDecimal priceAtAdd;
    private BigDecimal discountAtAdd;
    private BigDecimal taxAmount;
    private Integer type;
    private Boolean isActive;
    private Integer saveStatus;
    private Boolean isOfferItem;
    private Long mappingOfferId;
    private Long offerId;
    private Long skuId;




//  private Long memberId;
//  private Long itemId;
//  private Long BasketId;
//  private Integer quantity;
//  private BigDecimal pricePerUnit;
//  private BigDecimal discount;
//  private BigDecimal taxAmount;
//  private BigDecimal totalPrice;
}
