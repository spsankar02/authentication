package com.nalamfarms.inventory_service.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VendorDTO {

	    private Long vendorId;
	    private String name;
	    private String email;
	    private String phone;
	    private String website;
	    private String address;
	    private String city;
	    private String state;
	    private String country;
	    private String postalCode;
	    private String logoUrl;
	    private String bannerUrl;
	    private Boolean isActive;
	    private Boolean isVerified;
	    private Integer rating;
	    private String vendorType;
	    private String vendorCode;
	    private LocalDateTime createdAt;
	    private LocalDateTime updatedAt;
	}

