package com.nalamfarms.inventory_service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.InventoryMappingQuotationDemandItems;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrder;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface InventoryMappingQuotationDemandItemsRepository 
        extends JpaRepository<InventoryMappingQuotationDemandItems, Long> {


    @Query("SELECT COUNT(DISTINCT i.vendor.vendorId) FROM InventoryMappingQuotationDemandItems i " +
            "WHERE i.demand.demandId = :demandId")
    long countDistinctVendorsByDemandId(@Param("demandId") Long demandId);

    @Query("SELECT COALESCE(SUM(i.AvailableQuantity), 0) " +
            "FROM InventoryMappingQuotationDemandItems i " +
            "WHERE i.demand.demandId = :demandId")
    BigDecimal sumAvailableQuantityByDemandId(@Param("demandId") Long demandId);


	List<InventoryMappingQuotationDemandItems> findByDemand_DemandIdIn(List<Long> demandIds);


	@Query(value = "SELECT * FROM inventory_mapping_quotation_demand_items " + "WHERE demand_id = :demandId "
			+ "AND vendor_id = :vendorId " + "AND sku_id = :skuId", nativeQuery = true)
	Optional<InventoryMappingQuotationDemandItems> findByDemandAndVendorAndSku(@Param("demandId") Long demandId,
			@Param("vendorId") Long vendorId, @Param("skuId") Long skuId);


    Page<InventoryMappingQuotationDemandItems> findByDemand_DemandIdIn(List<Long> demandIds, Pageable pageable );

    Page<InventoryMappingQuotationDemandItems> findByquotationIdIn(List<Long> demandIds, Pageable pageable );

    Page<InventoryMappingQuotationDemandItems> findByDemand_DemandIdInAndQuotationIdIn(
            List<Long> demandIds,
            List<Long> quotationIds,
            Pageable pageable
    );

//	List<InventoryMappingQuotationDemandItems> findByDemandIdAndVendorIdAndQuotationStatusId(Long demandId,
//			Long vendorId, Long quotationStatusId);

	List<InventoryMappingQuotationDemandItems> findByDemandIdAndVendorId(Long demandId, Long vendorId);

	List<InventoryMappingQuotationDemandItems> findByDemandId(Long demandId);

	long countDistinctByVendorId(Long vendorId);

	@Query("""
		    SELECT COUNT(DISTINCT i.skuId, i.demandId)
		    FROM InventoryMappingQuotationDemandItems i
		    WHERE i.vendorId = :vendorId
		      AND i.quotationStatusId = 2
		""")
	Long countApprovedSkuPerDemand(Long vendorId);

	@Query("""
		    SELECT COUNT(DISTINCT i.skuId, i.demandId)
		    FROM InventoryMappingQuotationDemandItems i
		    WHERE i.vendorId = :vendorId
		      AND i.quotationStatusId = 1
		""")
	Long countPendingSkuPerDemand(Long vendorId);

	List<InventoryMappingQuotationDemandItems> findAllByVendorId(Long vendorIds);

	List<InventoryMappingQuotationDemandItems> findByDemand_DemandIdInAndVendorId(List<Long> demandIds, Long vendorIds);

	List<InventoryMappingQuotationDemandItems> findByVendorIdAndQuotationStatusId(Long vendorId, long l);

	List<InventoryMappingQuotationDemandItems> findByDemand_DemandIdInAndVendorIdAndQuotationStatusId(
			List<Long> demandIds, Long vendorId, long l);

}
