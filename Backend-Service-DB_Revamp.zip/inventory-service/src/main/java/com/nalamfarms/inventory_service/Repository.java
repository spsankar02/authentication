package com.nalamfarms.inventory_service;

import com.nalamfarms.inventory_service.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Repository extends JpaRepository<Inventory,Long> {
}
