package com.nalamfarms.inventory_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.MasterInventoryCertificateStatus;

@Repository
public interface MasterInventoryCertificateStatusRepository
		extends JpaRepository<MasterInventoryCertificateStatus, Long> {

}
