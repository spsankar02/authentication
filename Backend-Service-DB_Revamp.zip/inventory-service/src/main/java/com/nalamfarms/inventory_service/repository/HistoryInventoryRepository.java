package com.nalamfarms.inventory_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.HistoryInventory;

@Repository
public interface HistoryInventoryRepository  extends JpaRepository<HistoryInventory, Long>{
	
	

}
