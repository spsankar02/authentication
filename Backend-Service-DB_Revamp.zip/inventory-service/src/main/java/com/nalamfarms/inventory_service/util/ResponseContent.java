package com.nalamfarms.inventory_service.util;

import java.util.List;

public class ResponseContent {
	
	private ResponseContent() {}
	
	/**========== ERROR MESSAGES ==========**/
	public static final String UPDATE_ERRORMESSAGE="Error Occurred While Updating";
	public static final String REQUEST_CANNOT_BE_NULL="Request Cannot be Null";
	public static final String INVENTORY_UPDATE_ERRORMESSAGE="Error Occurred While Updating the Inventory Details";

	public static final String PURCHASE_ITEM_ID_NOT_FOUND="No Records Found For PurchaseItem Id:";
	public static final String STATUS_ID_NOT_FOUND="No Records Found For PurchaseItem Id:";
	public static final String CANNOT_UPDATE_AGAIN="The status is already set to this value. Cannot update again";
	public static final String UPLOAD_FAILED="QR Code generation/upload failed";
	public static final String PURCHASE_MASTER_CANNOT_NULL="PurchaseMaster cannot be null";
	public static final String PURCHASE_ITEM_CANNOT_NULL="PurchaseItem cannot be null";
	public static final String MISSING_DATA="Missing required data for approving quotation.";
	public static final String QUATATION_ID_NOT_FOUND="Quotation ID not found in matching quotations.";
	public static final String INVALID_INVOICESTATUS_ID_NOT_FOUND="Invoice ID not found in matching Invoice Details.";

	 /** ========== EXCEPTION MESSAGES ========== */
	public static final String INVENTORY_REQUEST_EXCEPTION="Inventory request is null";
	public static final String INVENTORY_MISSING_EXCEPTION="Missing SKU or batchCode for request";
	public static final String INVENTORY_NOTFOUND_EXCEPTION="Inventory not found for skuId and batch code";
	public static final String INVENTORY_INSUFFICIENT_EXCEPTION="Insufficient stock for skuId and batch code availability ";
	public static final String INVENTORY_CHECK_EXCEPTION="Failed to check inventory quantity";
	public static final String INVENTORY_UPLOAD_EXCEPTION="Failed during inventory upload";
	public static final String ACTION_TYPE_EXCEPTION ="Provide me the ActionType";
	public static final String	INVALID_ACTION_TYPE_EXCEPTION="Invalid inventory input for the provided action.";
	public static final String ERROR_MESSAGE="Error while Saving";
	public static final String ID_NOT_FOUND="Purchase Master ID Not Found";
	/** ========== SUCCESS MESSAGES ========== */
	public static final String INVENTORY_NOT_FOUND = "No matching inventory found";
	public static final String INVENTORY_CHECK_COMPLETED ="Inventory check completed";
	public static final String INVENTORY_UPDATE_MESSAGE="Inventory details updated sucessfully";
	public static final String INVENTORY_PRODUCT_UPDATE_SUCCESS_TEMPLATE ="Product Inventory updated successfully with Product Id: %s and Item Id: %s and Action TypeId: %s";
	public static final String BASKET_INVENTORY_UPDATE_SUCCESS_TEMPLATE ="Basket Inventory updated successfully with Basket Id: %s and VariantTypeId: %s and Action TypeId: %s";
	public static final String INVENTORY_ITEMS_AVAILABLE ="All items available";
	public static final String SAVED_SUCCESS_MESSAGE =" Saved Successfully";
	public static final String CREATED_DEMAND_SUCCESSFULLY =" Created Demand Successfully";
	

	/** ========== STATUS MESSAGES ========== */
	public static final String PENDING="Pending";
	public static final String CONFIRMED="Confirmed";


	public static final String PROVIDED_QUOTATION_NOT_FOUND = "Provided Quotation Id Not Found";
	public static final String DELETE_SUCESSFULLY = "Deleted Sucessfully";
	public static final String INVALID_STATUS_ID = "Provided Invalid Status Id:";
	public static final String NO_RECORDS_FOUND_WITH_QUOTATIONID = "No Records Found with Quotation Id";
	public static final String UPDATED_SUCESSFULLY = "Updated Successfully...!";
	public static final String SAVE_SUCCESS = "Master Vendor Details Saved Successfully";
	public static final String INVENTORY_UPDATE_EXCEPTION = "Inventory Update Exception";
	public static final String UPDATE_UNSUCCESSFULL = "Failed to Update...!";
	public static final String QRPATH_UPDATED_SUCESSFULLY="QR path updated successfully for PurchaseItem ID";
	public static final String QUATATION_APPROVED="Quotation approved and purchase process initiated successfully.";
	public static final String QUATATION_ALREADY_MOVED="Quotation already moved to PurchaseInitiated.";
	public static final String FAILED_TO_SAVE="Failed to save PurchaseMaster.";
	public static final String ITEMS_CREATED_SUCCESS="Purchase items created successfully.";
	public static final String NO_REQUEST_PROVIDED = "No requests provided";
	public static final String UPDATE_MISSING_IDS = "Updated with missing IDs: ";
	public static final String INVOICE_ID = "Invoice ID";
	public static final String ALREADY_SAME_STATUS = " Already has the same status";
	public static final String FAILED = " failed: ";
	public static final String INVOICE_ITEM_NOT_FOUND = " Invoice Item not found with ID: " ;
	public static final String DETAILS = " | Details: ";
}

