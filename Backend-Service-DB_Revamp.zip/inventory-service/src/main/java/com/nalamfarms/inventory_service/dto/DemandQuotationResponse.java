package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DemandQuotationResponse {

    private DemandDTO demand;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class DemandDTO {
        private Long demandId;
        private String demandCode;
        private String demandStatus;
        private String notes;
        private LocalDateTime createdDate;
	    private LocalDateTime modifiedDate;
	    private LocalDate  demandEndDate;
	    private LocalDate  previousEndDate;
        private List<DemandItemDTO> demandItems;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class DemandItemDTO {
        private Long skuId;
        private BigDecimal demandQuantity;
        private List<VendorQuotationDTO> vendors;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class VendorQuotationDTO {
        private Long vendorId;
        private String name;
        private String email;
        private String phone;
        private BigDecimal price;
        private BigDecimal availableQuantity;
        private BigDecimal approvedQuantity;
        private LocalDateTime deliveryDate;
        private Long quotationStatusId;
        private String quotationStatus;
        private LocalDateTime approvedDate;
        private String batchCode;
        private Long rackId;
        
    }
}

