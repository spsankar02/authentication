package com.nalamfarms.inventory_service.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;
import lombok.ToString;

@Data
@Entity
@Table(name = "inventory_master_purchase_order_invoice")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) // ✅ Ignore Hibernate internals globally
public class InventoryMasterPurchaseOrderInvoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "invoice_id")
    private Long invoiceId;

    @Column(name = "invoice_code")
    private String invoiceCode;

    @Column(name = "purchase_order_id")
    private Long purchaseOrderId;

    @Column(name = "demand_id")
    private Long demandId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "demand_id", nullable = false, insertable = false, updatable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) // ✅ prevent proxy serialization
    @ToString.Exclude
    private InventoryTxnDemand demand;

    @Column(name = "vendor_id")
    private Long vendorId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vendor_id", insertable = false, updatable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler", "invoices"}) // ✅ ignore nested invoices
    @ToString.Exclude
    private MasterVendor masterVendor;

    @Column(name = "invoice_date")
    private LocalDate invoiceDate;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt;

    @OneToMany(mappedBy = "invoice")
    @JsonManagedReference
    @ToString.Exclude
    private List<InventoryMappingInvoiceItem> items;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "invoice_status", nullable = false, insertable = false, updatable = false)
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private MasterInventoryInvoiceStatus invoiceStatus;

    @Column(name = "invoice_status")
    private Long invoiceStatusId;

    @Column(name = "grand_total")
    private BigDecimal grandTotal;
    
    @Column(name = "shipping_status_id")
    private Long shippingStatusId;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipping_status_id", nullable = false,insertable = false,updatable = false)  
    private InventoryMasterPurchaseShippingStatus shippingStatus;
    
    @Column(name = "shipping_amount")
    private BigDecimal shippingAmount;
    
    @Column(name = "invoice_settlement_date")
    private LocalDate invoiceSettlementDate;
    
    @Transient
    private String fromAddress = "NALAM, 90 200 Feet Radial Rd, Zamin Pallavaram, Perumal Nagar Extension, Old Pallavaram, Chennai - 600117, Tamil Nadu";
}
