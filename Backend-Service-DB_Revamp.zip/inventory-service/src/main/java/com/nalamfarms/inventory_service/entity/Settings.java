package com.nalamfarms.inventory_service.entity;

import jakarta.persistence.*;
import lombok.Data;
import jakarta.persistence.Id;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name="Settings")
public class Settings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "setting_id")
    private Long SettingId;

    @Column(name = "name")
    private String name;

    @Column(name = "value")
    private String Value;

    @Column(name = "category")
    private String category;

    @Column(name = "description")
    private String description;

    @Column(name = "modified_at")
    private LocalDateTime lastModifiedAt;

    @Column(name = "is_active")
    private Boolean isActive=true;

    @Column(name = "created_at")
    private LocalDateTime createdAt=LocalDateTime.now();
}
