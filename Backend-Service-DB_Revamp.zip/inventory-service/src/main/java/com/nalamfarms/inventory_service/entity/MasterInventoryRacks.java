package com.nalamfarms.inventory_service.entity;

import jakarta.persistence.*;
import lombok.Data;
import jakarta.persistence.Id;
@Data
@Entity
@Table(name = "inventory_master_racks")
public class MasterInventoryRacks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rack_id")
    private Long rackId;

    @Column(name = "warehouse_id")
    private Long wareHouseId;
    @Column(name = "zone")
    private String Zone;
    @Column(name = "aisle")

    private String aisle;
    @Column(name = "bay")

    private String bay;
    @Column(name = "level")

    private String level;
    @Column(name = "position")

    private String position;
    @Column(name = "rack_type")
    private Long rackType;

}
