package com.nalamfarms.inventory_service.util;

import com.nalamfarms.inventory_service.dto.UpdateInventorySkuDto;
import com.nalamfarms.inventory_service.dto.updateBasketInventory;
import com.nalamfarms.inventory_service.dto.updateProductInventory;
import com.nalamfarms.inventory_service.entity.HistoryInventory;
import com.nalamfarms.inventory_service.entity.Inventory;
import com.nalamfarms.inventory_service.repository.HistoryInventoryRepository;
import com.nalamfarms.inventory_service.repository.InventoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Component
public class InventoryActionStatusUtil {

  @Autowired
  private HistoryInventoryRepository historyInventoryRepo;

  @Autowired
  private InventoryRepository inventoryRepository;
  
  private static final Logger log = LoggerFactory.getLogger(InventoryActionStatusUtil.class);


  public String updateInventoryActionStatusUtil(updateProductInventory productInventory,
                                                updateBasketInventory basketInventory) {
    try {

      Long actionTypeId = (productInventory != null) ? productInventory.getActionType()
        : (basketInventory != null ? basketInventory.getActionType() : null);

      if (actionTypeId == null)
      {
          log.warn("ActionType is missing in inventory update request.");
        throw new IllegalArgumentException(ResponseContent.ACTION_TYPE_EXCEPTION);
      }

      String result;

      if (productInventory != null && productInventory.getProductId() != null
        && productInventory.getItemId() != null) {
          log.info("Processing product inventory update: {}", productInventory);
        processProductInventory(productInventory, actionTypeId);
         result = String.format(ResponseContent.INVENTORY_PRODUCT_UPDATE_SUCCESS_TEMPLATE, productInventory.getProductId(), productInventory.getItemId(), actionTypeId);
      } else if (basketInventory != null && basketInventory.getBasketId() != null
        && basketInventory.getVariantTypeId() != null) {
          log.info("Processing basket inventory update: {}", basketInventory);
        processBasketInventory(basketInventory, actionTypeId);
         result = String.format(ResponseContent.BASKET_INVENTORY_UPDATE_SUCCESS_TEMPLATE,basketInventory.getBasketId(),basketInventory.getVariantTypeId(),actionTypeId);
         } else {
          log.warn("Invalid inventory input for the provided action.");
        throw new IllegalArgumentException(ResponseContent.INVALID_ACTION_TYPE_EXCEPTION);
      }

      return result;
    } catch (Exception ex) {
    	 log.error("Error occurred while updating inventory details", ex);
      ex.printStackTrace();
      return ResponseContent.INVENTORY_UPDATE_ERRORMESSAGE + ex.getMessage();
    }
  }

  private void processProductInventory(updateProductInventory productInventory, Long actionTypeId) {
    Long productId = productInventory.getProductId();
    Long itemId = productInventory.getItemId();
    Long variantTypeId= productInventory.getVariantTypeId();
    BigDecimal quantityChange = calculateQuantityChange(productInventory.getQuantity(), actionTypeId);
    //Inventory Changes
    Inventory inventory = null;
//    		/inventoryRepository
//      .findByProductIdAndItemIdAndVariantTypeId(productId, itemId,variantTypeId)
//      .orElseGet(() -> {
//        Inventory newInventory = new Inventory();
        //newInventory.setProductId(productId);
        //newInventory.setItemId(itemId);
        //newInventory.setQuantityAvailable(BigDecimal.ZERO);
        //newInventory.setVariantTypeId(variantTypeId);
//        return newInventory;
//      });
    if (actionTypeId != 3 && actionTypeId != 5 && actionTypeId != 11) {
      BigDecimal newQtyAvailable = inventory.getQuantityAvailable() .add(quantityChange);
      inventory.setQuantityAvailable(
              newQtyAvailable.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyAvailable
      );
    }

    if (actionTypeId == 5) {
      BigDecimal newQtyAvailable = inventory.getQuantityAvailable().add(quantityChange);
      inventory.setQuantityAvailable(
              newQtyAvailable.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyAvailable
      );

      BigDecimal newQtyReserved = inventory.getQuantityReserved().add(quantityChange);
      inventory.setQuantityReserved(
              newQtyReserved.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyReserved
      );
    }

    if (actionTypeId == 3) {
      inventory.setQuantityReserved(inventory.getQuantityReserved() .add(quantityChange));
    }

    if(actionTypeId == 11) {
      if (productInventory.getOrderStatus() == ResponseContent.PENDING) {
        inventory.setQuantityReserved(inventory.getQuantityReserved().subtract(productInventory.getQuantity()));
      }
      if (productInventory.getOrderStatus() == ResponseContent.CONFIRMED) {
        inventory.setQuantityAvailable(inventory.getQuantityAvailable().subtract(productInventory.getQuantity()));

      }
    }

    Inventory savedInventory = inventoryRepository.save(inventory);
    log.debug("Updated product inventory: Available Quantity = {}", savedInventory.getQuantityAvailable());
    createProductHistory(productId, itemId, savedInventory.getInventoryId(), quantityChange, actionTypeId);
  }

  private void processBasketInventory(updateBasketInventory basketInventory, Long actionTypeId) {
    Long basketId = basketInventory.getBasketId();
    Long variantTypeId = basketInventory.getVariantTypeId();
    BigDecimal quantityChange = calculateQuantityChange(basketInventory.getQuantity(), actionTypeId);

    Inventory inventory =null;
    //inventoryRepository
//      .findByBasketIdAndVariantTypeId(basketId, variantTypeId)
//      .orElseGet(() -> {
//        Inventory newInventory = new Inventory();
//        //newInventory.setBasketId(basketId);
//        //newInventory.setVariantTypeId(variantTypeId);
//        //newInventory.setQuantityAvailable(BigDecimal.ZERO);
//        return newInventory;
//      });

    if (actionTypeId != 3 && actionTypeId != 5 && actionTypeId != 11) {
      BigDecimal newQtyAvailable = inventory.getQuantityAvailable() .add(quantityChange) ;
      inventory.setQuantityAvailable(newQtyAvailable.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyAvailable);
    }

    if (actionTypeId == 5) {
      BigDecimal newQtyAvailable = inventory.getQuantityAvailable() .add(quantityChange);
      inventory.setQuantityAvailable( newQtyAvailable.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyAvailable);
      BigDecimal newQtyReserved = inventory.getQuantityReserved() .add(quantityChange);
      inventory.setQuantityReserved(newQtyReserved.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyReserved);
    }

    if (actionTypeId == 3) {
      BigDecimal QuantityReserved = inventory.getQuantityReserved()!= null ? inventory.getQuantityReserved(): BigDecimal.ZERO;
      inventory.setQuantityReserved(QuantityReserved .add(quantityChange));
    }
    if(actionTypeId == 11){
      if(basketInventory.getOrderStatus()==ResponseContent.PENDING){
        inventory.setQuantityReserved(inventory.getQuantityReserved() .subtract(basketInventory.getQuantity()));

      }
      if(basketInventory.getOrderStatus()==ResponseContent.CONFIRMED){

        inventory.setQuantityAvailable(inventory.getQuantityAvailable() .add(basketInventory.getQuantity()));
  }
    }

    Inventory savedInventory = inventoryRepository.save(inventory);
    log.debug("Updated basket inventory: Available Quantity = {}", savedInventory.getQuantityAvailable());
    createBasketHistory(basketId, variantTypeId, savedInventory.getInventoryId(), quantityChange, actionTypeId);
  }

  private BigDecimal calculateQuantityChange(BigDecimal quantity, Long actionTypeId) {
    switch (actionTypeId.intValue()) {
      case 1: // ADD
        return quantity;
      case 5: // SALE
        return quantity.negate();
      case 6:// RETURN
        return quantity;
      case 11:// CANCEL
        return quantity;
      case 3://RESERVE
        return quantity;
      default:
        throw new IllegalArgumentException(ResponseContent.INVALID_ACTION_TYPE_EXCEPTION + actionTypeId);
    }
  }

  private void createProductHistory(Long productId, Long itemId, Long inventoryId, BigDecimal quantity, Long actionType) {
    if (actionType != 3) {
      HistoryInventory history = new HistoryInventory();
      history.setInventoryId(inventoryId);
//      history.setProductId(productId);
//      history.setItemId(itemId);
      history.setQuantityAvailable(quantity);
      history.setCreatedAt(new Date());
      history.setActionType(actionType);
      historyInventoryRepo.save(history);
      log.debug("Created product inventory history for productId={}, itemId={}", productId, itemId);

    }
  }

  private void createBasketHistory(Long basketId, Long variantTypeId, Long inventoryId, BigDecimal quantity, Long actionType) {
    if (actionType != 3) {
      HistoryInventory history = new HistoryInventory();
      history.setInventoryId(inventoryId);
//      history.setBasketId(basketId);
//      history.setVariantTypeId(variantTypeId);
      history.setQuantityAvailable(quantity);
      history.setCreatedAt(new Date());
      history.setActionType(actionType);
      historyInventoryRepo.save(history);
      log.debug("Created basket inventory history for basketId={}, variantTypeId={}", basketId, variantTypeId);

    }
  }
  
  
//  public void CalculateQuantityAvailableAndReserved(Long actionType,)
//  {
//	  if (actionTypeId != 3 && actionTypeId != 5 && actionTypeId != 11) {
//	      BigDecimal newQtyAvailable = inventory.getQuantityAvailable() .add(quantityChange) ;
//	      inventory.setQuantityAvailable(newQtyAvailable.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyAvailable);
//	    }
//
//	    if (actionTypeId == 5) {
//	      BigDecimal newQtyAvailable = inventory.getQuantityAvailable() .add(quantityChange);
//	      inventory.setQuantityAvailable( newQtyAvailable.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyAvailable);
//	      BigDecimal newQtyReserved = inventory.getQuantityReserved() .add(quantityChange);
//	      inventory.setQuantityReserved(newQtyReserved.compareTo(BigDecimal.ZERO) <= 0 ? BigDecimal.ZERO : newQtyReserved);
//	    }
//
//	    if (actionTypeId == 3) {
//	      BigDecimal QuantityReserved = inventory.getQuantityReserved()!= null ? inventory.getQuantityReserved(): BigDecimal.ZERO;
//	      inventory.setQuantityReserved(QuantityReserved .add(quantityChange));
//	    }
//	    if(actionTypeId == 11){
//	      if(basketInventory.getOrderStatus()==ResponseContent.PENDING){
//	        inventory.setQuantityReserved(inventory.getQuantityReserved() .subtract(basketInventory.getQuantity()));
//
//	      }
//	      if(basketInventory.getOrderStatus()==ResponseContent.CONFIRMED){
//
//	        inventory.setQuantityAvailable(inventory.getQuantityAvailable() .add(basketInventory.getQuantity()));
//	  }
//
//  }
  
  
//	private void updateInventoryWithSku(List<UpdateInventorySkuDto> updateInventorySkuRequestList) {
//		
//		updateInventorySkuRequestList.stream().map(skuList->{
//			BigDecimal quantityChange = calculateQuantityChange(skuList.getQuantity(), skuList.getActionType());
//			Inventory inventory=new Inventory();
//		});
//		
//
//	}
}
