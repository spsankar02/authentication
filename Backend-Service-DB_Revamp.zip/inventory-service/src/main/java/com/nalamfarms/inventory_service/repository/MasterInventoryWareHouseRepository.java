package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.MasterInventoryRacksType;
import com.nalamfarms.inventory_service.entity.MasterInventoryWareHouse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterInventoryWareHouseRepository extends JpaRepository<MasterInventoryWareHouse, Long> {

}
