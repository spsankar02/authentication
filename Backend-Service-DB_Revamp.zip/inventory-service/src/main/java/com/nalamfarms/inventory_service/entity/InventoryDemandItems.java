package com.nalamfarms.inventory_service.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;
import lombok.ToString;

@Entity
@Table(name = "inventory_mapping_demand_items", schema = "public")
@Data
public class InventoryDemandItems {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "demand_item_id", nullable = false)
	    private Long demandItemId;

	    @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "demand_id", nullable = false, foreignKey = @ForeignKey(name = "fk_demand_id"),insertable=false, updatable=false)
	    @ToString.Exclude
	    @JsonBackReference
	    private InventoryTxnDemand demand;

	    @Column(name = "sku_id")
	    private Long skuId;

	    @Column(name = "quantity", precision = 19, scale = 2)
	    private BigDecimal quantity;

	    @Column(name = "created_at")
	    private LocalDateTime createdAt;

	    @Column(name = "modified_at")
	    private LocalDateTime modifiedAt;

	    @Column(name = "created_by")
	    private Long createdBy;

	    @Column(name = "modified_by")
	    private Long modifiedBy;
	    
	    @Transient
	    private Long quotationStatusId;
	    
	    @Transient
	    private String quotationStatus;
	    
	    @Transient
	    private String approvedQuantity;
	    
	    @Transient
	    private String approvedDate;
	    
	    @Transient
		private boolean approved;
	    
	    @Column(name = "demand_id", nullable = false)
	    private Long demandId;  // FK to inventory_txn_demand
	
	    

}
