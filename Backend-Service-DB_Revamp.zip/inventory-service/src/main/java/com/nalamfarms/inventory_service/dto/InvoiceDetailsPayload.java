package com.nalamfarms.inventory_service.dto;

import lombok.Data;

import java.util.List;

@Data
public class InvoiceDetailsPayload {

    List<Long> demandIds;
    int page;
    int pageSize;
}
