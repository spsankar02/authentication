package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceItemResponse {
	
	private Long invoiceItemId;
	
	private Long skuId;
	
	//private Long shippingStatusId;
	
	//private String shippingStatusName;
		
	private BigDecimal totalPrice;
	
	//private BigDecimal shippingAmount;
	
	private Long quantity;
	
	private BigDecimal pricePerUnit;

}
