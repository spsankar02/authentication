package com.nalamfarms.inventory_service.dto;



import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@RequiredArgsConstructor
@Data
public class OrderEventDto {

  @JsonProperty("orderId")
  private Long orderId;

  @JsonProperty("memberId")
  private Long memberId;

  @JsonProperty("subTotal")
  private BigDecimal subTotal;

  @JsonProperty("discountAmount")
  private BigDecimal discountAmount;

  @JsonProperty("taxAmount")
  private BigDecimal taxAmount;

  @JsonProperty("grandTotal")
  private BigDecimal grandTotal;

  @JsonProperty("status")
  private String status;

  @JsonProperty("paymentStatus")
  private String paymentStatus;

  @JsonProperty("paymentMethod")
  private String paymentMethod;

  @JsonProperty("deliveryCharge")
  private BigDecimal deliveryCharge;

  @JsonProperty("surCharge")
  private BigDecimal surCharge;
  
  @JsonProperty("customerOrderId")
  private String customerOrderId;
  
  @JsonProperty("eventStatus")
  private String eventStatus;
  
  @JsonProperty("razorPayPaymentId")
  private String razorPayPaymentId;
  
  @JsonProperty("razorPayOrderId")
  private String razorPayOrderId;
  
  @JsonProperty("inventoryFailedReason")
  private String inventoryFailedReason;

  @JsonProperty("items")
  private List<OrderItemDto> items;


}
