package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.MasterInventoryRacksType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterInventoryRacksTypeRepository extends JpaRepository<MasterInventoryRacksType, Long> {
}
