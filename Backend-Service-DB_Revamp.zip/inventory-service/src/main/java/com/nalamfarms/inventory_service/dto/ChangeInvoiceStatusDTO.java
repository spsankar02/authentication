package com.nalamfarms.inventory_service.dto;

import lombok.Data;

@Data
public class ChangeInvoiceStatusDTO {
    private Long invoiceId;
    private Long invoiceStatusId;


}
