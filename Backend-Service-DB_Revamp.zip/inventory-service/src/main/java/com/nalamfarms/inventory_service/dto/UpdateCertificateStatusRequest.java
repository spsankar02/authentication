package com.nalamfarms.inventory_service.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateCertificateStatusRequest {
	
	private Long purchaseOrderItemId;
	
	private Long certificateStatusId;
	
	private Long certificateTypeId;
	
	

}
