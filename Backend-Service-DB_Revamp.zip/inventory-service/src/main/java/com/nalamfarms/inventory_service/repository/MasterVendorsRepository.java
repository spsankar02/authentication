package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.MasterInventoryRacksType;
import com.nalamfarms.inventory_service.entity.MasterVendor;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterVendorsRepository extends JpaRepository<MasterVendor, Long> {

	MasterVendor findByVendorId(Long vendorId);
}
