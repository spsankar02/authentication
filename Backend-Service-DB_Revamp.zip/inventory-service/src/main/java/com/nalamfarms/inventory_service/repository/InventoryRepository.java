package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface InventoryRepository  extends JpaRepository<Inventory, Long>{

//	Optional<Inventory> findByProductIdAndItemIdAndVariantTypeId(Long productId, Long itemId,Long variantTypeId);
//
//	Optional<Inventory> findByBasketIdAndVariantTypeId(Long basketId, Long variantTypeId);

	Optional<Inventory> findBySkuIdAndBatchCode(Long skuId, String batchCode);
	@Query(value = """
        SELECT mpivs.sku_id AS skuId, 
               p.product_name AS productName, 
               i.item_name AS itemName, 
               mvt.variant_type_name AS variantTypeName, 
               COALESCE(SUM(tinv.quantity_available), 0) AS totalQuantity
        FROM product_mapping_product_item_variant_sku mpivs
        LEFT JOIN product_master_items i ON i.item_id = mpivs.item_id
        LEFT JOIN product_master_products p ON p.product_id = i.product_id
        LEFT JOIN product_master_variants_type mvt ON mvt.variant_type_id  = mpivs.variant_type_id
        LEFT JOIN inventory_txn_inventory tinv ON tinv.sku_id = mpivs.sku_id
        GROUP BY mpivs.sku_id, i.item_name, p.product_name, mvt.variant_type_name
        """, nativeQuery = true)
	List<Object[]> getLowStockReport();


    List<Inventory> findAllBySkuId(Long skuId);
}
