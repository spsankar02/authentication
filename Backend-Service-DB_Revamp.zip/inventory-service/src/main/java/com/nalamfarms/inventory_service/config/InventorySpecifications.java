package com.nalamfarms.inventory_service.config;

import org.springframework.data.jpa.domain.Specification;

import com.nalamfarms.inventory_service.entity.InventoryMappingPurchaseOrderItems;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrder;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;

public class InventorySpecifications {
	
	public static Specification<InventoryMasterPurchaseOrder> purchaseOrderInitiated() {
        return (root, query, cb) -> cb.isNotNull(root.get("purchaseOrderCode"));
    }

    public static Specification<InventoryMasterPurchaseOrder> inventoryMoved() {
        return (root, query, cb) -> {
            Join<InventoryMasterPurchaseOrder, InventoryMappingPurchaseOrderItems> items =
                    root.join("purchaseOrderItems", JoinType.INNER);
            query.distinct(true);
            return cb.isTrue(items.get("isInventoryMoved"));
        };
    }

    public static Specification<InventoryMasterPurchaseOrder> orderShipped() {
        return (root, query, cb) -> {
            Join<InventoryMasterPurchaseOrder, InventoryMappingPurchaseOrderItems> items =
                    root.join("purchaseOrderItems", JoinType.INNER);
            query.distinct(true);
            return cb.equal(items.get("shippingStatusId"), 5L); // example SHIPPED
        };
    }

    public static Specification<InventoryMasterPurchaseOrder> certifyProducts() {
        return (root, query, cb) -> {
            Join<InventoryMasterPurchaseOrder, InventoryMappingPurchaseOrderItems> items =
                    root.join("purchaseOrderItems", JoinType.INNER);
            query.distinct(true);
            return cb.equal(items.get("certificateStatusId"), 2L); // example SUBMITTED
        };
    }

}
