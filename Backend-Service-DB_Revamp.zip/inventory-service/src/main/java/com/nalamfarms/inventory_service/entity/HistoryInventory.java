package com.nalamfarms.inventory_service.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Entity
@Table(name = "inventory_txn_inventory_activity", schema = "public")
@Data
public class HistoryInventory {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "history_id", nullable = false)
    private Long historyId;

    @Column(name = "inventory_id", nullable = false)
    private Long inventoryId;

    @Column(name = "quantity_available")
    private BigDecimal quantityAvailable;

    @Column(name = "quantity_reserved")
    private BigDecimal quantityReserved=BigDecimal.ZERO;

    @Column(name = "action_type")
    private Long actionType=1l;

    @Column(name = "created_at", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date createdAt=new Date();

    @Column(name = "modified_at")  
    @Temporal(TemporalType.DATE)
    private Date modifiedAt;

    @Column(name = "created_by")
    private Long createdBy=1l;

    @Column(name = "modified_by")
    private Long modifiedBy;
}