package com.nalamfarms.inventory_service.service;

import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nalamfarms.inventory_service.config.KafkaTopicVerifier;
import com.nalamfarms.inventory_service.dto.OrderEventDto;
import com.nalamfarms.inventory_service.dto.OrderHistoryEventDto;
//import com.nalamfarms.order_service.dto.OrderHistoryEventDto;


@Service
public class InventoryProducer {

  private static final Logger logger = LoggerFactory.getLogger(InventoryProducer.class);
  private final KafkaTemplate<String, Object> kafkaTemplate;
  private final KafkaTopicVerifier topicVerifier;

  public InventoryProducer(KafkaTemplate<String, Object> kafkaTemplate, KafkaTopicVerifier topicVerifier) {
    this.kafkaTemplate = kafkaTemplate;
    this.topicVerifier = topicVerifier;
  }

  public boolean sendpaymeneInitiated(OrderEventDto orderEvent,String inventoryMessage) {
    String topic  = "inventory.updated";
    if (!topicVerifier.doesTopicExist(topic)) {
      logger.error("Topic {} does not exist!", topic);
      return false;
    }
    try {
      CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send("inventory.updated", inventoryMessage);
      future.whenComplete(
        (result, ex) -> {
          if (ex == null) {
            logger.info("Produced message to inventory.updated: {}", inventoryMessage);
          } else {
            logger.error("Failed to send message to topic {}: {}", topic, ex.getMessage(), ex);
          }
        }
      );
      return true;
    } catch (Exception e) {
      logger.error("Failed to send message to topic {}: {}", topic, e.getMessage(), e);
      return false;
    }
  }

  public boolean sendOrderAuditEvent(String topic, OrderHistoryEventDto orderEventAudit) {
		if (!topicVerifier.doesTopicExist(topic)) {
			logger.error("Topic {} does not exist!", topic);
			return false;
		}

		try {
			ObjectMapper objectMapper=new ObjectMapper();
	        String jsonMessage = objectMapper.writeValueAsString(orderEventAudit);  

			CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic,
					orderEventAudit.getOrderId().toString(), jsonMessage);

			future.whenComplete((result, ex) -> {
				if (ex == null) {
					logger.info("✅ Successfully published audit event to topic '{}': orderId={}, event={}", topic,
							orderEventAudit.getOrderId(), orderEventAudit.getEventName());
				} else {
					logger.error("❌ Failed to publish audit event to topic '{}': {}", topic, ex.getMessage(), ex);
				}
			});

			return true;

		} catch (Exception e) {
			logger.error("❌ Exception while publishing audit event to topic '{}': {}", topic, e.getMessage(), e);
			return false;
		}
	}

	public boolean updateOrderConfirmed(String topic, OrderEventDto orderEventDto) {
		if (!topicVerifier.doesTopicExist(topic)) {
			logger.error("Topic {} does not exist!", topic);
			return false;
		}

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMessage = objectMapper.writeValueAsString(orderEventDto);

			CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, jsonMessage);

			future.whenComplete((result, ex) -> {
				if (ex == null) {
					logger.info("✅ Successfully published audit event to topic '{}': orderId={}, event={}", topic,
							orderEventDto.getOrderId());
				} else {
					logger.error("❌ Failed to publish audit event to topic '{}': {}", topic, ex.getMessage(), ex);
				}
			});

			return true;

		} catch (Exception e) {
			logger.error("❌ Exception while publishing audit event to topic '{}': {}", topic, e.getMessage(), e);
			return false;
		}

	}


	public boolean updateOrderCancelled(String topic, OrderEventDto orderEventDto) {
		if (!topicVerifier.doesTopicExist(topic)) {
			logger.error("Topic {} does not exist!", topic);
			return false;
		}

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMessage = objectMapper.writeValueAsString(orderEventDto);

			CompletableFuture<SendResult<String, Object>> future = kafkaTemplate.send(topic, jsonMessage);

			future.whenComplete((result, ex) -> {
				if (ex == null) {
					logger.info("✅ Successfully published audit event to topic '{}': orderId={}, event={}", topic,
							orderEventDto.getOrderId());
				} else {
					logger.error("❌ Failed to publish audit event to topic '{}': {}", topic, ex.getMessage(), ex);
				}
			});

			return true;

		} catch (Exception e) {
			logger.error("❌ Exception while publishing audit event to topic '{}': {}", topic, e.getMessage(), e);
			return false;
		}
		
	}

  	
}
