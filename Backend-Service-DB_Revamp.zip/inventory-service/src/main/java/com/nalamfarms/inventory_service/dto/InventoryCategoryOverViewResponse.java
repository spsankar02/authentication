package com.nalamfarms.inventory_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InventoryCategoryOverViewResponse {
	
	private Long DemandCount;
	 
    private Long QuotationReceivedCount;
 
    private Long PurchaseInitiatedCount;
 
    private Long purchaseOrderShippedCount;
    
    private Long purchaseInventoryUpdatedCount;
    
    private Long purchaseCertificatedCount;
    
    private Long purchaseInvoicePendingCount;

}
