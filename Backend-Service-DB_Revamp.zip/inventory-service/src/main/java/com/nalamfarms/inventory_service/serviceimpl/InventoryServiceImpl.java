package com.nalamfarms.inventory_service.serviceimpl;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import com.nalamfarms.inventory_service.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.zxing.WriterException;
import com.nalamfarms.inventory_service.config.InventorySpecifications;
import com.nalamfarms.inventory_service.entity.HistoryInventory;
import com.nalamfarms.inventory_service.entity.Inventory;
import com.nalamfarms.inventory_service.entity.InventoryDemandItems;
import com.nalamfarms.inventory_service.entity.InventoryMappingInvoiceItem;
import com.nalamfarms.inventory_service.entity.InventoryMappingPurchaseOrderItems;
import com.nalamfarms.inventory_service.entity.InventoryMappingQuotationDemandItems;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrder;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrderInvoice;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseShippingStatus;
import com.nalamfarms.inventory_service.entity.InventoryTxnDemand;
import com.nalamfarms.inventory_service.entity.MasterCertificateType;
import com.nalamfarms.inventory_service.entity.MasterInventoryCertificateStatus;
import com.nalamfarms.inventory_service.entity.MasterInventoryRacks;
import com.nalamfarms.inventory_service.entity.MasterInventoryRacksType;
import com.nalamfarms.inventory_service.entity.MasterInventoryStatus;
import com.nalamfarms.inventory_service.entity.MasterInventoryWareHouse;
import com.nalamfarms.inventory_service.entity.MasterVendor;
import com.nalamfarms.inventory_service.exception.InventoryCheckException;
import com.nalamfarms.inventory_service.repository.HistoryInventoryRepository;
import com.nalamfarms.inventory_service.repository.InventoryDemandItemsRepository;
import com.nalamfarms.inventory_service.repository.InventoryMappingInvoiceItemRepository;
import com.nalamfarms.inventory_service.repository.InventoryMappingPurchaseOrderItemsRepository;
import com.nalamfarms.inventory_service.repository.InventoryMappingQuotationDemandItemsRepository;
import com.nalamfarms.inventory_service.repository.InventoryMasterPurchaseOrderInvoiceRepo;
import com.nalamfarms.inventory_service.repository.InventoryMasterPurchaseOrderRepository;
import com.nalamfarms.inventory_service.repository.InventoryMasterPurchaseShippingStatusRepository;
import com.nalamfarms.inventory_service.repository.InventoryRepository;
import com.nalamfarms.inventory_service.repository.InventoryTxnDemandRepository;
import com.nalamfarms.inventory_service.repository.MasterCertificateTypeRepository;
import com.nalamfarms.inventory_service.repository.MasterInventoryCertificateStatusRepository;
import com.nalamfarms.inventory_service.repository.MasterInventoryInvoiceStatusRepository;
import com.nalamfarms.inventory_service.repository.MasterInventoryRacksRepository;
import com.nalamfarms.inventory_service.repository.MasterInventoryRacksTypeRepository;
import com.nalamfarms.inventory_service.repository.MasterInventoryStatusRepository;
import com.nalamfarms.inventory_service.repository.MasterInventoryWareHouseRepository;
import com.nalamfarms.inventory_service.repository.MasterVendorsRepository;
import com.nalamfarms.inventory_service.service.InventoryService;
import com.nalamfarms.inventory_service.util.ImageUploadUtil;
import com.nalamfarms.inventory_service.util.InventoryActionStatusUtil;
import com.nalamfarms.inventory_service.util.PurchaseOrderCodeGenerator;
import com.nalamfarms.inventory_service.util.QrCodeGenerator;
import com.nalamfarms.inventory_service.util.ResponseContent;
import com.nalamfarms.inventory_service.util.SkuGeneratorUtil;

import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InventoryServiceImpl implements InventoryService {

	private static final Logger log = LoggerFactory.getLogger(InventoryServiceImpl.class);

	@PostConstruct
	public void init() {
		log.info(">>> InventoryServiceImpl initialized with invoiceRepo={}, otherRepo={}",
				inventoryMasterPurchaseOrderInvoiceRepo);
	}

	private final InventoryRepository inventoryRepo;

	private final MasterVendorsRepository masterVendorsRepository;

	private final MasterInventoryWareHouseRepository masterInventoryWareHouseRepository;
	private final InventoryDemandItemsRepository inventoryMappingDemandItemRepo;
	// private final PurchaseOrderCodeGenerator codeGenerator;

	private final InventoryTxnDemandRepository inventoryTxnDemandRepository;
	private final MasterInventoryInvoiceStatusRepository masterInventoryInvoiceStatusRepository;

	@Autowired
	private InventoryActionStatusUtil inventoryActionStatusUtil;

	private final MasterInventoryRacksTypeRepository masterInventoryRacksTypeRepository;

	private final MasterInventoryRacksRepository masterInventoryRacksRepository;
	

	// private final PurchaseMasterRepository purchaseMasterRepository;
	// private final InventoryMappingPurchaseOrderItemsRepository
	// inventoryMappingPurchaseOrderItemsRepo;
	private final InvoiceImpl invoiceImpl;


	

	@Autowired
	private ObjectMapper objectMapper;

	@Value("${product.service.url}")
	private String productServiceUrl;

	@Autowired
	private WebClient.Builder webClientBuilder;

	@Autowired
	private MasterInventoryCertificateStatusRepository certificateStatusRepository;

	private final MasterInventoryStatusRepository masterInventoryStatusRepository;

	@Autowired
	private HistoryInventoryRepository historyInventoryRepo;


	@Autowired
	private InventoryMasterPurchaseShippingStatusRepository masterPurchaseShippingStatusRepository;



	@Autowired
	private QrCodeGenerator qrCodeGenerator;

	@Autowired
	private ImageUploadUtil imageUploadUtil;

	@Autowired
	private PurchaseOrderCodeGenerator purchaseOrderCodeGenerator;



	@Autowired
	private InventoryDemandItemsRepository inventoryDemandItemsRepository;

	@Autowired
	private InventoryMappingQuotationDemandItemsRepository inventoryQuotationDemandRepo;

	private final MasterCertificateTypeRepository certificateTypeRepository;

	@Autowired
	private InventoryMasterPurchaseOrderRepository purchaseOrderRepository;

	@Autowired
	private InventoryMasterPurchaseOrderRepository inventoryMasterPurchaseOrderRepository;

	@Autowired
	private InventoryMappingPurchaseOrderItemsRepository purchaseOrderItemsRepository;


	@Autowired
	private InventoryMasterPurchaseOrderInvoiceRepo inventoryMasterPurchaseOrderInvoiceRepo;

	@Autowired
	private InventoryMappingInvoiceItemRepository invoiceItemRepository;

	
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

	@Override
	public SaveResponse checkQuantityInInventory(WishListRequest request) {

		if (request == null || request.getQuantity() <= 0) {
			log.warn("Invalid inventory request received: {}", request);
			throw new IllegalArgumentException(ResponseContent.INVENTORY_REQUEST_EXCEPTION);
		}
		try {
			Optional<Inventory> inventoryOpt = Optional.empty();

			if (request.getProductId() != null && request.getItemId() != null) {
				// inventoryOpt =
				// inventoryRepo.findByProductIdAndItemIdAndVariantTypeId(request.getProductId(),
				// request.getItemId(),request.getVariantTypeId());
			}

			if (request.getBasketId() != null && request.getVariantTypeId() != null) {
				// inventoryOpt =
				// inventoryRepo.findByBasketIdAndVariantTypeId(request.getBasketId(),
				// request.getVariantTypeId());
			}

			if (inventoryOpt.isEmpty()) {
				log.info("No matching inventory found for request: {}", request);
				return new SaveResponse(ResponseContent.INVENTORY_NOT_FOUND, false, BigDecimal.ZERO);
			}

			Inventory inventory = inventoryOpt.get();
			BigDecimal quantityReserved = inventory.getQuantityReserved() != null ? inventory.getQuantityReserved()
					: BigDecimal.ZERO;
			BigDecimal available = inventory.getQuantityAvailable().subtract(quantityReserved);
			boolean isAvailable = available.compareTo(BigDecimal.valueOf(request.getQuantity())) >= 0;
			log.debug("Inventory check result — Available: {}, Requested: {}, IsAvailable: {}", available,
					request.getQuantity(), isAvailable);
			return new SaveResponse(ResponseContent.INVENTORY_CHECK_COMPLETED, isAvailable, available);
		} catch (Exception e) {
			log.error("Exception occurred during inventory check for request: {}", request, e);
			throw new InventoryCheckException(ResponseContent.INVENTORY_CHECK_EXCEPTION, e);
		}
	}

	@Transactional
	public SaveResponse checkReserveInInventory(List<WishListRequest> requestList) {

		if (requestList == null || requestList.isEmpty()) {
			log.warn("Invalid inventory request received: {}", requestList);
			throw new IllegalArgumentException(ResponseContent.INVENTORY_REQUEST_EXCEPTION);
		}

		try {
			List<String> unavailableMessages = new ArrayList<>();
			BigDecimal minAvailableQty = null;

			for (WishListRequest request : requestList) {

				Long skuId = request.getSkuId();
				String batchCode = request.getBatchCode();

				if (skuId == null || batchCode == null) {
					throw new InventoryCheckException(ResponseContent.INVENTORY_MISSING_EXCEPTION + request);
				}

				Optional<Inventory> inventoryOpt = inventoryRepo.findBySkuIdAndBatchCode(skuId, batchCode);

				if (inventoryOpt.isEmpty()) {
					unavailableMessages
							.add(ResponseContent.INVENTORY_NOTFOUND_EXCEPTION + skuId + " batchCode:" + batchCode);
					continue;
				}

				Inventory inventory = inventoryOpt.get();
				BigDecimal availableQty = inventory.getQuantityAvailable().subtract(inventory.getQuantityReserved());

				if (availableQty.compareTo(BigDecimal.valueOf(request.getQuantity())) < 0) {
					unavailableMessages.add(ResponseContent.INVENTORY_INSUFFICIENT_EXCEPTION + skuId + " batchCode:"
							+ batchCode + " (available: " + availableQty + ")");

					if (minAvailableQty == null || availableQty.compareTo(minAvailableQty) < 0) {
						minAvailableQty = availableQty;
					}
				}
			}

			if (!unavailableMessages.isEmpty()) {
				String finalMessage = String.join(", ", unavailableMessages);
				return new SaveResponse(finalMessage, false,
						minAvailableQty != null ? minAvailableQty : BigDecimal.ZERO);
			}

			return new SaveResponse(ResponseContent.INVENTORY_ITEMS_AVAILABLE, true, null);

		} catch (Exception ex) {
			log.error("Exception occurred during inventory check for requests: {}", requestList, ex);
			throw new InventoryCheckException(ResponseContent.INVENTORY_CHECK_EXCEPTION, ex);
		}
	}

	@Override
	public List<MasterInventoryRacks> getMasterInventoryRacks() {
		return masterInventoryRacksRepository.findAll();
	}

	@Override
	public List<MasterInventoryRacksType> getMasterInventoryRacksType() {
		return masterInventoryRacksTypeRepository.findAll();
	}

	@Override
	public List<MasterVendor> getMasterVendors() {
		return masterVendorsRepository.findAll();
	}

	@Override
	public List<MasterInventoryWareHouse> getMasterInventoryWareHouse() {
		return masterInventoryWareHouseRepository.findAll();
	}

	@Override
	public List<String> uploadInventory(UpdateInventoryRequestDto updateInventory) {
		log.info("Starting uploadInventory process with request: {}", updateInventory);
		try {
			String result = null;
			List<String> resultList = new ArrayList<String>();
			List<updateBasketInventory> baksetInventoryList = updateInventory.getBasket();
			List<updateProductInventory> productInventoryList = updateInventory.getProduct();
			processProductInventory(productInventoryList, result, resultList);
			processBasketInventory(baksetInventoryList, result, resultList);
			log.info("Inventory upload process completed. Results: {}", resultList);
			return resultList;

		} catch (Exception e) {
			log.error("Error occurred during inventory upload: {}", updateInventory, e);
			throw new InventoryCheckException(ResponseContent.INVENTORY_UPLOAD_EXCEPTION, e);
		}
	}

	private void processBasketInventory(List<updateBasketInventory> baksetInventoryList, String result,
			List<String> resultList) {

		for (updateBasketInventory BasketInventory : baksetInventoryList) {

			result = inventoryActionStatusUtil.updateInventoryActionStatusUtil(null, BasketInventory);
			resultList.add(result);
		}

	}

	private void processProductInventory(List<updateProductInventory> productInventoryList, String result,
			List<String> resultList) {

		for (updateProductInventory productInventory : productInventoryList) {

			result = inventoryActionStatusUtil.updateInventoryActionStatusUtil(productInventory, null);
			resultList.add(result);
		}

	}

	public String updateInventory(OrderEventDto orderEventDto, Long actionType) {
		List<updateBasketInventory> basketList = new ArrayList<>();
		List<updateProductInventory> productlist = new ArrayList<>();
		UpdateInventoryRequestDto updateInventoryRequestDto = new UpdateInventoryRequestDto();
		List<OrderItemDto> orderItemDto = orderEventDto.getItems();

		List<BasketInput> itemVariantList = orderItemDto.stream().map(item -> {
			BasketInput dto = new BasketInput();
			dto.setItemId(item.getItemId());
			dto.setVariantTypeId(item.getVariantTypeId());
			return dto;
		}).toList();
		List<ProductUnitDTO> productUnitDTOList = fetchProductUnit(itemVariantList);

		for (OrderItemDto orderItem : orderItemDto) {
			if (orderItem.getItemId() != null) {
				updateProductInventory updateProductInventory = new updateProductInventory();
				updateProductInventory.setProductId(orderItem.getProductId());
				updateProductInventory.setActionType(actionType);
				updateProductInventory.setItemId(orderItem.getItemId());
				updateProductInventory.setVariantTypeId(orderItem.getVariantTypeId());
				updateProductInventory.setOrderStatus(orderEventDto.getStatus());

				BigDecimal convertedQuantity = calculateConvertedQuantity(orderItem, productUnitDTOList);
				updateProductInventory.setQuantity(convertedQuantity);

				productlist.add(updateProductInventory);
			}
			if (orderItem.getBasketId() != null) {
				updateBasketInventory updateBasketInventory = new updateBasketInventory();
				updateBasketInventory.setBasketId(orderItem.getBasketId());
				updateBasketInventory.setQuantity(BigDecimal.valueOf(orderItem.getQuantity()));
				updateBasketInventory.setActionType(actionType);
				updateBasketInventory.setVariantTypeId(orderItem.getVariantTypeId());
				updateBasketInventory.setOrderStatus(orderEventDto.getStatus());
				basketList.add(updateBasketInventory);
			}
		}

		updateInventoryRequestDto.setProduct(productlist);
		updateInventoryRequestDto.setBasket(basketList);
		uploadInventory(updateInventoryRequestDto);
		log.debug("Final inventory update request DTO: {}", updateInventoryRequestDto);
		log.info("Inventory updated successfully for order ID: {}", orderEventDto.getOrderId());
		return ResponseContent.INVENTORY_UPDATE_MESSAGE;
	}

	public List<ProductUnitDTO> fetchProductUnit(List<BasketInput> inputList) {
		String query = """
				    query FetchProductUnit($input: [BasketInput!]!) {
				      fetchProductUnit(input: $input) {
				        itemId
				        variantList {
				          variantTypeId
				          variantTypeName
				          size
				          masterUnit {
				            unitId
				            unitName
				            isActive
				            baseUnitName
				            conversionFactorToBase
				          }
				        }
				      }
				    }
				""";

		Map<String, Object> request = Map.of("query", query, "variables", Map.of("input", inputList));

		JsonNode response;
		try {
			response = webClientBuilder.baseUrl(productServiceUrl + "/graphql").build().post().bodyValue(request)
					.retrieve().bodyToMono(JsonNode.class).block();
		} catch (Exception e) {
			throw new RuntimeException("Failed to fetch data from GraphQL", e);
		}

		JsonNode dataNode = response != null ? response.path("data").path("fetchProductUnit") : null;

		if (dataNode == null || dataNode.isMissingNode()) {
			return Collections.EMPTY_LIST;
			// throw new RuntimeException("No data found in GraphQL response");
		}

		try {
			return objectMapper.readerForListOf(ProductUnitDTO.class).readValue(dataNode);
		} catch (Exception e) {
			throw new RuntimeException("Failed to parse ProductUnitDTO list", e);
		}
	}

	public BigDecimal calculateConvertedQuantity(OrderItemDto orderItem, List<ProductUnitDTO> productUnitDTOList) {
		if (orderItem == null || productUnitDTOList == null) {
			return BigDecimal.ZERO;
		}

		ProductUnitDTO matchingProductUnit = productUnitDTOList.stream()
				.filter(p -> p.getItemId().equals(orderItem.getItemId()) && p.getVariantList() != null
						&& p.getVariantList().getVariantTypeId().equals(orderItem.getVariantTypeId()))
				.findFirst().orElse(null);

		if (matchingProductUnit == null) {
			return BigDecimal.ZERO;
		}

		VariantList variantList = matchingProductUnit.getVariantList();
		MasterUnit masterUnit = variantList.getMasterUnit();

		Integer size = variantList.getSize();
		BigDecimal unitValue = (size != null) ? BigDecimal.valueOf(size) : BigDecimal.ONE;

		if (masterUnit != null && masterUnit.getConversionFactorToBase() != null) {
			BigDecimal perUnitConverted = unitValue.multiply(masterUnit.getConversionFactorToBase());
			return perUnitConverted.multiply(BigDecimal.valueOf(orderItem.getQuantity()));
		}

		return BigDecimal.ZERO;
	}

	@Override
	@Transactional
	public StatusUpdateResponse updateShippingStatus(List<UpdateShippingStatusRequest> requestList) {
	    if (requestList == null || requestList.isEmpty()) {
	        return new StatusUpdateResponse(false, ResponseContent.NO_REQUEST_PROVIDED);
	    }

	    List<Long> notFoundIds = new ArrayList<>();
	    List<InventoryMappingPurchaseOrderItems> toUpdate = new ArrayList<>();

	    
	    Map<String, List<UpdateShippingStatusRequest>> groupedRequests = requestList.stream()
	            .collect(Collectors.groupingBy(req ->
	                    req.getPurchaseOrderId() + "-" + req.getDemandId() + "-" + req.getVendorId()
	            ));

	    for (Map.Entry<String, List<UpdateShippingStatusRequest>> entry : groupedRequests.entrySet()) {
	        List<UpdateShippingStatusRequest> groupedList = entry.getValue();

	        
	        InventoryMasterPurchaseOrderInvoice invoice = createNewInvoice(groupedList.get(0));

	        for (UpdateShippingStatusRequest request : groupedList) {
	            purchaseOrderItemsRepository.findById(request.getPurchaseOrderItemId()).ifPresentOrElse(purchaseDetails -> {
	                purchaseDetails.setShippingStatusId(request.getNewStatus());

	                if (request.getNewStatus() == 5) { 
	                    purchaseDetails.setRackId(request.getRackId());
	                    purchaseDetails.setExpDate(request.getExpDate());
	                    purchaseDetails.setMfgDate(request.getMfgDate());
	                    purchaseDetails.setNotes(request.getNotes());
	                    addInvoiceItem(request, invoice);
	                }

	                toUpdate.add(purchaseDetails);
	            }, () -> notFoundIds.add(request.getPurchaseOrderItemId()));
	        }
	    }

	    if (!toUpdate.isEmpty()) {
	        purchaseOrderItemsRepository.saveAll(toUpdate);
	    }

	    if (notFoundIds.isEmpty()) {
	        return new StatusUpdateResponse(true, ResponseContent.UPDATED_SUCESSFULLY);
	    } else {
	        return new StatusUpdateResponse(false, ResponseContent.UPDATE_MISSING_IDS + notFoundIds);
	    }
	}

	private InventoryMasterPurchaseOrderInvoice createNewInvoice(UpdateShippingStatusRequest request) {
	    InventoryMasterPurchaseOrderInvoice newInvoice = new InventoryMasterPurchaseOrderInvoice();
	    newInvoice.setVendorId(request.getVendorId());
	    newInvoice.setDemandId(request.getDemandId());
	    newInvoice.setPurchaseOrderId(request.getPurchaseOrderId());
	    newInvoice.setInvoiceStatusId(2L); // Example: 2 = Active or Created

	    newInvoice.setShippingStatusId(request.getNewStatus() != null ? request.getNewStatus() : 1L);
	    newInvoice.setShippingAmount(request.getShippingAmount() != null ? request.getShippingAmount() : BigDecimal.ZERO);

	    InventoryMasterPurchaseOrderInvoice savedInvoice = inventoryMasterPurchaseOrderInvoiceRepo.save(newInvoice);

	    String invoiceCode = invoiceImpl.generateInvoiceCode(savedInvoice.getInvoiceId());
	    savedInvoice.setInvoiceCode(invoiceCode);

	    return inventoryMasterPurchaseOrderInvoiceRepo.save(savedInvoice);
	}

	private void addInvoiceItem(UpdateShippingStatusRequest request, InventoryMasterPurchaseOrderInvoice invoice) {
	    purchaseOrderItemsRepository.findById(request.getPurchaseOrderItemId()).ifPresent(purchaseOrderItem -> {
	        InventoryMappingInvoiceItem invoiceItem = new InventoryMappingInvoiceItem();
	        invoiceItem.setInvoiceId(invoice.getInvoiceId());
	        invoiceItem.setQuantity(purchaseOrderItem.getQuantity());
	        invoiceItem.setPurchaseOrderItemId(purchaseOrderItem.getPurchaseOrderItemId());
	        //invoiceItem.setShippingAmount(purchaseOrderItem.getShippingAmount());
	        invoiceItem.setTotalPrice(purchaseOrderItem.getTotalPrice());
	        //invoiceItem.setShippingStatusId(request.getNewStatus());
	        invoiceItem.setPricePerUnit(purchaseOrderItem.getPricePerUnit());
	        invoiceItem.setSkuId(purchaseOrderItem.getSkuId());

	        invoiceItemRepository.save(invoiceItem);
	    });
	}



	@Override
	public List<MasterInventoryCertificateStatus> getCertificationStatus() {
		List<MasterInventoryCertificateStatus> certificateStatusList = certificateStatusRepository.findAll();
		if (certificateStatusList.isEmpty())
			return Collections.EMPTY_LIST;
		log.error("MasterCertificationStatus Fetched Successfully: {}", certificateStatusList);
		return certificateStatusList;
	}

	@Override
	@Transactional
	public StatusUpdateResponse updateCertificateStatus(List<UpdateCertificateStatusRequest> requestList) {
		if (requestList == null || requestList.isEmpty()) {
			return new StatusUpdateResponse(false, ResponseContent.NO_REQUEST_PROVIDED);
		}

		List<Long> notFoundIds = new ArrayList<>();
		List<InventoryMappingPurchaseOrderItems> toUpdate = new ArrayList<>();

		for (UpdateCertificateStatusRequest request : requestList) {
			purchaseOrderItemsRepository.findById(request.getPurchaseOrderItemId()).ifPresentOrElse(purchaseDetails -> {
				purchaseDetails.setCertificateStatusId(request.getCertificateStatusId());
				purchaseDetails.setCertificateTypeId(request.getCertificateTypeId());
				toUpdate.add(purchaseDetails);
			}, () -> notFoundIds.add(request.getPurchaseOrderItemId()));
		}

		if (!toUpdate.isEmpty()) {
			purchaseOrderItemsRepository.saveAll(toUpdate);
		}

		if (notFoundIds.isEmpty()) {
			return new StatusUpdateResponse(true, ResponseContent.UPDATED_SUCESSFULLY);
		} else {
			return new StatusUpdateResponse(false, ResponseContent.UPDATE_MISSING_IDS + notFoundIds);
		}
	}

	@Override
	public List<MasterInventoryStatus> getAllMasterInventoryStatus() {
		return masterInventoryStatusRepository.findAll();
	}

	
	@Override

	public StatusUpdateResponse saveOrUpdateCertificate(CertificateRequest request) {
//		Optional<InventoryMappingPurchaseCertificate> existingOpt = inventoryMappingPurchaseCertificateRepo
//				.findByPurchaseMasterIdAndPurchaseItemId(request.getPurchaseMasterId(), request.getPurchaseItemId());
//
//		InventoryMappingPurchaseCertificate cert;
//
//		if (existingOpt.isPresent()) {
//			// Update existing
//			cert = existingOpt.get();
//			cert.setCertificateStatusId(request.getCertificateStatusId());
//			cert.setModifiedAt(LocalDateTime.now());
//			// cert.setUpdatedBy(request.getUpdatedBy());
//		} else {
//			// Create new
//			cert = new InventoryMappingPurchaseCertificate();
//			cert.setPurchaseMasterId(request.getPurchaseMasterId());
//			cert.setPurchaseItemId(request.getPurchaseItemId());
//			cert.setCertificateStatusId(request.getCertificateStatusId());
//			cert.setCreatedAt(LocalDateTime.now());
//			cert.setCreatedBy(1l);
//		}
//
//		inventoryMappingPurchaseCertificateRepo.save(cert);
		String message = "" != null ? ResponseContent.UPDATED_SUCESSFULLY
				: ResponseContent.SAVED_SUCCESS_MESSAGE;
		return new StatusUpdateResponse(true, message);
	}

	@Override
	@Transactional
	public MoveInventoryResponse updateInventoryStatus(List<MoveToInventoryRequest> requests) {
		if (requests == null || requests.isEmpty()) {
			return new MoveInventoryResponse(ResponseContent.REQUEST_CANNOT_BE_NULL, false);
		}

		boolean masterStatusUpdated = updatePurchaseMasterInventoryStatus(requests);
		if (!masterStatusUpdated) {
			return new MoveInventoryResponse(ResponseContent.UPDATE_UNSUCCESSFULL, false);
		}

		boolean inventoryStatusUpdated = updateInventory(requests);
		if (!inventoryStatusUpdated) {
			return new MoveInventoryResponse(ResponseContent.UPDATE_UNSUCCESSFULL, false);
		}

		return new MoveInventoryResponse(ResponseContent.UPDATED_SUCESSFULLY, true);
	}

	@Transactional
	private boolean updatePurchaseMasterInventoryStatus(List<MoveToInventoryRequest> requests) {
		try {
			for (MoveToInventoryRequest request : requests) {
				InventoryMappingPurchaseOrderItems purchaseMaster = purchaseOrderItemsRepository
						.findById(request.getPurchaseOrderItemId()).orElseThrow(() -> new NoSuchElementException(
								"Purchase Order Item not found with ID: " + request.getPurchaseOrderItemId()));
				purchaseMaster.setIsInventoryMoved(request.isPurchaseMasterStatus());
				purchaseOrderItemsRepository.save(purchaseMaster);
			}
			return true;
		} catch (Exception e) {
			log.error("Failed to update Purchase Order Items Master Inventory Status", e);
			return false;
		}
	}

	private boolean updateInventory(List<MoveToInventoryRequest> requests) {

		try {

			for (MoveToInventoryRequest request : requests) {
				Long actionTypeId = request.getActionType();
				String batchCode = request.getBatchCode();
				String orderStatus = request.getOrderStatus();

				for (PurchaseMasterItemRequest itemRequest : request.getPurchaseItemRequest()) {
					Long skuId = itemRequest.getSkuId();
					BigDecimal quantity = itemRequest.getQuantity();
					BigDecimal quantityChange = calculateQuantityChange(quantity, actionTypeId);

					saveOrUpdateInventory(actionTypeId, batchCode, skuId, quantityChange, orderStatus);
				}
			}
			return true;

		} catch (Exception e) {
			log.error("Failed to update Purchase Master Inventory Status", e);
			return false;
		}
	}

	private void saveOrUpdateInventory(Long actionTypeId, String batchCode, Long skuId, BigDecimal quantityChange,
			String orderStatus) {

		Inventory inventory = inventoryRepo.findBySkuIdAndBatchCode(skuId, batchCode).orElseGet(() -> {
			Inventory newInventory = new Inventory();
			newInventory.setSkuId(skuId);
			newInventory.setBatchCode(batchCode);
			newInventory.setQuantityAvailable(BigDecimal.ZERO);
			newInventory.setQuantityReserved(BigDecimal.ZERO);
			return newInventory;
		});

		switch (actionTypeId.intValue()) {
		case 1: // ADD
		case 6: // RETURN
			adjustQuantityAvailable(inventory, quantityChange);
			break;
		case 5: // SALE
			adjustQuantityAvailable(inventory, quantityChange.negate());
			adjustQuantityReserved(inventory, quantityChange.negate());
			break;
		case 3: // RESERVE
			adjustQuantityReserved(inventory, quantityChange);
			break;
		case 11: // CANCEL
			handleCancelAction(inventory, quantityChange, orderStatus);
			break;
		default:
			throw new IllegalArgumentException(ResponseContent.INVALID_ACTION_TYPE_EXCEPTION + actionTypeId);
		}

		Inventory savedInventory = inventoryRepo.save(inventory);
		saveInventoryHistory(savedInventory, actionTypeId);
	}

	
	private void handleCancelAction(Inventory inventory, BigDecimal quantityChange, String orderStatus) {
		if (ResponseContent.PENDING.equals(orderStatus)) {
			adjustQuantityReserved(inventory, quantityChange.negate());
		} else if (ResponseContent.CONFIRMED.equals(orderStatus)) {
			adjustQuantityAvailable(inventory, quantityChange);
		} else {
			throw new IllegalArgumentException("Invalid order status: " + orderStatus);
		}
	}

	private void adjustQuantityAvailable(Inventory inventory, BigDecimal quantityChange) {
		BigDecimal updated = safeAdd(inventory.getQuantityAvailable(), quantityChange);
		inventory.setQuantityAvailable(updated.max(BigDecimal.ZERO));
	}

	private void adjustQuantityReserved(Inventory inventory, BigDecimal quantityChange) {
		BigDecimal updated = safeAdd(inventory.getQuantityReserved(), quantityChange);
		inventory.setQuantityReserved(updated.max(BigDecimal.ZERO));
	}

	private BigDecimal safeAdd(BigDecimal base, BigDecimal toAdd) {
		if (base == null)
			base = BigDecimal.ZERO;
		if (toAdd == null)
			toAdd = BigDecimal.ZERO;
		return base.add(toAdd);
	}

	private BigDecimal calculateQuantityChange(BigDecimal quantity, Long actionTypeId) {
		if (quantity == null) {
			throw new IllegalArgumentException("Quantity cannot be null");
		}

		switch (actionTypeId.intValue()) {
		case 1: // ADD
		case 6: // RETURN
		case 11: // CANCEL
		case 3: // RESERVE
			return quantity;
		case 5: // SALE
			return quantity.negate();
		default:
			throw new IllegalArgumentException(ResponseContent.INVALID_ACTION_TYPE_EXCEPTION + actionTypeId);
		}
	}

	@Transactional
	private void saveInventoryHistory(Inventory inventory, Long actionTypeId) {
		HistoryInventory history = new HistoryInventory();
		history.setInventoryId(inventory.getInventoryId());
		history.setQuantityAvailable(inventory.getQuantityAvailable());
		history.setQuantityReserved(inventory.getQuantityReserved());
		history.setCreatedAt(new Date());
		history.setActionType(actionTypeId);
		historyInventoryRepo.save(history);
	}

	

	
	@Override
	public List<InventoryMasterPurchaseShippingStatus> masterPurchaseShippingStatus() {
		List<InventoryMasterPurchaseShippingStatus> purchaseShippingStatusList = masterPurchaseShippingStatusRepository
				.findAll();
		if (purchaseShippingStatusList.isEmpty())
			return Collections.EMPTY_LIST;
		return purchaseShippingStatusList;
	}

	@Override
	public List<SkuInventoryData> getLowStockReport() {
		List<Object[]> rawData = inventoryRepo.getLowStockReport();
		return rawData.stream().map(row -> new SkuInventoryData(((Number) row[0]).longValue(), (String) row[1],
				(String) row[2], (String) row[3], ((Number) row[4]).intValue())).collect(Collectors.toList());
	}

	@Override
	public List<Inventory> getRecentInventory(List<Long> skuIds) {

		if (skuIds == null || skuIds.isEmpty()) {
			return Collections.emptyList();
		}

		List<Inventory> result = new ArrayList<>();

		for (Long skuId : skuIds) {

			List<Inventory> inventoryList = inventoryRepo.findAllBySkuId(skuId);
			if (inventoryList.isEmpty())
				continue;

			// Check once if there is any moved purchase item for this SKU
			if (!purchaseOrderItemsRepository.existsBySkuIdAndIsInventoryMovedTrue(skuId)) {
				continue;
			}

			// Sort: (available - reserved) DESC ➜ earliest expiry ASC
			Comparator<Inventory> comparator = Comparator.<Inventory, BigDecimal>comparing(inv -> {
				BigDecimal available = defaultZero(inv.getQuantityAvailable());
				BigDecimal reserved = defaultZero(inv.getQuantityReserved());
				return available.subtract(reserved);
			}).reversed().thenComparing((Inventory inv) -> // Explicit type solves inference
			purchaseOrderItemsRepository.findTopBySkuIdAndIsInventoryMovedTrueOrderByExpDateAsc(inv.getSkuId())
					.map(InventoryMappingPurchaseOrderItems::getExpDate).orElse(LocalDateTime.MAX),
					Comparator.naturalOrder() // Explicit comparator
			);

			inventoryList.sort(comparator);

			// Take only the best inventory
			result.add(inventoryList.get(0));
		}

		return result;
	}

	/** Utility to handle possible null BigDecimals. */
	private BigDecimal defaultZero(BigDecimal val) {
		return val == null ? BigDecimal.ZERO : val;
	}

	
	

	
	

	

	@Override
	public List<MasterCertificateType> getAllCertificateTypes() {
		return certificateTypeRepository.findAll();
	}

	

	@Transactional
	public void updateInventoryQuantity(List<WishListRequest> requestList) {

		if (requestList == null || requestList.isEmpty()) {
			log.warn("Invalid inventory request received for update: {}", requestList);
			throw new IllegalArgumentException(ResponseContent.INVENTORY_REQUEST_EXCEPTION);
		}

		try {
			for (WishListRequest request : requestList) {

				Long skuId = request.getSkuId();
				String batchCode = request.getBatchCode();

				if (skuId == null || batchCode == null) {
					throw new InventoryCheckException(ResponseContent.INVENTORY_MISSING_EXCEPTION + request);
				}

				Optional<Inventory> inventoryOpt = inventoryRepo.findBySkuIdAndBatchCode(skuId, batchCode);

				if (inventoryOpt.isEmpty()) {
					throw new InventoryCheckException(
							ResponseContent.INVENTORY_NOTFOUND_EXCEPTION + skuId + " batchCode:" + batchCode);
				}

				Inventory inventory = inventoryOpt.get();

				BigDecimal availableQty = inventory.getQuantityAvailable().subtract(inventory.getQuantityReserved());
				BigDecimal requestQty = BigDecimal.valueOf(request.getQuantity());

				if (availableQty.compareTo(requestQty) < 0) {
					throw new InventoryCheckException(
							ResponseContent.INVENTORY_INSUFFICIENT_EXCEPTION + skuId + " batchCode:" + batchCode
									+ " (available: " + availableQty + ", requested: " + requestQty + ")");
				}

				inventory.setQuantityReserved(inventory.getQuantityReserved().add(requestQty));
				inventory.setQuantityAvailable(inventory.getQuantityAvailable().subtract(requestQty));
				inventory.setModifiedAt(new Date());
				inventory.setModifiedBy(1L);
				inventoryRepo.save(inventory);

				log.info("Reserved {} units for skuId:{} batchCode:{}. Updated inventory: available={}, reserved={}",
						requestQty, skuId, batchCode, inventory.getQuantityAvailable(),
						inventory.getQuantityReserved());
			}

		} catch (Exception ex) {
			log.error("Exception occurred during inventory update for requests: {}", requestList, ex);
			throw new InventoryCheckException(ResponseContent.INVENTORY_UPDATE_EXCEPTION, ex);
		}
	}

	@Override
	public DemandSummaryDto getDemandSummary(Long demandId) {

		BigDecimal sumQuantity = inventoryDemandItemsRepository.sumQuantityByDemandId(demandId);
		BigDecimal vendorTotalAvailability = inventoryQuotationDemandRepo.sumAvailableQuantityByDemandId(demandId);
		DemandSummaryDto demandObj = new DemandSummaryDto();
		demandObj.setItemRequired(sumQuantity.longValue());
		demandObj.setVendorAvailable(inventoryQuotationDemandRepo.countDistinctVendorsByDemandId(demandId));
		demandObj.setTotalCapacity(vendorTotalAvailability.longValue());

		if (sumQuantity != null && sumQuantity.compareTo(BigDecimal.ZERO) > 0) {
			BigDecimal coverage = vendorTotalAvailability.divide(sumQuantity, 2, RoundingMode.HALF_UP) // 2 = scale
																										// (decimal
																										// places)
					.multiply(BigDecimal.valueOf(100));

			demandObj.setDemandCoverage(coverage.longValue());
		} else {
			demandObj.setDemandCoverage(0l); // no demand case
		}

		return demandObj;
	}

	@Override
	@Transactional
	public ResponseDto createDemand(DemandRequest request) {
		LocalDateTime now = LocalDateTime.now();

		InventoryTxnDemand demand = InventoryTxnDemand.builder()
				.demandStatus("OPEN")
				.notes(request.getNotes())
				.demandEndDate(LocalDate.parse(request.getDemandEndDate()))
				.createdDate(now)
				.modifiedDate(now).build();

		InventoryTxnDemand savedDemand = inventoryTxnDemandRepository.save(demand);

		String codeDemand = purchaseOrderCodeGenerator.generateDemandCode(savedDemand.getDemandId(),
				savedDemand.getCreatedDate());
		savedDemand.setDemandCode(codeDemand);

		inventoryTxnDemandRepository.save(savedDemand);

		request.getDemandItems().forEach(dto -> {
			InventoryDemandItems demandItem = new InventoryDemandItems();
			demandItem.setDemandId(savedDemand.getDemandId());
			demandItem.setQuantity(dto.getQuantity());
			demandItem.setSkuId(dto.getSkuId());
			demandItem.setCreatedAt(LocalDateTime.now());
			demandItem.setCreatedBy(1l);
			demandItem.setModifiedAt(LocalDateTime.now());
			demandItem.setModifiedBy(1l);
			inventoryMappingDemandItemRepo.save(demandItem);
		});
		return new ResponseDto(ResponseContent.CREATED_DEMAND_SUCCESSFULLY, true);
	}

	@Override
	public PagedResponse<InventoryTxnDemand> getDemandList(List<Long> demandId, int page, int pageSize) {

		Sort sort = "desc".equalsIgnoreCase("desc") ? Sort.by("demandId").descending()
				: Sort.by("demandId").ascending();

		Pageable pageable = PageRequest.of(page, pageSize, sort);

		Page<InventoryTxnDemand> demandList;

		if (demandId == null || demandId.isEmpty())
			demandList = inventoryTxnDemandRepository.findAll(pageable);
		else
			demandList = inventoryTxnDemandRepository.findByDemandIdIn(demandId, pageable);

		return new PagedResponse<>(demandList.getContent(), demandList.getTotalPages(), demandList.getTotalElements());
	}

	@Override
	public List<PurchaseOrderResponse> getPurchaseOrdersByDemandIds(List<Long> demandIds) {

		List<InventoryMasterPurchaseOrder> purchaseOrders;

		if (demandIds == null || demandIds.isEmpty()) {
			purchaseOrders = purchaseOrderRepository.findAll();
		} else {
			purchaseOrders = purchaseOrderRepository.findByDemandIdIn(demandIds);
		}

		return mapToPurchaseOrderResponse(purchaseOrders);
	}

	private List<PurchaseOrderResponse> mapToPurchaseOrderResponse(List<InventoryMasterPurchaseOrder> purchaseOrders) {
		return purchaseOrders.stream().collect(Collectors.groupingBy(InventoryMasterPurchaseOrder::getDemandId))
				.entrySet().stream()
				.map(entry -> new PurchaseOrderResponse(entry.getKey(),
						entry.getValue().stream().map(po -> new PurchaseOrderResponseDto(po.getPurchaseOrderCode(),
								po.getPurchaseOrderId(), po.getDemandId(), po.getPurchaseOrderDate(),
								objectMapper.convertValue(po.getVendor(), VendorDTO.class),
								po.getPurchaseOrderItems().stream().map(item -> new PurchaseOrderItemDTO(
										item.getPurchaseOrderItemId(), item.getIsInventoryMoved(),
										item.getCertificateTypeId(),
										item.getCertificateType() != null
												? item.getCertificateType().getCertificateName()
												: null,
										item.getCertificateType() != null
												? item.getCertificateType().getCertificateCode()
												: null,
										item.getCertificateType() != null ? item.getCertificateType().getDescription()
												: null,
										item.getShippingStatusId(),
										item.getShippingStatus() != null ? item.getShippingStatus().getShippingStatus()
												: null,
										item.getSkuId(), item.getCertificateStatusId(),
										item.getCertificateStatus().getStatusName(),
										item.getCertificateStatus().getDescription(),
										item.getMfgDate() != null ? item.getMfgDate() : null,
										item.getExpDate() != null ? item.getExpDate() : null,
										item.getNotes() != null ? item.getNotes() : null,
										item.getRack() != null ? item.getRack().getRackId() : null,
										item.getPricePerUnit() != null ? item.getPricePerUnit() : BigDecimal.ZERO,
										item.getQuantity() != null ? item.getQuantity() : BigDecimal.ZERO,
										item.getTotalPrice() != null ? item.getTotalPrice() : BigDecimal.ZERO,
										item.getShippingAmount() != null ? item.getShippingAmount() : BigDecimal.ZERO,
										item.getBatchCode() != null ? item.getBatchCode() : "",
									    item.getQrPath() != null ? item.getQrPath() : "")).toList()))
								.toList()))
				.toList();
	}

	@Override
	public List<DemandQuotationResponse> getVendorCapacityByDemandIds(List<Long> demandIds) {
		List<InventoryMappingQuotationDemandItems> items = (demandIds == null || demandIds.isEmpty())
				? inventoryQuotationDemandRepo.findAll()
				: inventoryQuotationDemandRepo.findByDemand_DemandIdIn(demandIds);

		Map<InventoryTxnDemand, List<InventoryMappingQuotationDemandItems>> groupedByDemand = items.stream()
				.collect(Collectors.groupingBy(InventoryMappingQuotationDemandItems::getDemand));

		return groupedByDemand.entrySet().stream().map(demandEntry -> {
			InventoryTxnDemand demand = demandEntry.getKey();

			Map<Long, List<InventoryMappingQuotationDemandItems>> groupedBySku = demandEntry.getValue().stream()
					.collect(Collectors.groupingBy(InventoryMappingQuotationDemandItems::getSkuId));

			List<DemandQuotationResponse.DemandItemDTO> demandItems = groupedBySku.entrySet().stream().map(skuEntry -> {
				Long skuId = skuEntry.getKey();
				List<DemandQuotationResponse.VendorQuotationDTO> vendors = skuEntry.getValue().stream()
						.map(item -> DemandQuotationResponse.VendorQuotationDTO.builder()
								.vendorId(item.getVendor().getVendorId()).name(item.getVendor().getName())
								.email(item.getVendor().getEmail()).phone(item.getVendor().getPhone())
								.rackId(item.getRackId())
								.quotationStatus(item.getQuotationStatus().getStatusName())
								.approvedQuantity(item.getApprovedQuantity() != null ? item.getApprovedQuantity()
										: BigDecimal.ZERO)
								.phone(item.getVendor().getPhone()).price(item.getPricePerUnit())
								.availableQuantity(item.getAvailableQuantity()).deliveryDate(item.getDeliveryDate())
								.quotationStatusId(item.getQuotationStatusId()).approvedDate(item.getApprovedDate())
								.batchCode(item.getBatchCode())
								.build())
						.toList();

				// 👉 Take available quantity from the first vendor item
				BigDecimal demandQuantity = skuEntry.getValue().get(0).getAvailableQuantity();

				return DemandQuotationResponse.DemandItemDTO.builder().skuId(skuId).demandQuantity(demandQuantity)
						.vendors(vendors).build();
			}).toList();

			DemandQuotationResponse.DemandDTO demandDTO = DemandQuotationResponse.DemandDTO.builder()
					.demandId(demand.getDemandId()).demandCode(demand.getDemandCode())
					.demandStatus(demand.getDemandStatus()).demandItems(demandItems).build();

			return DemandQuotationResponse.builder().demand(demandDTO).build();
		}).toList();
	}

	@Override
	@Transactional
	public ResponseDto createPurchaseOrder(PurchaseOrderRequest request) {
	    Long skuId    = request.getItems().get(0).getSkuId();
	    String batchCode = request.getItems().get(0).getBatchCode();
	    BigDecimal approvedQty = request.getItems().get(0).getApprovedQuantity();
	    Long rackId  = request.getItems().get(0).getRackId();

	    // 🔹 Fetch and update quotation if present
	    Optional<InventoryMappingQuotationDemandItems> existingQuotation =
	            inventoryQuotationDemandRepo.findByDemandAndVendorAndSku(
	                    request.getDemandId(), request.getVendorId(), skuId);

	    InventoryMappingQuotationDemandItems targetQuotation = null;
	    if (existingQuotation.isPresent()) {
	        targetQuotation = existingQuotation.get();
	        targetQuotation.setApprovedDate(LocalDateTime.now());
	        targetQuotation.setApprovedQuantity(approvedQty);
	        targetQuotation.setQuotationStatusId(2L);
	        targetQuotation.setRackId(rackId);
	    }

	    // 🔹 Create or get purchase order
	    InventoryMasterPurchaseOrder targetPO = purchaseOrderRepository
	            .findByDemandIdAndVendorId(request.getDemandId(), request.getVendorId())
	            .orElseGet(() -> purchaseOrderRepository.save(
	                    InventoryMasterPurchaseOrder.builder()
	                            .demandId(request.getDemandId())
	                            .vendorId(request.getVendorId())
	                            .purchaseOrderDate(LocalDateTime.now())
	                            .createdAt(LocalDateTime.now())
	                            .modifiedAt(LocalDateTime.now())
	                            .purchaseOrderCode("POM-" + UUID.randomUUID())
	                            .build()
	            ));

	    Long purchaseOrderId = targetPO.getPurchaseOrderId();
	    final InventoryMappingQuotationDemandItems finalQuotation = targetQuotation; // ✅ effectively final

	    List<InventoryMappingPurchaseOrderItems> poItemsList = new ArrayList<>();

	    for (ItemDto dto : request.getItems()) {
	        BigDecimal pricePerUnit = finalQuotation != null
	                ? finalQuotation.getPricePerUnit()
	                : BigDecimal.ZERO;

	        InventoryMappingPurchaseOrderItems poItem =
	                InventoryMappingPurchaseOrderItems.builder()
	                        .purchaseOrderId(purchaseOrderId)
	                        .skuId(dto.getSkuId())
	                        .quantity(dto.getApprovedQuantity())
	                        .isInventoryMoved(false)
	                        .shippingStatusId(1L)
	                        .certificateStatusId(1L)
	                        .createdBy(1L)
	                        .modifiedBy(1L)
	                        .rackId(rackId)	                        
	                        .createdAt(LocalDateTime.now())
	                        .modifiedAt(LocalDateTime.now())
	                        .pricePerUnit(pricePerUnit)
	                        .batchCode(dto.getBatchCode())
	                        .qrPath(generateQrPathForApprovedQuantity(
	                                dto,
	                                finalQuotation,
	                                dto.getApprovedQuantity()
	                        ))
	                        .totalPrice(pricePerUnit.multiply(dto.getApprovedQuantity()))
	                        .build();

	        poItemsList.add(poItem);
	    }

	    purchaseOrderItemsRepository.saveAll(poItemsList);
	    return new ResponseDto("Purchase Order created successfully", true);
	}


	private String generateQrPathForApprovedQuantity(
	        ItemDto dto,
	        InventoryMappingQuotationDemandItems inventoryDemandItems,
	        BigDecimal approvedQty) {

	    if (inventoryDemandItems == null) {
	        throw new IllegalArgumentException("Quotation details are required to generate QR code.");
	    }

	    try {
	        // Build SKU string
	        String sku = SkuGeneratorUtil.generateSku(
	                inventoryDemandItems.getVendor().getVendorCode(),
	                dto.getSkuDetails().getItemSkuDto().getProductSkuDto()
	                   .getClassificationSkuDto().getClassifyCode(),
	                dto.getSkuDetails().getItemSkuDto().getItemCode(),
	                dto.getSkuDetails().getItemSkuDto().getProductSkuDto().getProductCode(),
	                dto.getSkuDetails().getVariantTypeSkuDto().getVariantTypeCode()
	        );

	        // Total price = pricePerUnit * approvedQty
	        BigDecimal totalPrice = inventoryDemandItems.getPricePerUnit().multiply(approvedQty);

	        // Build JSON string for QR
	        String qrContent = String.format("""
	            {
	              "PurchaseSKU": "%s",
	              "VendorName": "%s",
	              "ItemName": "%s",
	              "ProductName": "%s",
	              "ClassificationName": "%s",
	              "VariantTypeName": "%s",
	              "Quantity": "%s",
	              "Price": "%s"
	            }
	            """,
	            sku,
	            inventoryDemandItems.getVendor().getName(),
	            dto.getSkuDetails().getItemSkuDto().getItemName(),
	            dto.getSkuDetails().getItemSkuDto().getProductSkuDto().getProductName(),
	            dto.getSkuDetails().getItemSkuDto().getProductSkuDto()
	               .getClassificationSkuDto().getClassificationName(),
	            dto.getSkuDetails().getVariantTypeSkuDto().getVariantTypeName(),
	            approvedQty,
	            totalPrice
	        );

	        byte[] qrCodeBytes = qrCodeGenerator.generateQrCodeBytes(qrContent, 300, 300);
	        return imageUploadUtil.uploadQrCodeToS3(qrCodeBytes, sku);

	    } catch (WriterException | IOException e) {
	        log.error("Failed to generate or upload QR Code for SKU", e);
	        throw new RuntimeException(ResponseContent.UPLOAD_FAILED + e.getMessage(), e);
	    }
	}


	@Override
	public PagedResponse<InventoryMasterPurchaseOrderInvoice> getInvoiceDetails(List<Long> demandIds, int page,
			int size) {

		Sort sort = "desc".equalsIgnoreCase("desc") ? Sort.by("invoiceId").descending()
				: Sort.by("invoiceId").ascending();

		Pageable pageable = PageRequest.of(page, size, sort);
		Page<InventoryMasterPurchaseOrderInvoice> invoicePage;

		if (demandIds.size() == 0) {
			invoicePage = inventoryMasterPurchaseOrderInvoiceRepo.findAll(pageable);
		} else {
			invoicePage = inventoryMasterPurchaseOrderInvoiceRepo.findBydemandIdIn(demandIds, pageable);
			
			
		}

		return new PagedResponse<>(invoicePage.getContent(), invoicePage.getTotalPages(),
				invoicePage.getTotalElements());
	}

	@Override
	@Transactional(rollbackOn = RuntimeException.class)
	public ResponseDto saveVendorQuotations(List<VendorQuotations> vendorQuotationsList) {
		if (vendorQuotationsList == null || vendorQuotationsList.isEmpty()) {
			return new ResponseDto(ResponseContent.REQUEST_CANNOT_BE_NULL, false);
		}
		List<InventoryMappingQuotationDemandItems> mappingItems = vendorQuotationsList.stream()
				.map(vendorQuotations -> {
					InventoryMappingQuotationDemandItems mappingQuotationsItems = new InventoryMappingQuotationDemandItems();
					mappingQuotationsItems.setVendorId(vendorQuotations.getVendorId());
					mappingQuotationsItems.setDemandId(vendorQuotations.getDemandId());
					mappingQuotationsItems.setSkuId(vendorQuotations.getSkuId());
					mappingQuotationsItems.setAvailableQuantity(vendorQuotations.getAvailableQuantity());
					mappingQuotationsItems.setPricePerUnit(vendorQuotations.getPricePerUnit());
					mappingQuotationsItems
							.setBatchCode("BATCH_" + vendorQuotations.getVendorId() + vendorQuotations.getSkuId());
					LocalDate localDate = LocalDate.parse(vendorQuotations.getDeliveryDate(), formatter);
					mappingQuotationsItems.setDeliveryDate(localDate.atStartOfDay());
//	                if (vendorQuotations.getDeliveryLocation() != null) {
//	                    if (vendorQuotations.getDeliveryLocation().getDeliveryLocationStatus() == DeliveryLocationStatus.NALAM) {
//	                        mappingQuotationsItems.setDeliveryLocationId(1L);
//	                    } else {
//	                        PurchaseItemsDeliveryLocation deliveryLocation = new PurchaseItemsDeliveryLocation();
//	                        deliveryLocation.setAddress(vendorQuotations.getDeliveryLocation().getAddress());
//	                        deliveryLocation.setCity(vendorQuotations.getDeliveryLocation().getCity());
//	                        deliveryLocation.setCountry(vendorQuotations.getDeliveryLocation().getCountry());
//	                        deliveryLocation.setDeliveryLocationStatus(
//	                                DeliveryLocationStatus.valueOf(
//	                                        vendorQuotations.getDeliveryLocation().getDeliveryLocationStatus().toString()));
//	                        deliveryLocation.setPincode(vendorQuotations.getDeliveryLocation().getPincode());
//	                        deliveryLocation.setState(vendorQuotations.getDeliveryLocation().getState());
//
//	                        PurchaseItemsDeliveryLocation savedLocation = deliveryLocationRepository.save(deliveryLocation);
					mappingQuotationsItems.setDeliveryLocationId(1l);
					// }
					// }

					return mappingQuotationsItems;
				}).collect(Collectors.toList());

		// save all in one go (batch insert if JPA batching is enabled)
		inventoryQuotationDemandRepo.saveAll(mappingItems);

		return new ResponseDto(ResponseContent.SAVE_SUCCESS, true);
	}

	public PagedResponse<InventoryMappingQuotationDemandItems> getQuotationList(List<Long> quoatationIds,
			List<Long> demandIds, int page, int pageSize) {
		Sort sort = "desc".equalsIgnoreCase("desc") ? Sort.by("quotationId").descending()
				: Sort.by("quotationId").ascending();

		Pageable pageable = PageRequest.of(page, pageSize, sort);
		Page<InventoryMappingQuotationDemandItems> quotationDemandItems = null;

		if (demandIds != null && quoatationIds != null) {
			if (demandIds.size() > 0 && quoatationIds.size() == 0)
				quotationDemandItems = inventoryQuotationDemandRepo.findByDemand_DemandIdIn(demandIds, pageable);
			else if (demandIds.size() == 0 && quoatationIds.size() > 0)
				quotationDemandItems = inventoryQuotationDemandRepo.findByquotationIdIn(quoatationIds, pageable);
			else if (demandIds.size() > 0 && quoatationIds.size() > 0)
				quotationDemandItems = inventoryQuotationDemandRepo.findByDemand_DemandIdInAndQuotationIdIn(demandIds,
						quoatationIds, pageable);
		} else
			quotationDemandItems = inventoryQuotationDemandRepo.findAll(pageable);
		
		  // ✅ Set approved field based on quotationStatusId
	    List<InventoryMappingQuotationDemandItems> updatedList = quotationDemandItems.getContent().stream()
	            //.peek(item -> item.getsetApproved(item.getQuotationStatusId() != null && item.getQuotationStatusId() == 2 && item.getApprovedDate()!=null))
	            .toList();

		return new PagedResponse<>(updatedList, quotationDemandItems.getTotalPages(),
				quotationDemandItems.getTotalElements());
	}

	@Override
	public PagedResponse<PurchaseOrderResponseDto> getInventoryByCategory(List<String> categories, int page, int size) {
		Sort sort = "desc".equalsIgnoreCase("desc") ? Sort.by("purchaseOrderId").descending()
				: Sort.by("purchaseOrderId").ascending();
		Pageable pageable = PageRequest.of(page, size, sort);

		Specification<InventoryMasterPurchaseOrder> spec = null;

		for (String category : categories) {
			Specification<InventoryMasterPurchaseOrder> categorySpec;
			switch (category.toLowerCase()) {
			case "purchaseorderinitiated":
				categorySpec = InventorySpecifications.purchaseOrderInitiated();
				break;
			case "inventorymoved":
				categorySpec = InventorySpecifications.inventoryMoved();
				break;
			case "ordershipped":
				categorySpec = InventorySpecifications.orderShipped();
				break;
			case "certifyproducts":
				categorySpec = InventorySpecifications.certifyProducts();
				break;
			default:
				throw new IllegalArgumentException("Unknown category: " + category);
			}
			spec = (spec == null) ? categorySpec : spec.or(categorySpec); // combine with OR
		}

		Page<InventoryMasterPurchaseOrder> purchaseOrders = purchaseOrderRepository.findAll(spec, pageable);

		// filter items per category before mapping
		List<PurchaseOrderResponseDto> content = mapToPurchaseOrderResponse(purchaseOrders.getContent(), categories);

		return new PagedResponse(content, purchaseOrders.getTotalPages(), purchaseOrders.getTotalElements());
	}

	private List<PurchaseOrderResponseDto> mapToPurchaseOrderResponse(List<InventoryMasterPurchaseOrder> purchaseOrders,
			List<String> categories) {

		boolean filterMoved = categories.stream().anyMatch(c -> c.equalsIgnoreCase("inventorymoved"));
		boolean filterShipped = categories.stream().anyMatch(c -> c.equalsIgnoreCase("ordershipped"));
		boolean filterCertified = categories.stream().anyMatch(c -> c.equalsIgnoreCase("certifyproducts"));

		return purchaseOrders.stream().map(po -> {
			List<InventoryMappingPurchaseOrderItems> items = po.getPurchaseOrderItems();

			// Apply filters if needed
			if (filterMoved || filterShipped || filterCertified) {
				items = items.stream().filter(item -> (filterMoved && Boolean.TRUE.equals(item.getIsInventoryMoved()))
						|| (filterShipped && item.getShippingStatusId() != null && item.getShippingStatusId() == 5L)
						|| (filterCertified && item.getCertificateStatusId() != null && item.getCertificateStatusId() == 2L))
						.toList();
			}

			// Map items to DTO
			List<PurchaseOrderItemDTO> itemDtos = items.stream()
					.map(item -> new PurchaseOrderItemDTO(item.getPurchaseOrderItemId(), item.getIsInventoryMoved(),
							item.getCertificateTypeId(),
							item.getCertificateType() != null ? item.getCertificateType().getCertificateName() : null,
							item.getCertificateType() != null ? item.getCertificateType().getCertificateCode() : null,
							item.getCertificateType() != null ? item.getCertificateType().getDescription() : null,
							item.getShippingStatusId(),
							item.getShippingStatus() != null ? item.getShippingStatus().getShippingStatus() : null,
							item.getSkuId(), item.getCertificateStatusId(),
							item.getCertificateStatus() != null ? item.getCertificateStatus().getStatusName() : null,
							item.getCertificateStatus() != null ? item.getCertificateStatus().getDescription() : null,
							item.getMfgDate(), item.getExpDate(), item.getNotes(),
							item.getRack() != null ? item.getRack().getRackId() : null,
							item.getPricePerUnit() != null ? item.getPricePerUnit() : BigDecimal.ZERO,
							item.getQuantity() != null ? item.getQuantity() : BigDecimal.ZERO,
							item.getTotalPrice() != null ? item.getTotalPrice() : BigDecimal.ZERO,
							item.getShippingAmount() != null ? item.getShippingAmount() : BigDecimal.ZERO,
							item.getBatchCode() != null ? item.getBatchCode() : "",
							item.getQrPath() != null ? item.getQrPath() : ""))
					.toList();

			// Build PurchaseOrderResponseDto
			return new PurchaseOrderResponseDto(po.getPurchaseOrderCode(), po.getPurchaseOrderId(), po.getDemandId(),
					po.getPurchaseOrderDate(), objectMapper.convertValue(po.getVendor(), VendorDTO.class), itemDtos);
		}).toList();
	}

	@Override
	public VendorDemandResponse getQuotationDemandItems(Long vendorId, Long demandId) {

		try {  
			
			

			// Load demand with its demandItems
			InventoryTxnDemand demand = inventoryTxnDemandRepository.findById(demandId)
					.orElseThrow(() -> new IllegalArgumentException("Demand not found"));

			// All quotations for this vendor & demand
			List<InventoryMappingQuotationDemandItems> vendorQuotations = inventoryQuotationDemandRepo
					.findByDemandIdAndVendorId(demandId, vendorId);

			// Check if purchase order exists
			Optional<InventoryMasterPurchaseOrder> existingPurchaseOrder = inventoryMasterPurchaseOrderRepository
					.findByDemandIdAndVendorId(demandId, vendorId);

			Long purchaseOrderId = null;
			Map<Long, Long> purchaseItemMap = Collections.emptyMap();

			if (existingPurchaseOrder.isPresent()) {
				purchaseOrderId = existingPurchaseOrder.get().getPurchaseOrderId();

				List<InventoryMappingPurchaseOrderItems> purchaseItemsList = purchaseOrderItemsRepository
						.findByPurchaseOrderId(purchaseOrderId);

				purchaseItemMap = purchaseItemsList.stream()
						.collect(Collectors.toMap(InventoryMappingPurchaseOrderItems::getSkuId,
								InventoryMappingPurchaseOrderItems::getPurchaseOrderItemId));
			}

			// Final copies for lambda use
			final Long finalPurchaseOrderId = purchaseOrderId;
			final Map<Long, Long> finalPurchaseItemMap = purchaseItemMap;

			// Map skuId -> approved info for quick lookup
			Map<Long, InventoryMappingQuotationDemandItems> approvedMap = vendorQuotations.stream()
					.collect(Collectors.toMap(InventoryMappingQuotationDemandItems::getSkuId, q -> q));

			// Build response
			List<VendorDemandResponse.ItemStatusDto> itemDtos = demand.getDemandItems().stream().map(item -> {
				InventoryMappingQuotationDemandItems quote = approvedMap.get(item.getSkuId());
				boolean approved = quote != null && quote.getQuotationStatus() != null
						&& "APPROVED".equalsIgnoreCase(quote.getQuotationStatus().getStatusName());

				return new VendorDemandResponse.ItemStatusDto(item.getDemandItemId(), item.getSkuId(),
						item.getQuantity(), approved, quote != null ? quote.getApprovedQuantity() : null,
						finalPurchaseOrderId, finalPurchaseItemMap.get(item.getSkuId()));
			}).collect(Collectors.toList());

			return new VendorDemandResponse(demand.getDemandId(), demand.getDemandCode(), demand.getDemandStatus(),
					demand.getNotes(), itemDtos);
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}
	
	
	@Override
    public InventoryCategoryOverViewResponse inventoryCategoryOverView() {
        Long demandCount = inventoryTxnDemandRepository.count();
        Long quotationReceivedCount = inventoryQuotationDemandRepo.count();
        Long invoicePendingCount = inventoryMasterPurchaseOrderInvoiceRepo.count();
        Long purchaseInitiatedCount = inventoryMasterPurchaseOrderRepository.count();
        Long orderShippedCount = purchaseOrderItemsRepository.countByShippingStatusId(5l);
        Long inventoryUpdatedCount = purchaseOrderItemsRepository.countByIsInventoryMoved(true);
        Long certifyProductsCount = purchaseOrderItemsRepository.countByCertificateStatusId(2l);
 
        InventoryCategoryOverViewResponse inventoryCategoryOverViewResponse = new InventoryCategoryOverViewResponse();
        inventoryCategoryOverViewResponse.setPurchaseCertificatedCount(certifyProductsCount);
        inventoryCategoryOverViewResponse.setDemandCount(demandCount);
        inventoryCategoryOverViewResponse.setPurchaseInitiatedCount(purchaseInitiatedCount);
        inventoryCategoryOverViewResponse.setQuotationReceivedCount(quotationReceivedCount);
        inventoryCategoryOverViewResponse.setPurchaseInventoryUpdatedCount(inventoryUpdatedCount);
        inventoryCategoryOverViewResponse.setPurchaseOrderShippedCount(orderShippedCount);
        inventoryCategoryOverViewResponse.setPurchaseInvoicePendingCount(invoicePendingCount);
        return inventoryCategoryOverViewResponse;
    }

	@Override
	public ResponseEntity<Map<String, Object>> closeDemand(Long demandId) {
		Map<String, Object> response = new HashMap<>();
		Optional<InventoryTxnDemand> optionalDemand = inventoryTxnDemandRepository.findById(demandId);

		if (optionalDemand.isPresent()) {
			InventoryTxnDemand demand = optionalDemand.get();
			demand.setDemandStatus("CLOSED");
			demand.setPreviousEndDate(LocalDate.now().minusDays(1));
			InventoryTxnDemand savedDemand = inventoryTxnDemandRepository.save(demand);

			response.put("message", "Successfully Updated");
			response.put("status", true);

			return new ResponseEntity<>(response, HttpStatus.OK);
		} else {
			response.put("message", "Error while Updated");
			response.put("status", false);
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public VendorDashboardSummary getVendorDashboardSummary(Long vendorId) {
		Long demandCount = inventoryTxnDemandRepository.count();
		Long approvedItemcount = inventoryQuotationDemandRepo.countApprovedSkuPerDemand(vendorId);
		Long pendingItemcount = inventoryQuotationDemandRepo.countPendingSkuPerDemand(vendorId);
		Long invoiceCount = inventoryMasterPurchaseOrderInvoiceRepo.countInvoiceDemandPerVendorId(vendorId);
		return VendorDashboardSummary.builder().approvedItemCount(approvedItemcount).demandCount(demandCount)
				.invoiceCount(invoiceCount).pendingItemCount(pendingItemcount).build();
	}

	@Override
	public List<DemandQuotationResponse> getDemandlistByVendor(List<Long> demandIds, Long vendorId, Long actionType) {

		List<InventoryMappingQuotationDemandItems> items = new ArrayList<>();

		// 🔹 ActionType = 0 → All Quotations
		if (actionType == 0) {
			items = (demandIds == null || demandIds.isEmpty())
					? inventoryQuotationDemandRepo.findAllByVendorId(vendorId)
					: inventoryQuotationDemandRepo.findByDemand_DemandIdInAndVendorId(demandIds, vendorId);
		}
		// 🔹 ActionType = 2 → Approved Quotations (quotationStatusId = 2)
		else if (actionType == 2) {
			items = (demandIds == null || demandIds.isEmpty())
					? inventoryQuotationDemandRepo.findByVendorIdAndQuotationStatusId(vendorId, 2L)
					: inventoryQuotationDemandRepo.findByDemand_DemandIdInAndVendorIdAndQuotationStatusId(demandIds,
							vendorId, 2L);
		}
		// 🔹 ActionType = 1 → Pending Quotations (quotationStatusId = 1)
		else if (actionType == 1) {
			items = (demandIds == null || demandIds.isEmpty())
					? inventoryQuotationDemandRepo.findByVendorIdAndQuotationStatusId(vendorId, 1L)
					: inventoryQuotationDemandRepo.findByDemand_DemandIdInAndVendorIdAndQuotationStatusId(demandIds,
							vendorId, 1L);
		}

		if (items == null || items.isEmpty()) {
			return Collections.emptyList();
		}

		Map<InventoryTxnDemand, List<InventoryMappingQuotationDemandItems>> groupedByDemand = items.stream()
				.collect(Collectors.groupingBy(InventoryMappingQuotationDemandItems::getDemand));

		return groupedByDemand.entrySet().stream().map(demandEntry -> {
			InventoryTxnDemand demand = demandEntry.getKey();

			Map<Long, List<InventoryMappingQuotationDemandItems>> groupedBySku = demandEntry.getValue().stream()
					.collect(Collectors.groupingBy(InventoryMappingQuotationDemandItems::getSkuId));

			List<DemandQuotationResponse.DemandItemDTO> demandItems = groupedBySku.entrySet().stream().map(skuEntry -> {
				Long skuId = skuEntry.getKey();

				List<DemandQuotationResponse.VendorQuotationDTO> vendors = skuEntry.getValue().stream()
						.map(item -> DemandQuotationResponse.VendorQuotationDTO.builder()
								.vendorId(item.getVendor().getVendorId()).name(item.getVendor().getName())
								.email(item.getVendor().getEmail()).phone(item.getVendor().getPhone())
								.rackId(item.getRackId()).quotationStatus(item.getQuotationStatus().getStatusName())
								.quotationStatusId(item.getQuotationStatusId())
								.approvedQuantity(item.getApprovedQuantity() != null ? item.getApprovedQuantity()
										: BigDecimal.ZERO)
								.availableQuantity(item.getAvailableQuantity()).price(item.getPricePerUnit())
								.deliveryDate(item.getDeliveryDate()).approvedDate(item.getApprovedDate())
								.batchCode(item.getBatchCode()).build())
						.toList();

				BigDecimal demandQuantity = skuEntry.getValue().get(0).getAvailableQuantity();

				return DemandQuotationResponse.DemandItemDTO.builder().skuId(skuId).demandQuantity(demandQuantity)
						.vendors(vendors).build();
			}).toList();

			DemandQuotationResponse.DemandDTO demandDTO = DemandQuotationResponse.DemandDTO.builder()
					.demandId(demand.getDemandId()).demandCode(demand.getDemandCode())
					.notes(demand.getNotes())
					.createdDate(demand.getCreatedDate())
					.modifiedDate(demand.getModifiedDate()!=null?demand.getModifiedDate():null)
					.demandEndDate(demand.getDemandEndDate()).previousEndDate(demand.getPreviousEndDate()!=null?demand.getPreviousEndDate():null)
					.demandStatus(demand.getDemandStatus()).demandItems(demandItems).build();

			return DemandQuotationResponse.builder().demand(demandDTO).build();
		}).toList();
	}

	@Override
	public InvoiceVendorSummaryResponse getInvoiceByVendorId(List<Long> demandIds, Long vendorId) {

	    // 1️⃣ Fetch invoices based on vendor and optional demand IDs
	    List<InventoryMasterPurchaseOrderInvoice> invoices = 
	        (demandIds == null || demandIds.isEmpty())
	            ? inventoryMasterPurchaseOrderInvoiceRepo.findAllByVendorId(vendorId)
	            : inventoryMasterPurchaseOrderInvoiceRepo.findByDemandIdInAndVendorId(demandIds, vendorId);

	    if (invoices == null || invoices.isEmpty()) {
	        return InvoiceVendorSummaryResponse.builder()
	                .overallApprovedAmount(BigDecimal.ZERO)
	                .overallPendingAmount(BigDecimal.ZERO)
	                .invoices(Collections.emptyList())
	                .build();
	    }

	    // 2️⃣ Convert each entity to response DTO
	    List<InvoiceVendorSummaryResponse.InvoiceVendorResponse> invoiceResponses = invoices.stream()
	        .map(invoice -> {

	            List<InvoiceItemResponse> invoiceItems = (invoice.getItems() == null)
	                    ? Collections.emptyList()
	                    : invoice.getItems().stream().map(item -> 
	                        InvoiceItemResponse.builder()
	                            .invoiceItemId(item.getInvoiceItemId())
	                            .skuId(item.getSkuId())
	                            .totalPrice(item.getTotalPrice())
	                            .quantity(item.getQuantity() != null ? item.getQuantity().longValue() : null)
	                            .pricePerUnit(item.getPricePerUnit())
	                            .build()
	                    ).collect(Collectors.toList());
	            MasterVendor vendor=null;
	            if (invoice.getMasterVendor() != null) {
	                 vendor = invoice.getMasterVendor();
	            }


	            return InvoiceVendorSummaryResponse.InvoiceVendorResponse.builder()
	                    .invoiceId(invoice.getInvoiceId())
	                    .invoiceCode(invoice.getInvoiceCode())
	                    .demandId(invoice.getDemandId())
	                    .demandCode(invoice.getDemand().getDemandCode())
	                    .shippingStatusId(invoice.getShippingStatusId())
	                    .shippingAmount(invoice.getShippingAmount())
	                    .shippingStatusName(invoice.getShippingStatus() != null? invoice.getShippingStatus().getShippingStatus(): null)
	                    .invoiceStatusId(invoice.getInvoiceStatusId())
	                    .invoiceStatusName(invoice.getInvoiceStatus() != null 
	                        ? invoice.getInvoiceStatus().getStatusName() 
	                        : null)
	                    .invoiceDate(invoice.getInvoiceDate())
	                    .vendor(vendor)
	                    .modifiedDate(invoice.getModifiedAt())
	                    .invoiceSettlementDate(invoice.getInvoiceSettlementDate())
	                    .grandTotal(invoice.getGrandTotal())
	                    .fromAddress(invoice.getFromAddress())
	                    .invoiceItem(invoiceItems)
	                    .build();
	        })
	        .collect(Collectors.toList());

	    BigDecimal totalApproved = invoiceResponses.stream()
	        .filter(inv -> "PAID".equalsIgnoreCase(inv.getInvoiceStatusName()))
	        .map(InvoiceVendorSummaryResponse.InvoiceVendorResponse::getGrandTotal)
	        .filter(Objects::nonNull)
	        .reduce(BigDecimal.ZERO, BigDecimal::add);

	    BigDecimal totalPending = invoiceResponses.stream()
	        .filter(inv -> "Pending Approval".equalsIgnoreCase(inv.getInvoiceStatusName()))
	        .map(InvoiceVendorSummaryResponse.InvoiceVendorResponse::getGrandTotal)
	        .filter(Objects::nonNull)
	        .reduce(BigDecimal.ZERO, BigDecimal::add);

	    return InvoiceVendorSummaryResponse.builder()
	            .overallApprovedAmount(totalApproved)
	            .overallPendingAmount(totalPending)
	            .invoices(invoiceResponses)
	            .build();
	}





}
