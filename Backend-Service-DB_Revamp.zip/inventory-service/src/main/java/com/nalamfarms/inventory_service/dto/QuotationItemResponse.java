package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QuotationItemResponse {
	    private Long quotationItemId;
	    private Long skuId;
	    private BigDecimal price;
	    private LocalDateTime deliveryDate;
	    private Long quotationStatusId;
	    private BigDecimal approvedQuantity;
	    private LocalDateTime approvedDate;

}
