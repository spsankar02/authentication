package com.nalamfarms.inventory_service.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data
@Entity
@Table(name = "inventory_master_warehouse")
public class MasterInventoryWareHouse {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "warehouse_id")
    private Long wareHouseId;
    @Column(name = "warehouse_code")
    private String wareHouseCode;
    @Column(name = "name")
    private String name;
    @Column(name = "location")
    private String location;
    @Column(name = "pincode")
    private String pinCode;
    @Column(name = "phone_number")
    private String phoneNumber;
    @Column(name = "email")
    private String email;
    @Column(name = "status")
    private boolean status;
    @Column(name = "latitude")
    private BigDecimal latitude;
    @Column(name = "longitude")
    private BigDecimal longitude;
    @Column(name = "capacity")
    private Long capacity;
    @Column(name = "manager_name")
    private String managerName;
    @Column(name = "notes")
    private String notes;
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    @Column(name = "updated_at")
    private LocalDateTime UpdatedAt;
    @Column(name = "created_by")
    private Long createdBy;
    @Column(name = "modified_by")
    private Long modifiedBy;

}
