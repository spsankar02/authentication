package com.nalamfarms.inventory_service.config;

import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;


@Service
public class KafkaTopicVerifier {
	
    private static final Logger log = LoggerFactory.getLogger(KafkaTopicVerifier.class);


  private final AdminClient adminClient;
  private final List<String> requiredTopics = Arrays.asList(
    "order.created",
    "payment.initiated",
    "inventory.updated",
    "shipment.created",
    "notification.send",
    "order.status.updated",
    "event.audit",
    "inventory.reserved",
    "order.confirmed",
    "refund.initiated",
    "order.cancelled",
    "payment.status.updated",
    "logistics.created"
  );

  public KafkaTopicVerifier() {
    Properties config = new Properties();
    config.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
    this.adminClient = AdminClient.create(config);
  }

  @PostConstruct
  public void checkTopicsOnStartup() {
    log.info("Verifying Kafka topics on startup...");
    checkTopics();
    createMissingTopics();
  }

  public List<String> checkTopics() {
    try {
      ListTopicsResult listTopicsResult = adminClient.listTopics();
      Set<String> existingTopics = listTopicsResult.names().get();
      log.info("Existing Kafka Topics: {}", existingTopics);

      for (String topic : requiredTopics) {
        if (existingTopics.contains(topic)) {
        	log.info("Topic '{}' exists.", topic);
        } else {
        	  log.warn("Topic '{}' does NOT exist.", topic);
        }
      }
      return requiredTopics.stream()
        .filter(existingTopics::contains)
        .toList();
    } catch (InterruptedException | ExecutionException e) {
        log.error("Error checking topics", e);
      return List.of();
    }
  }

  public boolean doesTopicExist(String topic) {
    try {
    	 boolean exists = adminClient.listTopics().names().get().contains(topic);
         log.debug("Checked existence of topic '{}': {}", topic, exists);
         return exists;
    } catch (InterruptedException | ExecutionException e) {
    	 log.error("Error checking topic '{}'", topic, e);
      return false;
    }
  }

  public void createMissingTopics() {
    try {
      ListTopicsResult listTopicsResult = adminClient.listTopics();
      Set<String> existingTopics = listTopicsResult.names().get();
      List<NewTopic> newTopics = requiredTopics.stream()
        .filter(topic -> !existingTopics.contains(topic))
        .map(topic -> new NewTopic(topic, 1, (short) 1))
        .toList();
      if (!newTopics.isEmpty()) {
        adminClient.createTopics(newTopics).all().get();
        log.info("Created missing topics: {}", newTopics.stream().map(NewTopic::name).toList());
      }
    } catch (InterruptedException | ExecutionException e) {
        log.info("No missing topics found. All required topics exist.");
    }
  }
}
