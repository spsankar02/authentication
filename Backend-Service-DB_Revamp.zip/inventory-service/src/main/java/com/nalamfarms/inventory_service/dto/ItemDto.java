package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public  class ItemDto {
    private Long skuId;
    private BigDecimal approvedQuantity;
    private String batchCode;
    private Long rackId;
    private MappingProductItemVariantSkuDto skuDetails;
    
    
    
   // private BigDecimal shippingAmount;

}