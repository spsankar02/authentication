package com.nalamfarms.inventory_service.controller;


import com.nalamfarms.inventory_service.service.InventoryConsumer;
import com.nalamfarms.inventory_service.config.KafkaTopicVerifier;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/kafka")
@ConditionalOnProperty(name ="enable.kafka",havingValue ="true",matchIfMissing =false)
public class KafkaMonitorController {

  private final KafkaTopicVerifier topicVerifier;
  private final InventoryConsumer inventoryConsumer;

  public KafkaMonitorController(KafkaTopicVerifier topicVerifier, InventoryConsumer inventoryConsumer) {
    this.topicVerifier = topicVerifier;
    this.inventoryConsumer = inventoryConsumer;
  }

  @GetMapping("/topics")
  public Map<String, Object> checkTopics() {
    List<String> existingTopics = topicVerifier.checkTopics();
    Map<String, Object> response = new HashMap<>();
    response.put("existingTopics", existingTopics);
    response.put("allTopicsExist", existingTopics.size() == 6);
    return response;
  }

  @GetMapping("/messages")
  public Map<String, Object> getMessages() {
    Map<String, Object> response = new HashMap<>();
    response.put("consumedMessages", inventoryConsumer.getConsumedMessages());
    response.put("producedMessages", inventoryConsumer.getProducedMessages());
    return response;
  }
}
