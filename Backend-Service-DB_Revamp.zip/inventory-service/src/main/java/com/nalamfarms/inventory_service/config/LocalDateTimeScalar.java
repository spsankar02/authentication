package com.nalamfarms.inventory_service.config;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import graphql.schema.Coercing;
import graphql.schema.GraphQLScalarType;

public class LocalDateTimeScalar {
	
	public static final GraphQLScalarType LOCAL_DATE_TIME = GraphQLScalarType.newScalar()
		    .name("LocalDateTime")
		    .description("Custom scalar for LocalDateTime")
		    .coercing(new Coercing<LocalDateTime, String>() {

		      @Override
		      public String serialize(Object dataFetcherResult) {
		        return ((LocalDateTime) dataFetcherResult).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		      }

		      @Override
		      public LocalDateTime parseValue(Object input) {
		        return LocalDateTime.parse(input.toString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		      }

		      @Override
		      public LocalDateTime parseLiteral(Object input) {
		        return LocalDateTime.parse(input.toString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		      }
		    })
		    .build();

}
