package com.nalamfarms.inventory_service.controller;

import java.util.List;

import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.inventory_service.dto.ChangeInvoiceStatusDTO;
import com.nalamfarms.inventory_service.dto.CountStatus;
import com.nalamfarms.inventory_service.dto.InvoiceDashboardDto;
import com.nalamfarms.inventory_service.dto.StatusUpdateResponse;
import com.nalamfarms.inventory_service.service.InvoiceService;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    InvoiceService invoiceService;
    public InvoiceController(InvoiceService invoiceService)
    {
        this.invoiceService = invoiceService;
    }

   
//    @GetMapping("/purchase/{purchaseMasterId}")
//    public ResponseEntity<Invoice> getInvoiceByPurchaseId(@PathVariable Long purchaseMasterId) {
//        Invoice invoice = invoiceService.getInvoiceByPurchaseId(purchaseMasterId);
//        return ResponseEntity.ok(invoice);
//    }

	@PutMapping("/changeInvoiceStatus")
	public StatusUpdateResponse changeInvoiceStatus(@RequestBody ChangeInvoiceStatusDTO changeInvoiceStatusDTO) {
		return invoiceService.changeInvoiceStatus(changeInvoiceStatusDTO);
	}

    @PutMapping("/getDashboardSummary")
    public ResponseEntity<InvoiceDashboardDto> getDashboardSummary() {
        InvoiceDashboardDto dashboardSummaryData = invoiceService.getDashboardSummary();
        return new ResponseEntity<>(dashboardSummaryData, HttpStatus.OK);
    }
    
    @QueryMapping
    public CountStatus calculateTotalsAmountWithStatus(){
        return invoiceService.calculateTotalsAmountWithStatus();
    }



}
