package com.nalamfarms.inventory_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderHistoryEventDto {
    private String eventName;
    private String triggeredBy;
    private Boolean status;
    private String payload;
    private Long orderId;
    private String customOrderId;
    private String errorMessage;
}
