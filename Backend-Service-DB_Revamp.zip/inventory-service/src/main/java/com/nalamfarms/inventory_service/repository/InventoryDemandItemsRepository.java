package com.nalamfarms.inventory_service.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.InventoryDemandItems;
import com.nalamfarms.inventory_service.entity.InventoryMappingQuotationDemandItems;
import com.nalamfarms.inventory_service.entity.QuotationStatus;

@Repository
public interface InventoryDemandItemsRepository extends JpaRepository<InventoryDemandItems, Long>{

	//List<InventoryDemandItems> findByDemandId(Long demandId);

	List<InventoryDemandItems> findByDemand_DemandId(Long demandId);

	long countByDemand_DemandId(Long demandId);

	//List<InventoryMappingQuotationDemandItems> findByDemand_DemandIdIn(List<Long> demandIds);



	@Query("SELECT COALESCE(SUM(i.quantity), 0) " +
			"FROM InventoryDemandItems i " +
			"WHERE i.demand.demandId = :demandId")
	BigDecimal sumQuantityByDemandId(@Param("demandId") Long demandId);
}
