package com.nalamfarms.inventory_service.service;

import java.util.List;
import java.util.Map;

import com.nalamfarms.inventory_service.dto.*;
import com.nalamfarms.inventory_service.entity.*;

import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

public interface InventoryService {

	List<String> uploadInventory(UpdateInventoryRequestDto updateInventory);

	SaveResponse checkQuantityInInventory(WishListRequest request);

	List<MasterInventoryRacks> getMasterInventoryRacks();

	List<MasterInventoryRacksType> getMasterInventoryRacksType();

	List<MasterVendor> getMasterVendors();

	List<MasterInventoryWareHouse> getMasterInventoryWareHouse();


	StatusUpdateResponse updateShippingStatus(List<UpdateShippingStatusRequest> request);

	List<MasterInventoryCertificateStatus> getCertificationStatus();

	StatusUpdateResponse updateCertificateStatus(List<UpdateCertificateStatusRequest> request);

	List<MasterInventoryStatus> getAllMasterInventoryStatus();


	StatusUpdateResponse saveOrUpdateCertificate(CertificateRequest request);

	MoveInventoryResponse updateInventoryStatus(List<MoveToInventoryRequest> moveToInventoryRequest);

	List<InventoryMasterPurchaseShippingStatus> masterPurchaseShippingStatus();

	public List<SkuInventoryData> getLowStockReport();


	List<Inventory> getRecentInventory(List<Long> skuIds);

	List<MasterCertificateType> getAllCertificateTypes();


	SaveResponse checkReserveInInventory(List<WishListRequest> requestList);

	ResponseDto createDemand(DemandRequest request);

	PagedResponse<InventoryTxnDemand> getDemandList(List<Long> demandId, int page, int pageSize);

	PagedResponse<InventoryMappingQuotationDemandItems> getQuotationList(List<Long> quoatationList,List<Long> demandId, int page, int pageSize);

	DemandSummaryDto getDemandSummary(Long DemandId);

	List<PurchaseOrderResponse> getPurchaseOrdersByDemandIds(List<Long> demandIds);

	List<DemandQuotationResponse> getVendorCapacityByDemandIds(List<Long> demandIds);

	ResponseDto createPurchaseOrder(PurchaseOrderRequest request);

	PagedResponse<InventoryMasterPurchaseOrderInvoice> getInvoiceDetails(List<Long> demandIds, int page, int size);

	ResponseDto saveVendorQuotations(List<VendorQuotations> vendorQuotationsList);

	PagedResponse<PurchaseOrderResponseDto> getInventoryByCategory(List<String> categories, int page, int size);

	VendorDemandResponse getQuotationDemandItems(Long vendorId, Long demandId);
	
	InventoryCategoryOverViewResponse inventoryCategoryOverView();

	ResponseEntity<Map<String, Object>> closeDemand(Long demandId);

	VendorDashboardSummary getVendorDashboardSummary(Long vendorId);

	List<DemandQuotationResponse> getDemandlistByVendor(List<Long> demandIds, Long vendorIds,Long actionType);

	InvoiceVendorSummaryResponse getInvoiceByVendorId(List<Long> demandIds, Long vendorIds);
}
