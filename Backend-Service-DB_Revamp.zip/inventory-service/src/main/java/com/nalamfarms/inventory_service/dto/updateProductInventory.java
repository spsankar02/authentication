package com.nalamfarms.inventory_service.dto;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class updateProductInventory {

	private Long productId;

	private Long itemId;

	private BigDecimal quantity;

	private Long actionType;

	private String orderStatus;

	private Long VariantTypeId;
}
