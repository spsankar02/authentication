package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MappingProductItemVariantSkuDto {

    private Long skuId;
    private String skuCode;
    private ItemSku itemSkuDto;
    //private Long productOriginInfo;
    private BasketSku basketSkuDto;
    private VariantTypeSku variantTypeSkuDto;
 //   private WareHouse wareHouseDto;
 //   private Vendor vendorDto;
//    private Long rackId;

    /* ---------- Static Nested Classes ---------- */

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ItemSku {
        private Long itemId;
        private String itemName;
        private String imageUrl;
        private String itemCode;
        private ItemPrice itemPrices;
        private ProductSku productSkuDto;
    }
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ItemPrice {
        private BigDecimal price;
        private BigDecimal discount;
        private BigDecimal realPrice;
        private Boolean isDealItem;
        private BigDecimal dealPrice;
        private BigDecimal dealDiscount;
        private String batchCode;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProductSku {
        private Long productId;
        private String productName;
        private String productCode;
        private ClassificationSku classificationSkuDto;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ClassificationSku {
        private Long classificationId;
        private String classifyCode;
        private String classificationName;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class BasketSku {
        private Long basketId;
        private String basketName;
        private String basketCode;
        private String imageUrl;
        private PriceSku basketSukPrice;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PriceSku {
        private Long priceId;
        private BigDecimal price;
        private BigDecimal discount;
        private Boolean isActive;
        private BigDecimal realPrice;
        private String batchCode;
    }

    @Data
    public static class VariantTypeSku {
        private Long variantTypeId;
        private String variantTypeName;
        private String variantTypeCode;
    }

    @Data
    public static class WareHouse {
        // Add warehouse fields if/when required
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Vendor {
        private Long vendorId;
        private String name;
        private String email;
        private String vendorCode;
        private String website;
        private String address;
        private String city;
        private String state;
        private String country;
        private String postalCode;
        private String logoUrl;
        private String bannerUrl;
        private Boolean isActive;
        private Boolean isVerified;
    }
}
