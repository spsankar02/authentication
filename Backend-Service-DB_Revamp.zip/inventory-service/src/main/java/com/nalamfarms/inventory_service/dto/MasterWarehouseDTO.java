package com.nalamfarms.inventory_service.dto;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class MasterWarehouseDTO {

    private Long warehouseId;
    private String warehouseCode;
    private String name;
    private String location;
    private String pincode;
    private String phoneNumber;
    private String email;
    private Boolean status;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Long capacity;
    private String managerName;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long createdBy;
    private Long modifiedBy;
}
