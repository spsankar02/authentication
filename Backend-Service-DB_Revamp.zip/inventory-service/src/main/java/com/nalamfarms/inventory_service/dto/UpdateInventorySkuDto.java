package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UpdateInventorySkuDto {

	private Long skuId;

	private String skuCode;

	private String batchCode;

	private BigDecimal quantity;
	
	private Long actionType;
}
