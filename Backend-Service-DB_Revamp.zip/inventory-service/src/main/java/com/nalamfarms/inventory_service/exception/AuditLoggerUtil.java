package com.nalamfarms.inventory_service.exception;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AuditLoggerUtil {

    private static final Logger logger = LoggerFactory.getLogger("ExceptionLogger");
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void log(Throwable exception) {
        String originatingClass = "UnknownClass";
        String originatingMethod = "UnknownMethod";
        int lineNumber = -1;

        // Find the first application class in stack trace
        for (StackTraceElement element : exception.getStackTrace()) {
            if (element.getClassName().contains("nalamfarms")) {
                String fullClassName = element.getClassName();
                originatingClass = fullClassName.substring(fullClassName.lastIndexOf('.') + 1);
                originatingMethod = element.getMethodName();
                lineNumber = element.getLineNumber();
                break;
            }
        }

        String timestamp = LocalDateTime.now().format(formatter);
        String exceptionType = exception.getClass().getSimpleName();
        String message = exception.getMessage();

        // Walk to the root cause (if any)
        Throwable rootCause = exception;
        while (rootCause.getCause() != null) {
            rootCause = rootCause.getCause();
        }

        String causeType = rootCause != exception ? rootCause.getClass().getSimpleName() : "";
        String causeMessage = rootCause != exception ? rootCause.getMessage() : "";

        logger.error(
            "AUDIT_LOG | timestamp={} | className={} | methodName={} | lineNumber={} | {}: {}{}",
            timestamp,
            originatingClass,
            originatingMethod,
            lineNumber,
            exceptionType,
            message,
            rootCause != exception ? " | cause=" + causeType + ": " + causeMessage : ""
        );
    }
}
