package com.nalamfarms.inventory_service.serviceimpl;

import java.util.List;

import com.nalamfarms.inventory_service.entity.InventoryTxnDemand;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



@Repository
public interface InventoryDemandRepository extends JpaRepository<InventoryTxnDemand,Long>{

    Long countByDemandId(Long demandId);
	List<InventoryTxnDemand> findByDemandId(Long demandId);
}
