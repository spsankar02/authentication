package com.nalamfarms.inventory_service.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class DemandResponse {
	private Long demandId;
    private String demandCode;
    private String demandStatus;
    private String notes;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    public List<DemandItemResponse> demandItems;
    public List<QuotationResponse> quotations;

}
