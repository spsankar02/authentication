package com.nalamfarms.inventory_service.dto;

import java.util.List;

import lombok.Data;


@Data
public class UpdateInventoryRequestDto {

	private List<updateBasketInventory> basket;

	private List<updateProductInventory> product;

}
