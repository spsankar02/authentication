package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.QuotationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface QuotationStatusRepository extends JpaRepository<QuotationStatus, Long> {
}
