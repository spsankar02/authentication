package com.nalamfarms.inventory_service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

//public enum QuotationStatusEnum {
//	PENDING, 
//	APPROVED, 
//	REJECTED, 
//	EXPIRED;
//
//	@JsonFormat
//	public static QuotationStatusEnum fromString(String value) {
//		return QuotationStatusEnum.valueOf(value.toUpperCase());
//	}
//}
