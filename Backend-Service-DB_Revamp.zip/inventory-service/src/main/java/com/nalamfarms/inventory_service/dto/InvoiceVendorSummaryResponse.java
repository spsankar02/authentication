package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import com.nalamfarms.inventory_service.entity.MasterVendor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InvoiceVendorSummaryResponse {

    private BigDecimal overallApprovedAmount; 
    private BigDecimal overallPendingAmount;  
    private List<InvoiceVendorResponse> invoices;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class InvoiceVendorResponse {

        private Long invoiceId;
        private String invoiceCode;
        private Long demandId;
        private String demandCode;
        private Long vendorId;
        private Long invoiceStatusId;
        private String invoiceStatusName;
        private MasterVendor vendor;
    	private Long shippingStatusId;
    	private BigDecimal shippingAmount;
    	private String shippingStatusName;
        private LocalDate invoiceDate;
        private LocalDateTime modifiedDate;
        private LocalDate invoiceSettlementDate;
        private String fromAddress;

        private BigDecimal grandTotal;

        private List<InvoiceItemResponse> invoiceItem;
    }
}
