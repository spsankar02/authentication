package com.nalamfarms.inventory_service.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nalamfarms.inventory_service.dto.OrderEventDto;
import com.nalamfarms.inventory_service.dto.OrderHistoryEventDto;
import com.nalamfarms.inventory_service.dto.SaveResponse;
import com.nalamfarms.inventory_service.dto.WishListRequest;
import com.nalamfarms.inventory_service.serviceimpl.InventoryServiceImpl;

@Service
public class InventoryConsumer {

  private static final Logger logger = LoggerFactory.getLogger(InventoryConsumer.class);
  private final KafkaTemplate<String, String> kafkaTemplate;
  private final List<String> consumedMessages = Collections.synchronizedList(new ArrayList<>());
  private final List<String> producedMessages = Collections.synchronizedList(new ArrayList<>());
  private final ObjectMapper objectMapper;
  private final InventoryServiceImpl inventoryService;
  private final InventoryProducer inventoryProducer;
  

  public InventoryConsumer(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper,InventoryServiceImpl inventoryService,InventoryProducer inventoryProducer) {

    this.kafkaTemplate = kafkaTemplate;
    this.objectMapper = objectMapper;
    this.inventoryService = inventoryService;
    this.inventoryProducer = inventoryProducer;
   
  }
  
	@KafkaListener(topics = "inventory.reserved", groupId = "inventory-group")
	public void handlePaymentSuccess(String message) {
		OrderEventDto orderEventDto = null;
		boolean auditResult = true;
		String inventoryMessage = null;
		String errorMessage = null;
		logger.info("Consumed message from order.created: {}", message);

		try {
			String json = message.replaceFirst("^Consumed message from Inventory-Reserve: ", "");
			orderEventDto = objectMapper.readValue(json, OrderEventDto.class);
			logger.info("Parsed OrderEventDto: {}", orderEventDto);

			List<WishListRequest> requestList = orderEventDto.getItems().stream().map(orderItem -> {
				WishListRequest request = new WishListRequest();
				request.setSkuId(orderItem.getSkuId());
				request.setBatchCode(orderItem.getBatchCode());
				request.setQuantity(orderItem.getQuantity());
				return request;
			}).collect(Collectors.toList());

			SaveResponse inventoryCheck = inventoryService.checkReserveInInventory(requestList);

			if (inventoryCheck.isAvailable()) {
				orderEventDto.setEventStatus("Confirmed");
				inventoryService.updateInventoryQuantity(requestList);
				inventoryProducer.updateOrderConfirmed("order.confirmed", orderEventDto);
			}

			else {
				orderEventDto.setEventStatus("Inventory Failed");
				orderEventDto.setInventoryFailedReason((inventoryCheck != null && inventoryCheck.getMessage() != null) ? inventoryCheck.getMessage() : null);
				inventoryProducer.updateOrderCancelled("order.cancelled", orderEventDto);
			}

			consumedMessages.add(message);

			inventoryMessage = "Inventory updated for order: " + message;

		} catch (Exception ex) {
			logger.error("Error processing order.created message: {}", message, ex);
			auditResult = false;
			StringWriter sw = new StringWriter();
			ex.printStackTrace(new PrintWriter(sw));
			String fullStackTrace = sw.toString();
			errorMessage = fullStackTrace;

		}

		// Send Audit Event
		if (orderEventDto != null) {
			OrderHistoryEventDto auditEvent = new OrderHistoryEventDto();
			auditEvent.setOrderId(orderEventDto.getOrderId());
			auditEvent.setPayload(orderEventDto.toString());
			auditEvent.setEventName("Inventory.Reserve");
			auditEvent.setTriggeredBy("Payment.Success");
			auditEvent.setStatus(auditResult);
			auditEvent.setErrorMessage(errorMessage);
			auditEvent.setCustomOrderId(orderEventDto.getCustomerOrderId());

			boolean auditSent = inventoryProducer.sendOrderAuditEvent("event.audit", auditEvent);
			if (auditSent) {
				logger.info("Audit event sent successfully for orderId={}", auditEvent.getOrderId());
			} else {
				logger.error("Failed to send audit event for orderId={}", auditEvent.getOrderId());
			}

		} else {
			logger.warn("Skipping audit and payment events: orderEventDto is null");
		}
	}

  @KafkaListener(topics = "order.created", groupId = "inventory-group")
  public void consumeOrderCreated(String message) {
      OrderEventDto orderEventDto = null;
      boolean auditResult = true;
      String inventoryMessage = null;
      String errorMessage=null;
      logger.info("Consumed message from order.created: {}", message);

      try {
          String json = message.replaceFirst("^Consumed message from order.created: ", "");
          orderEventDto = objectMapper.readValue(json, OrderEventDto.class);
          logger.info("Parsed OrderEventDto: {}", orderEventDto);

          inventoryService.updateInventory(orderEventDto, 3L);
          consumedMessages.add(message);

          inventoryMessage = "Inventory updated for order: " + message;

      } catch (Exception ex) {
          logger.error("Error processing order.created message: {}", message, ex);
          auditResult = false;
          StringWriter sw = new StringWriter();
          ex.printStackTrace(new PrintWriter(sw));
          String fullStackTrace = sw.toString();
          errorMessage=fullStackTrace;

      }

      // Send Audit Event
      if (orderEventDto != null) {
          OrderHistoryEventDto auditEvent = new OrderHistoryEventDto();
          auditEvent.setOrderId(orderEventDto.getOrderId());
          auditEvent.setPayload(orderEventDto.toString());
          auditEvent.setEventName("order.created");
          auditEvent.setTriggeredBy("Rest Api");
          auditEvent.setStatus(auditResult);
          auditEvent.setErrorMessage(errorMessage);
          auditEvent.setCustomOrderId(orderEventDto.getCustomerOrderId());

          boolean auditSent = inventoryProducer.sendOrderAuditEvent("event.audit", auditEvent);
          if (auditSent) {
              logger.info("Audit event sent successfully for orderId={}", auditEvent.getOrderId());
          } else {
              logger.error("Failed to send audit event for orderId={}", auditEvent.getOrderId());
          }

          // Send Payment Initiated Event (only if audit was attempted)
          if (inventoryMessage != null) {
              boolean kafkaResult = inventoryProducer.sendpaymeneInitiated(orderEventDto, inventoryMessage);
              if (kafkaResult) {
                  logger.info("Payment event sent successfully for orderId={}", auditEvent.getOrderId());
              } else {
                  logger.error("Failed to send payment event for orderId={}", auditEvent.getOrderId());
              }
          }
      } else {
          logger.warn("Skipping audit and payment events: orderEventDto is null");
      }
  }

	@KafkaListener(topics = "order.status.updated", groupId = "inventory-group")
	public void consumeOrderStatusUpdated(String message) {
	    logger.info("Consumed message from order.status.updated: {}", message);

	    OrderEventDto orderEventDto = null;
	    boolean processingSuccess = true;
	    String errorMessage=null;
	    try {
	        String json = message.replaceFirst("^Consumed message from order.status.updated: ", "");
	        orderEventDto = objectMapper.readValue(json, OrderEventDto.class);
	        logger.info("orderDetails: {}", orderEventDto);

	        inventoryService.updateInventory(orderEventDto, 5L);
	        consumedMessages.add(message);

	    } catch (Exception ex) {
	        logger.error("Error while processing order.status.updated message: {}", message, ex);
	        processingSuccess = false;
	        StringWriter sw = new StringWriter();
	          ex.printStackTrace(new PrintWriter(sw));
	          String fullStackTrace = sw.toString();
	          errorMessage=fullStackTrace;


	    }

	    if (orderEventDto != null) {
	        OrderHistoryEventDto auditEvent = new OrderHistoryEventDto();
	        auditEvent.setOrderId(orderEventDto.getOrderId());
	        auditEvent.setPayload(orderEventDto.toString());
	        auditEvent.setEventName("order.status.updated");
	        auditEvent.setTriggeredBy("notification.send");
	        auditEvent.setStatus(processingSuccess);
	        auditEvent.setErrorMessage(errorMessage);
	        auditEvent.setCustomOrderId(orderEventDto.getCustomerOrderId());

	        boolean auditSent = inventoryProducer.sendOrderAuditEvent("event.audit", auditEvent);
	        if (auditSent) {
	            logger.info("Audit event sent successfully for orderId={}", auditEvent.getOrderId());
	        } else {
	            logger.error("Failed to send audit event for orderId={}", auditEvent.getOrderId());
	        }
	    } else {
	        logger.warn("Skipping audit event; orderEventDto is null");
	    }
	}


	public void orderCancelled(String message) throws JsonProcessingException {
		logger.info("Consumed message from order.cancelled: {}", message);
		String json = message.replaceFirst("^Consumed message from order.status.updated: ", "");
		OrderEventDto orderEventDto = objectMapper.readValue(json, OrderEventDto.class);
		logger.info("orderDetails----------->" + orderEventDto);
		//inventoryService.updateInventory(orderEventDto, 11L);
		consumedMessages.add(message);
		String inventoryMessage = "Inventory updated for order: " + message;

	}


  public List<String> getConsumedMessages() {
    return new ArrayList<>(consumedMessages);
  }

  public List<String> getProducedMessages() {
    return new ArrayList<>(producedMessages);
  }
}
