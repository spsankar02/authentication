package com.nalamfarms.inventory_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VariantList {
    private Long variantTypeId;
    private String variantTypeName;
    private Integer size;
    private MasterUnit masterUnit;


}
