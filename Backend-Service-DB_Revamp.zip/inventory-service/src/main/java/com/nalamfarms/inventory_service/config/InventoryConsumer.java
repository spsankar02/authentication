//package com.nalamfarms.inventory_service.Config;
//
//import com.nalamfarms.inventory_service.Entity.InventoryEvent;
//import com.nalamfarms.order_service.Entity.OrderEvent;
//import lombok.RequiredArgsConstructor;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.stereotype.Component;
//
//@Component
//@RequiredArgsConstructor
//public class InventoryConsumer {
//  private final KafkaTemplate<String, InventoryEvent> inventoryKafkaTemplate;
//  private final KafkaTemplate<String, OrderEvent> orderKafkaTemplate;
//
//  @KafkaListener(topics = "order.created", groupId = "inventory-service")
//  public void listen(OrderEvent orderEvent) {
//    System.out.println("Received order.created: OrderId=" + orderEvent.getOrderId());
//
//    InventoryEvent inventoryEvent = new InventoryEvent();
//    inventoryEvent.setOrderId(orderEvent.getOrderId());
//    inventoryEvent.setAvailable(true); // Mock inventory check
//    inventoryKafkaTemplate.send("inventory.updated", inventoryEvent);
//
//    OrderEvent statusEvent = new OrderEvent();
//    statusEvent.setOrderId(orderEvent.getOrderId());
//    statusEvent.setStatus(inventoryEvent.isAvailable() ? "INVENTORY_CONFIRMED" : "INVENTORY_FAILED");
//    orderKafkaTemplate.send("order.status.updated", statusEvent);
//
//    System.out.println("Published inventory.updated: OrderId=" + inventoryEvent.getOrderId());
//  }
//}
