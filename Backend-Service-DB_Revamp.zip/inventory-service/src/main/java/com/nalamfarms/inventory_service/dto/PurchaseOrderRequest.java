package com.nalamfarms.inventory_service.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PurchaseOrderRequest {
	   private Long demandId;
	    private Long vendorId;
	    private List<ItemDto> items;
}
