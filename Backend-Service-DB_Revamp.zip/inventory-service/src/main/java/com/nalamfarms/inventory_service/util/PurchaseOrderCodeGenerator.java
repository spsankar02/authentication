package com.nalamfarms.inventory_service.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

@Component
public class PurchaseOrderCodeGenerator {
	
	 private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	   
	    
	    public  String generateQuotationCode(Long skuId, LocalDateTime QuotationOrderDate) {
	        if (skuId == null || QuotationOrderDate == null) {
	            throw new IllegalArgumentException("SKU ID and Quotation Order Date must not be null.");
	        }

	        String formattedDate = QuotationOrderDate.format(FORMATTER);
	        return "QUO-" + skuId + "-" + formattedDate;
	    }
	    
	    public  String generateDemandCode(Long demandId, LocalDateTime demandCreatedDate) {
	        if (demandId == null || demandCreatedDate == null) {
	            throw new IllegalArgumentException("Demand Id  and Demand created Date must not be null.");
	        }

	        String formattedDate = demandCreatedDate.format(FORMATTER);
	        return "DEM-" + demandId + "-" + formattedDate;
	    }
	    
	    public static String generateInvoiceCode(Long invoiceId) {
	        LocalDate date = LocalDate.now();
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
	        String dateStr = date.format(formatter);
	        String sequenceStr = String.format("%03d", invoiceId);
	        return "INV-" + dateStr + "-" + sequenceStr;
	    }
	    
	    public static String generateBatchCode(Long skuId) {
	        LocalDate date = LocalDate.now();
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
	        String dateStr = date.format(formatter);
	        String sequenceStr = String.format("%03d", skuId);
	        return "BAT-" + dateStr + "-" + sequenceStr;
	    }


}
