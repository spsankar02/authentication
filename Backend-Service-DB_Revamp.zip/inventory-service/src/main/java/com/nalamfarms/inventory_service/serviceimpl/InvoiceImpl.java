package com.nalamfarms.inventory_service.serviceimpl;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nalamfarms.inventory_service.dto.ChangeInvoiceStatusDTO;
import com.nalamfarms.inventory_service.dto.CountStatus;
import com.nalamfarms.inventory_service.dto.InvoiceDashboardDto;
import com.nalamfarms.inventory_service.dto.StatusUpdateResponse;
import com.nalamfarms.inventory_service.entity.InventoryMappingInvoiceItem;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrderInvoice;
import com.nalamfarms.inventory_service.entity.MasterInventoryInvoiceStatus;
import com.nalamfarms.inventory_service.repository.InventoryMappingInvoiceItemRepository;
import com.nalamfarms.inventory_service.repository.InventoryMasterPurchaseOrderInvoiceRepo;
import com.nalamfarms.inventory_service.repository.MasterInventoryInvoiceStatusRepository;
import com.nalamfarms.inventory_service.service.InvoiceService;
import com.nalamfarms.inventory_service.util.ResponseContent;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;

@Service
public class InvoiceImpl implements InvoiceService {
   
  
    @Autowired
    MasterInventoryInvoiceStatusRepository masterInventoryInvoiceStatusRepository;
    
    @Autowired
    private InventoryMappingInvoiceItemRepository invoiceItemRepository;
    
    
    @Autowired
    private InventoryMasterPurchaseOrderInvoiceRepo invoiceRepository;
  
   
    public static String generateInvoiceCode(Long invoiceId) {
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String dateStr = date.format(formatter);
        String sequenceStr = String.format("%03d", invoiceId);
        return "INV-" + dateStr + "-" + sequenceStr;
    }

   

    @Override
    public InvoiceDashboardDto getDashboardSummary() {
        return null;
    }

    @Override
    public List<MasterInventoryInvoiceStatus> getMasterInvoiceStatus() {
        return masterInventoryInvoiceStatusRepository.findAll();
    }


    @Override
    @Transactional
	public StatusUpdateResponse changeInvoiceStatus(ChangeInvoiceStatusDTO changeInvoiceStatus) {
    	if(changeInvoiceStatus==null)
    		return new StatusUpdateResponse(false, ResponseContent.REQUEST_CANNOT_BE_NULL); 
    	
		try {
			InventoryMasterPurchaseOrderInvoice invoiceDetails = invoiceRepository
					.findById(changeInvoiceStatus.getInvoiceId()).orElseThrow(() -> new EntityNotFoundException(
							ResponseContent.INVOICE_ITEM_NOT_FOUND + changeInvoiceStatus.getInvoiceId()));

			if (invoiceDetails != null) {
				invoiceDetails.setInvoiceStatusId(changeInvoiceStatus.getInvoiceStatusId());
				invoiceDetails.setModifiedAt(LocalDateTime.now());
				invoiceDetails.setInvoiceSettlementDate(LocalDate.now());
				invoiceRepository.save(invoiceDetails);
				return new StatusUpdateResponse(true, ResponseContent.UPDATED_SUCESSFULLY);
			} else {
				return new StatusUpdateResponse(false, ResponseContent.INVALID_INVOICESTATUS_ID_NOT_FOUND);
			}

		} catch (Exception e) {
			return new StatusUpdateResponse(false, ResponseContent.ERROR_MESSAGE);
		}

	}
    
    
    @Override
	public CountStatus calculateTotalsAmountWithStatus() {
		CountStatus countStatus = new CountStatus();
		LocalDate today = LocalDate.now();
		BigDecimal totalAmount = invoiceRepository.findTotalAmount();
		BigDecimal totalPaidAmount = invoiceRepository.findPaidAmount();
		BigDecimal totalUnpaidAmount = invoiceRepository.findUnpaidAmount();
		BigDecimal totalDueAmount = invoiceRepository.findTotalDueAmount(today);

		countStatus.setAmount(totalAmount != null ? totalAmount : BigDecimal.ZERO);
		countStatus.setPaidAmount(totalPaidAmount != null ? totalPaidAmount : BigDecimal.ZERO);
		countStatus.setUnPaidAmount(totalUnpaidAmount != null ? totalUnpaidAmount : BigDecimal.ZERO);
		countStatus.setDue(totalDueAmount != null ? totalDueAmount : BigDecimal.ZERO);
		return countStatus;

	}



}
