package com.nalamfarms.inventory_service.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MoveToInventoryRequest {
	
	private Long purchaseOrderItemId;
	private boolean purchaseMasterStatus;
	private String batchCode;
	private Long actionType;
	private String orderStatus;
	private List<PurchaseMasterItemRequest> purchaseItemRequest; 

}
