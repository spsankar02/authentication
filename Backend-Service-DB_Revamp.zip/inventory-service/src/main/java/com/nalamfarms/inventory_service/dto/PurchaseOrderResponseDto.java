package com.nalamfarms.inventory_service.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.nalamfarms.inventory_service.entity.InventoryMappingPurchaseOrderItems;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrderResponseDto {
	
	private String purchaseOrderCode;
	private Long purchaseOrderId;
	private Long demandId;
	private LocalDateTime purchaseOrderDate;
    private VendorDTO vendor;
    private List<PurchaseOrderItemDTO> purchaseOrderItems;

}
