package com.nalamfarms.inventory_service.entity;


import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "inventory_master_quotation_status")
public class QuotationStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "quotation_status_id")
    private Long id;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "status_name")
    private String statusName;

    @Column(name = "description")
    private String description;

}
