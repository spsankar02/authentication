package com.nalamfarms.inventory_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.QuotationItemsOriginInfo;

@Repository
public interface QuotationItemsOriginInfoRepository extends JpaRepository<QuotationItemsOriginInfo,Long> {

}
