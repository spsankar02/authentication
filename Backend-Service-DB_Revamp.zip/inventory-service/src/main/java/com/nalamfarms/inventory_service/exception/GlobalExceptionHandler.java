package com.nalamfarms.inventory_service.exception;

import java.time.LocalDateTime;
import java.util.NoSuchElementException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.messaging.handler.annotation.support.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.nalamfarms.inventory_service.dto.ErrorResponseDto;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InventoryCheckException.class)
    public ResponseEntity<?> handleInventoryException(InventoryCheckException ex,HttpServletRequest request) {
    	ErrorResponseDto errorResponseDto = new ErrorResponseDto(ex.getMessage(), LocalDateTime.now(),
				HttpStatus.INTERNAL_SERVER_ERROR, request.getRequestURI());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponseDto);
    }
    
    
	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<?> handleInvalidEnum(HttpMessageNotReadableException ex, HttpServletRequest request) {
		ErrorResponseDto errorResponseDto = new ErrorResponseDto(ex.getMessage(), LocalDateTime.now(),
				HttpStatus.BAD_REQUEST, request.getRequestURI());
		return ResponseEntity.badRequest().body(errorResponseDto);
	}
	
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<?> handleIllegalArgumentException(IllegalArgumentException ex, HttpServletRequest request) {
		ErrorResponseDto errorResponseDto = new ErrorResponseDto(ex.getMessage(), LocalDateTime.now(),
				HttpStatus.BAD_REQUEST, request.getRequestURI());
		return ResponseEntity.badRequest().body(errorResponseDto);
	}
	
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity<?> handleNoSuchElementException(NoSuchElementException ex, HttpServletRequest request) {
		ErrorResponseDto errorResponseDto = new ErrorResponseDto(ex.getMessage(), LocalDateTime.now(),
				HttpStatus.BAD_REQUEST, request.getRequestURI());
		return ResponseEntity.badRequest().body(errorResponseDto);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex,
			HttpServletRequest request) {
		ErrorResponseDto errorResponseDto = new ErrorResponseDto(ex.getMessage(), LocalDateTime.now(),
				HttpStatus.BAD_REQUEST, request.getRequestURI());
		return ResponseEntity.badRequest().body(errorResponseDto);
	}
	

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handleAll(Exception ex, HttpServletRequest request) {
		AuditLoggerUtil.log(ex);

		ErrorResponseDto errorResponseDto = new ErrorResponseDto(ex.getMessage(), LocalDateTime.now(),
				HttpStatus.INTERNAL_SERVER_ERROR, request.getRequestURI());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponseDto);

	}
	
}

