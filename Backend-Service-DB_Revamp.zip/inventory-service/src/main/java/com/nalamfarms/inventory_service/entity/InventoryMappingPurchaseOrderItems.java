package com.nalamfarms.inventory_service.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "inventory_mapping_purchase_order_items", schema = "public")
@ToString(exclude = "purchaseOrder") 
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InventoryMappingPurchaseOrderItems {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "purchase_order_item_id", nullable = false)
    private Long purchaseOrderItemId;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "is_inventory_moved")
    private Boolean isInventoryMoved;

    @Column(name = "certificate_type_id")
    private Long certificateTypeId;
    
    @Column(name = "sku_id")
    private Long skuId;
    
    @Column(name = "certificate_status_id")
    private Long certificateStatusId;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "certificate_status_id",insertable = false,updatable = false)
    private MasterInventoryCertificateStatus certificateStatus;
    
 
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "certificate_type_id",insertable = false,updatable = false)
    private MasterCertificateType certificateType;

    @Column(name = "shipping_status_id")
    private Long shippingStatusId;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipping_status_id",insertable = false,updatable = false)
    private InventoryMasterPurchaseShippingStatus shippingStatus;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_order_id", referencedColumnName = "purchase_order_id", nullable = false,insertable=false,updatable=false)
    private InventoryMasterPurchaseOrder purchaseOrder;
    
        
    @Column(name = "mfg_date")
    private LocalDateTime mfgDate;
    
    @Column(name = "exp_date")
    private LocalDateTime expDate;
    
    @Column(name = "rack_id")
    private Long rackId;
   
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "rack_id",insertable = false,updatable = false)
    private MasterInventoryRacks rack;
    
    @Column(name = "notes")
    private String notes;
    
    @Column(name="purchase_order_id")
    private Long purchaseOrderId;
    
    @Column(name="quantity")
    private BigDecimal quantity;
    
    
    @Column(name="price_per_unit")
    private BigDecimal pricePerUnit;
    
    @Column(name="total_price")
    private BigDecimal totalPrice;
    
    @Column(name="shipping_amount")
    private BigDecimal shippingAmount;
    
    @Column(name="batch_code")
    private String batchCode;
    
    @Column(name="qr_path")
    private String qrPath;
     
   
}
