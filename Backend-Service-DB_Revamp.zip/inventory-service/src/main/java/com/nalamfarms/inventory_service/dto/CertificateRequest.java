package com.nalamfarms.inventory_service.dto;

import lombok.Data;

@Data
public class CertificateRequest {
    private Long purchaseMasterId;
    private Long purchaseItemId;
    private Long certificateStatusId;
}
