package com.nalamfarms.inventory_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.graphql.execution.RuntimeWiringConfigurer;


import graphql.scalars.ExtendedScalars;

@Configuration
public class GraphQLConfig {

	@Bean
	public RuntimeWiringConfigurer runtimeWiringConfigurer() {
		return wiringBuilder -> wiringBuilder.scalar(ExtendedScalars.GraphQLLong)
				.scalar(LocalDateTimeScalar.LOCAL_DATE_TIME)
		        .scalar(ExtendedScalars.GraphQLBigDecimal)
                .scalar(ExtendedScalars.GraphQLLong);
	}

}
