package com.nalamfarms.inventory_service.controller;

import com.nalamfarms.inventory_service.entity.MasterInventoryInvoiceStatus;
import com.nalamfarms.inventory_service.service.InvoiceService;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;

@Controller
public class InvoiceGraphQLController {

	InvoiceService invoiceService;

	public InvoiceGraphQLController(InvoiceService invoiceService) {
		this.invoiceService = invoiceService;
	}

	@QueryMapping
	public List<MasterInventoryInvoiceStatus> getMasterInvoiceStatus() {
		return invoiceService.getMasterInvoiceStatus();
	}

}
