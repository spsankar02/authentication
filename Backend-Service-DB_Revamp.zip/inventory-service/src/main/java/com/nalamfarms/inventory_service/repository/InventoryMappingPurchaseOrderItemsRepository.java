package com.nalamfarms.inventory_service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.InventoryMappingPurchaseOrderItems;

@Repository
public interface InventoryMappingPurchaseOrderItemsRepository
        extends JpaRepository<InventoryMappingPurchaseOrderItems, Long> {

    long countByShippingStatusId(Long shippingStatusId);
    long countByCertificateStatusId(Long CertificateStatusId);
    long countByIsInventoryMoved(Boolean IsInventoryMoved);
	boolean existsBySkuIdAndIsInventoryMovedTrue(Long skuId);
	Optional<InventoryMappingPurchaseOrderItems> findTopBySkuIdAndIsInventoryMovedTrueOrderByExpDateAsc(Long skuId);
	List<InventoryMappingPurchaseOrderItems> findByPurchaseOrderId(Long purchaseOrderId);

}