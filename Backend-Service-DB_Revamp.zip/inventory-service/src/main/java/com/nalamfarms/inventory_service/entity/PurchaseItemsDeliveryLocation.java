package com.nalamfarms.inventory_service.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.Type;

import com.vladmihalcea.hibernate.type.basic.PostgreSQLEnumType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inventory_mapping_purchase_items_deliverylocation", schema = "public")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseItemsDeliveryLocation {
		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "deliverylocation_id")
	    private Long deliveryLocationId;

	    @Column(name = "address", nullable = false)
	    private String address;

	    @Column(name = "pincode", nullable = false)
	    private String pincode;

	    @Column(name = "city", nullable = false)
	    private String city;

	    @Column(name = "state", nullable = false)
	    private String state;

	    @Column(name = "country", nullable = false)
	    private String country;

	    @Column(name = "created_at", nullable = false)
	    private LocalDateTime createdAt=LocalDateTime.now();

	    @Column(name = "modified_at")
	    private LocalDateTime modifiedAt=LocalDateTime.now();

	    @Column(name = "created_by", nullable = false)
	    private Long createdBy=1l;

	    @Column(name = "modified_by")
	    private Long modifiedBy=1l;

	    @Enumerated(EnumType.STRING)
	    @Column(name = "deliverylocation_status",columnDefinition = "deliverylocation_status")
	    @Type(PostgreSQLEnumType.class)
	    private DeliveryLocationStatus deliveryLocationStatus;

}
