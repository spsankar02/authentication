package com.nalamfarms.inventory_service.entity;

import jakarta.persistence.*;
import lombok.Data;
import jakarta.persistence.Id;
import java.time.LocalDateTime;
@Data
@Entity
@Table(name = "inventory_master_racks_type")
public class MasterInventoryRacksType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rack_type_id")
    private Long rackTypeId;
    @Column(name = "rack_type_code")
    private String rackTypeCode;
    @Column(name = "rack_type_name")
    private String rackTypeName;
    @Column(name = "best_for")
    private String bestFor;
    @Column(name = "description")
    private String description;
    @Column(name = "created_date")
    private LocalDateTime createdDate;
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
    @Column(name = "created_by")
    private Long createBy;
    @Column(name = "modified_by")
    private Long modifiedBy;

}
