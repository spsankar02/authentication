package com.nalamfarms.inventory_service.dto;


import java.util.List;

import lombok.Data;

@Data
public class DemandRequest {
	   	private String notes;
	    private List<DemandItemDto> demandItems;
	    private String demandEndDate;
}
