package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateShippingStatusRequest {
	 private Long purchaseOrderItemId;
	 private Long purchaseOrderId;
	 private Long vendorId;
	 private Long demandId;
	 private boolean isAdmin;
	 private Long newStatus; 
	 private Long rackId;
	// private BigDecimal price;
	 private LocalDateTime mfgDate;
	 private LocalDateTime expDate;
	 private String notes;
	 private BigDecimal shippingAmount;
	 
	    
}
