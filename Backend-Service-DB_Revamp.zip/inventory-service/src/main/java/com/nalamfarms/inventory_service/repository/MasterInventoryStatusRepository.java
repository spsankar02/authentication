package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.MasterInventoryRacksType;
import com.nalamfarms.inventory_service.entity.MasterInventoryStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterInventoryStatusRepository extends JpaRepository<MasterInventoryStatus, Long> {


}
