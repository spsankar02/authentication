package com.nalamfarms.inventory_service.util;

import java.util.Arrays;

import org.springframework.stereotype.Component;

@Component
public class SkuGeneratorUtil {

    public static String generateSku(String vendorCode, String classificationCode,
                                     String productCode, String itemCode, String variantTypeCode) {

        return String.join("-", Arrays.asList(
                vendorCode,
                classificationCode,
                productCode,
                itemCode,
                variantTypeCode
        ));
    }
}
