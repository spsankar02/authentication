package com.nalamfarms.inventory_service.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "inventory_master_purchase_order", schema = "public")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InventoryMasterPurchaseOrder {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "purchase_order_id", nullable = false)
	    private Long purchaseOrderId;

	    @Column(name = "demand_id", nullable = false)
	    private Long demandId;

	    @Column(name="vendor_id")
	    private Long vendorId;
	    
	    @ManyToOne(fetch = FetchType.LAZY)
	    @JoinColumn(name = "vendor_id", nullable = false,insertable = false,updatable=false)
	    private MasterVendor vendor;

	    @Column(name = "purchase_order_date", nullable = false)
	    private LocalDateTime purchaseOrderDate;

	    @Column(name = "created_at", nullable = false)
	    private LocalDateTime createdAt;

	    @Column(name = "modified_at")
	    private LocalDateTime modifiedAt;

	    @Column(name = "created_by")
	    private Long createdBy;

	    @Column(name = "modified_by")
	    private Long modifiedBy;
	    
	    @Column(name = "purchase_order_code", nullable = false)
	    private String purchaseOrderCode;
	    
	    
	    @OneToMany(mappedBy = "purchaseOrder", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	    private List<InventoryMappingPurchaseOrderItems> purchaseOrderItems;
	    
	    

}
