package com.nalamfarms.inventory_service.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "inventory_mapping_invoice_item")
public class InventoryMappingInvoiceItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "invoice_item_id")
    Long invoiceItemId;

    @Column(name = "sku_id")
    Long skuId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invoice_id", nullable = false,insertable = false,updatable = false)
    @JsonBackReference
    private InventoryMasterPurchaseOrderInvoice invoice;
    
    @Column(name = "invoice_id")
    private Long invoiceId;

    @Column(name = "created_at")
    LocalDateTime createdAt=LocalDateTime.now();

    @Column(name = "modified_at")
    LocalDateTime modifiedAt;

//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "shipping_status_id", nullable = false,insertable = false,updatable = false)  
//    private InventoryMasterPurchaseShippingStatus shippingStatus;

//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "invoice_status_id", nullable = false,insertable = false,updatable = false)  
//    private MasterInventoryInvoiceStatus invoiceStatus;
    
//    @Column(name = "shipping_status_id")
//    private Long shippingStatusId;
    
//    @Column(name = "invoice_status_id")
//    private Long invoiceStatusId;
    
    @Column(name = "purchase_order_item_id")
    private Long purchaseOrderItemId;
    
//    @Column(name = "shipping_amount")
//    private BigDecimal shippingAmount;
    
    @Column(name="total_price")
    private BigDecimal totalPrice;
    
    @Column(name="quantity")
    private BigDecimal quantity;
    
    @Column(name="price_per_unit")
    private BigDecimal pricePerUnit;
    
    @Column(name="created_by")
    private Long createdBy=1l;
    
    @Column(name="modified_by")
    private Long modifiedBy=1l;
    
    
    
    
    
}
