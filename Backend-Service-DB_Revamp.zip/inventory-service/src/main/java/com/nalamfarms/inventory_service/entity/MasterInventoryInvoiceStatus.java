package com.nalamfarms.inventory_service.entity;


import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "inventory_master_invoice_status")
public class MasterInventoryInvoiceStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "invoice_status_id")
    private Long invoiceStatusId;
    @Column(name = "status_name")
    private String statusName;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "description")
    private String description;


}
