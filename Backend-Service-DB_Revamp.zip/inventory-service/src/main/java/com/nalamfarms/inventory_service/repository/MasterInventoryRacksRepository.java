package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.Inventory;
import com.nalamfarms.inventory_service.entity.MasterInventoryRacks;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterInventoryRacksRepository extends JpaRepository<MasterInventoryRacks, Long> {

    
}
