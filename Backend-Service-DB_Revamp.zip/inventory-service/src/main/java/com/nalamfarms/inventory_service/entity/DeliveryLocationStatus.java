package com.nalamfarms.inventory_service.entity;

public enum DeliveryLocationStatus {

	NALAM, VENDOR

}
