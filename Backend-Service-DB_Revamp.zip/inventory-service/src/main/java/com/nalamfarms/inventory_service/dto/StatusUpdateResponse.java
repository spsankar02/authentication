package com.nalamfarms.inventory_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StatusUpdateResponse {
	Boolean status;
     String message;
}
