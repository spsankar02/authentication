package com.nalamfarms.inventory_service.util;

import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Component;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.nalamfarms.inventory_service.repository.SettingsRepository;

@Component
public class ImageUploadUtil {
	
	 public static final String SLASH = "/";
	    public static final String ACCESS_KEY = "amazon_Acess_Key";
	    public static final String SECRET_KEY = "amazon_Secret_Key";
	    public static final String S3URL = "awsS3RealPath";
	    public static final String BUCKET_NAME = "Bucketname";
	    public static final String HOSTED_MODEL = "HOSTED_MODEL";
	    public static final String CLOUD = "CLOUD";
	    public static final String WORKSPACE_PATH = "workspacePath";
	    public static final String IMAGE_UPLOAD_PATH = "farmuploads";


	    public static final String IMAGE_UPLOAD_PATH_BANNER = "banneruploads";

	    private static final Logger logger = LoggerFactory.getLogger(ImageUploadUtil.class);
		private static final String IMAGE_UPLOAD_PATH_QRCODE = "qrCodeUploads";



	    @Autowired
	    private SettingsRepository configSettingsRepo;

	    public AmazonS3Client getS3Client() {
	        String access_key = configSettingsRepo.findByName(ACCESS_KEY).getValue();
	        String secret_key = configSettingsRepo.findByName(SECRET_KEY).getValue();
	        String s3Url = configSettingsRepo.findByName(S3URL).getValue();

	        AWSCredentials creds = new BasicAWSCredentials(access_key, secret_key);

	        return (AmazonS3Client) AmazonS3ClientBuilder.standard()
	                .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(s3Url, Regions.AP_SOUTH_1.name()))
	                .withPathStyleAccessEnabled(true)
	                .withCredentials(new AWSStaticCredentialsProvider(creds))
	                .build();
	    }

	    
	    public String uploadQrCodeToS3(byte[] qrCodeBytes, String sku) {
	        String bucketName = configSettingsRepo.findByName(BUCKET_NAME).getValue();
	        logger.info("Bucket Name: {}", bucketName);

	        String qrCodeUploads = configSettingsRepo.findByName(IMAGE_UPLOAD_PATH_QRCODE).getValue(); // e.g., "qrcodes/"
	        String hostModelType = configSettingsRepo.findByName(HOSTED_MODEL).getValue();

	        ByteArrayInputStream bis = new ByteArrayInputStream(qrCodeBytes);

	        // Use SKU in filename:
	        String sanitizedSku = sku.replaceAll("[^a-zA-Z0-9_-]", "_"); // prevent S3 issues with special chars
	        String fileName = "qrcode_" + sanitizedSku + ".png";
	        String s3Key = qrCodeUploads + fileName;

	        logger.info("QR Upload Path: {}", qrCodeUploads);

	        if (CLOUD.equalsIgnoreCase(hostModelType)) {
	            AmazonS3Client s3Client = getS3Client();

	            ObjectMetadata metadata = new ObjectMetadata();
	            metadata.setContentLength(qrCodeBytes.length);
	            metadata.setContentType("image/png");

	            PutObjectRequest s3Put = new PutObjectRequest(
	                    bucketName,
	                    s3Key,
	                    bis,
	                    metadata
	            ).withCannedAcl(CannedAccessControlList.PublicReadWrite); 

	            logger.info("Uploading QR to S3 -> Bucket: {}, Key: {}", bucketName, s3Key);
	            s3Client.putObject(s3Put);
	        }

	        return s3Key;
	    }

}
