package com.nalamfarms.inventory_service.service;

import com.nalamfarms.inventory_service.dto.ChangeInvoiceStatusDTO;
import com.nalamfarms.inventory_service.dto.CountStatus;
import com.nalamfarms.inventory_service.dto.InvoiceDashboardDto;
import com.nalamfarms.inventory_service.dto.StatusUpdateResponse;
import com.nalamfarms.inventory_service.entity.MasterInventoryInvoiceStatus;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public interface InvoiceService {

   
    InvoiceDashboardDto getDashboardSummary();

    public List<MasterInventoryInvoiceStatus> getMasterInvoiceStatus();
	StatusUpdateResponse changeInvoiceStatus(ChangeInvoiceStatusDTO changeInvoiceStatusDTO);

	CountStatus calculateTotalsAmountWithStatus();

}
