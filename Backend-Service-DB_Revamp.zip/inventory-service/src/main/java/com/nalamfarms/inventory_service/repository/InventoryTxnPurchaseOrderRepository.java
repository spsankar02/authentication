package com.nalamfarms.inventory_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.InventoryTxnPurchaseOrder;

@Repository
public interface InventoryTxnPurchaseOrderRepository extends JpaRepository<InventoryTxnPurchaseOrder, Long> {

	List<InventoryTxnPurchaseOrder> findAllByOrderByPurchaseOrderIdDesc();

	List<InventoryTxnPurchaseOrder> findAllByPurchaseOrderIdInOrderByPurchaseOrderIdDesc(List<Long> purchaseOrderIds);
    
}