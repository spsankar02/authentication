package com.nalamfarms.inventory_service.repository;

import com.nalamfarms.inventory_service.entity.MasterInventoryInvoiceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MasterInventoryInvoiceStatusRepository extends JpaRepository<MasterInventoryInvoiceStatus, Long> {
}
