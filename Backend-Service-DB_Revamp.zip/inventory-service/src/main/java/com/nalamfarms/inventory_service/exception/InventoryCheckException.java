package com.nalamfarms.inventory_service.exception;


public class InventoryCheckException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InventoryCheckException(String message, Throwable cause) {
		super(message, cause);
	}

	public InventoryCheckException(String message) {
		super(message);
	}
}
