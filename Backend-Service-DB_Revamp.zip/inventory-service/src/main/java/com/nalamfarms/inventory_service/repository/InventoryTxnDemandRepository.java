package com.nalamfarms.inventory_service.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.nalamfarms.inventory_service.entity.InventoryTxnDemand;

public interface InventoryTxnDemandRepository extends JpaRepository<InventoryTxnDemand, Long> {
//	  @Query(value = "SELECT * FROM inventory_txn_demand d " +
//              "WHERE d.demand_id IN (:demandId) " +
//              "ORDER BY d.created_date DESC " +
//              "LIMIT :limit",
//      nativeQuery = true)
//	List<InventoryTxnDemand> findByDemandIdsWithLimit(@Param("limit") int limit, @Param("demandId") List<Long> demandId);

	Page<InventoryTxnDemand> findByDemandIdInOrderByCreatedDateDesc(
			List<Long> demandIds,
			Pageable pageable
	);


	Page<InventoryTxnDemand> findByDemandIdIn(List<Long> demandId, Pageable pageable);
                                                 
}
