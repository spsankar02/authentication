package com.nalamfarms.inventory_service.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inventory_mapping_quotation_demand_items", schema = "public")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InventoryMappingQuotationDemandItems {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "quotation_id", nullable = false)
	private Long quotationId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "vendor_id", referencedColumnName = "vendor_id", nullable = false,updatable = false,insertable = false)
	private MasterVendor vendor;
	
	@Column(name = "vendor_id")
	private Long vendorId;

	@Column(name = "sku_id")
	private Long skuId;

	@Column(name = "price_per_unit", nullable = false)
	private BigDecimal pricePerUnit;

	@Column(name = "delivery_date", nullable = false)
	private LocalDateTime deliveryDate;

	@Column(name = "created_at", nullable = false)
	private LocalDateTime createdAt=LocalDateTime.now();

	@Column(name = "modified_at")
	private LocalDateTime modifiedAt=LocalDateTime.now();

	@Column(name = "created_by")
	private Long createdBy=1l;

	@Column(name = "modified_by")
	private Long modifiedBy=1l;

	@Column(name = "quotation_status_id", nullable = false)
	private Long quotationStatusId=1l;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "quotation_status_id", nullable = false,updatable = false,insertable = false)
	private QuotationStatus quotationStatus;

	@Column(name = "available_quantity")
	private BigDecimal AvailableQuantity;

	@Column(name = "approved_date")
	private LocalDateTime approvedDate;

	@Column(name = "approved_quantity")
	private BigDecimal approvedQuantity;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "demand_id", referencedColumnName = "demand_id",updatable = false,insertable = false)
	private InventoryTxnDemand demand;
	
	@Column(name = "demand_id")
	private Long demandId;
	
	@Column(name = "batch_code")
	private String batchCode;
	
	@Column(name = "delivery_location_id")
	private Long deliveryLocationId;
	
	@Column(name = "rack_id")
	private Long rackId;
	
	

}
