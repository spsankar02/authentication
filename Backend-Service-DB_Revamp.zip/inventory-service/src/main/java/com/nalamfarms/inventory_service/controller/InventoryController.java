package com.nalamfarms.inventory_service.controller;

import java.util.List;
import java.util.Map;

import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.inventory_service.dto.CertificateRequest;
import com.nalamfarms.inventory_service.dto.DemandQuotationResponse;
import com.nalamfarms.inventory_service.dto.DemandRequest;
import com.nalamfarms.inventory_service.dto.DemandSummaryDto;
import com.nalamfarms.inventory_service.dto.InventoryCategoryOverViewResponse;
import com.nalamfarms.inventory_service.dto.InvoiceDetailsPayload;
import com.nalamfarms.inventory_service.dto.InvoiceVendorSummaryResponse;
import com.nalamfarms.inventory_service.dto.MoveInventoryResponse;
import com.nalamfarms.inventory_service.dto.MoveToInventoryRequest;
import com.nalamfarms.inventory_service.dto.PagedResponse;
import com.nalamfarms.inventory_service.dto.PurchaseOrderRequest;
import com.nalamfarms.inventory_service.dto.PurchaseOrderResponse;
import com.nalamfarms.inventory_service.dto.PurchaseOrderResponseDto;
import com.nalamfarms.inventory_service.dto.ResponseDto;
import com.nalamfarms.inventory_service.dto.SaveResponse;
import com.nalamfarms.inventory_service.dto.SkuInventoryData;
import com.nalamfarms.inventory_service.dto.StatusUpdateResponse;
import com.nalamfarms.inventory_service.dto.UpdateCertificateStatusRequest;
import com.nalamfarms.inventory_service.dto.UpdateInventoryRequestDto;
import com.nalamfarms.inventory_service.dto.UpdateShippingStatusRequest;
import com.nalamfarms.inventory_service.dto.VendorDashboardSummary;
import com.nalamfarms.inventory_service.dto.VendorDemandResponse;
import com.nalamfarms.inventory_service.dto.VendorQuotations;
import com.nalamfarms.inventory_service.dto.WishListRequest;
import com.nalamfarms.inventory_service.entity.Inventory;
import com.nalamfarms.inventory_service.entity.InventoryMappingQuotationDemandItems;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrderInvoice;
import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseShippingStatus;
import com.nalamfarms.inventory_service.entity.InventoryTxnDemand;
import com.nalamfarms.inventory_service.entity.MasterCertificateType;
import com.nalamfarms.inventory_service.entity.MasterInventoryCertificateStatus;
import com.nalamfarms.inventory_service.entity.MasterInventoryRacks;
import com.nalamfarms.inventory_service.entity.MasterInventoryRacksType;
import com.nalamfarms.inventory_service.entity.MasterInventoryStatus;
import com.nalamfarms.inventory_service.entity.MasterInventoryWareHouse;
import com.nalamfarms.inventory_service.entity.MasterVendor;
import com.nalamfarms.inventory_service.service.InventoryService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/inventory")
@RequiredArgsConstructor
public class InventoryController {

	private final InventoryService inventoryService;

	@PostMapping("/checkQuantityInInventory")
	public SaveResponse checkQuantityInInventory(@RequestBody WishListRequest request) {
		return inventoryService.checkQuantityInInventory(request);
	}
	
	@PostMapping("/checkQuantity")
	public SaveResponse checkQuantity(@RequestBody List<WishListRequest> requestList) {
		return inventoryService.checkReserveInInventory(requestList);
	}

	@PostMapping(value = "/updateInventory")
	public ResponseEntity<List<String>> updateInventory(@RequestBody UpdateInventoryRequestDto updateInventory) {
		List<String> updateInventoryList = inventoryService.uploadInventory(updateInventory);
		return ResponseEntity.ok(updateInventoryList);
	}

	@GetMapping("/racks")
	public List<MasterInventoryRacks> getAllRacks() {
		return inventoryService.getMasterInventoryRacks();
	}

	@GetMapping("/rackTypes")
	public List<MasterInventoryRacksType> getAllRackTypes() {
		return inventoryService.getMasterInventoryRacksType();
	}

	@GetMapping("/masterVendors")
	public List<MasterVendor> getMasterVendors() {
		return inventoryService.getMasterVendors();
	}

	@GetMapping("/masterInventoryWareHouse")
	public List<MasterInventoryWareHouse> getMasterInventoryWareHouse() {
		return inventoryService.getMasterInventoryWareHouse();
	}

	


	@PutMapping("/updateShippingStatus")
	public StatusUpdateResponse updateShippingStatus(@RequestBody List<UpdateShippingStatusRequest> request) {
		return inventoryService.updateShippingStatus(request);
	}

	@QueryMapping
	public List<MasterInventoryCertificateStatus> getCertificationStatus() {
		return inventoryService.getCertificationStatus();
	}
	
	@PutMapping("/updateCertificateStatus")
	public StatusUpdateResponse updateCertificateStatus( @RequestBody List<UpdateCertificateStatusRequest> requestList) {
		return inventoryService.updateCertificateStatus(requestList);
	}
	@QueryMapping
	public List<MasterInventoryStatus> getAllMasterInventoryStatus() {
		return inventoryService.getAllMasterInventoryStatus();
	}



	@PostMapping("/saveOrUpdatePurchaseCertificate")
	public StatusUpdateResponse saveOrUpdatePurchaseCertificate(@RequestBody CertificateRequest request) {
	    return inventoryService.saveOrUpdateCertificate(request);
	}



	@PostMapping("/moveToInventory")
	public MoveInventoryResponse updateInventoryStatus(
			@RequestBody List<MoveToInventoryRequest> moveToInventoryRequest) {
		return inventoryService.updateInventoryStatus(moveToInventoryRequest);

	}
	
	
	
	@QueryMapping
	public List<InventoryMasterPurchaseShippingStatus> masterPurchaseShippingStatus() {
		return inventoryService.masterPurchaseShippingStatus();
	}

	@QueryMapping
	public List<SkuInventoryData> getLowStockReport()  {
		return inventoryService.getLowStockReport();
	}
	
	

	@QueryMapping
	public List<Inventory> getRecentInventory(@Argument List<Long> skuIds){
		return inventoryService.getRecentInventory(skuIds);
	}
	
	 @QueryMapping
	 public List<MasterCertificateType> getAllCertificateTypes() {
	        return inventoryService.getAllCertificateTypes();
	  }
	 
	
	 
	   /**DEMAND API**/
	@QueryMapping
	 public List<PurchaseOrderResponse> getPOByDemandId(@Argument List<Long> demandIds) {
	        return inventoryService.getPurchaseOrdersByDemandIds(demandIds);
	    }
	 	
	@QueryMapping
	public List<DemandQuotationResponse> getVendorCapacityByDemandIds(@Argument List<Long> demandIds) {
			 return inventoryService.getVendorCapacityByDemandIds(demandIds);
		}
	

	@QueryMapping
	public DemandSummaryDto getDemandSummary(@Argument Long demandId) {
		return inventoryService.getDemandSummary(demandId);
	}


	//@Argument List<Long> demandIds,@Argument int page,@Argument int pageSize
	@PostMapping("/getInvoiceDetails")
	public ResponseEntity<PagedResponse<InventoryMasterPurchaseOrderInvoice>> getInvoiceDetails(@RequestBody InvoiceDetailsPayload invoiceDetailsPayload) {
        return new ResponseEntity<>(inventoryService.getInvoiceDetails(invoiceDetailsPayload.getDemandIds(), invoiceDetailsPayload.getPage(), invoiceDetailsPayload.getPageSize()), HttpStatus.OK);
    }

	@PostMapping("/createDemand")
	public ResponseDto CreateDemand(@RequestBody DemandRequest request) {
		return inventoryService.createDemand(request);
	}

	@QueryMapping
	public PagedResponse<InventoryTxnDemand> getDemandList(@Argument List<Long> demandId,@Argument int page,@Argument int pageSize ){
		return inventoryService.getDemandList(demandId,page,pageSize);
	}

	//Initiate Purchase Order and Generate QrPath.
	@PostMapping("/createPurchaseOrder")
	public ResponseDto createPurchaseOrder(@RequestBody PurchaseOrderRequest request) {
		return inventoryService.createPurchaseOrder(request);
	}
	
	@PostMapping("/saveVendorQuotations")
	public ResponseDto saveVendorQuotations(@RequestBody List<VendorQuotations> vendorQuotationsList) {
		return inventoryService.saveVendorQuotations(vendorQuotationsList);
		
	}
	
	//PagedResponse<InventoryTxnDemand>
	@QueryMapping
	public PagedResponse<InventoryMappingQuotationDemandItems> getQuotationList(@Argument List<Long> quotationIds, @Argument List<Long> demandIds,@Argument int page,@Argument int pageSize ){
		return inventoryService.getQuotationList(quotationIds,demandIds,page,pageSize);
	}
	
	@QueryMapping
	public PagedResponse<PurchaseOrderResponseDto> getInventoryByCategory(@Argument List<String> categories, @Argument int page, @Argument int size) {
		return inventoryService.getInventoryByCategory(categories,page,size);
	}
	@QueryMapping
	public VendorDemandResponse getQuotationDemandItems(@Argument Long vendorId,@Argument Long demandId){
	return inventoryService.getQuotationDemandItems(vendorId,demandId);
	
	}

    @QueryMapping
    public InventoryCategoryOverViewResponse inventoryCategoryOverView() {
        return inventoryService.inventoryCategoryOverView();
    }

	@PostMapping("/closedDemand/{demandId}")
	public ResponseEntity<Map<String, Object>> closedDemand(@PathVariable Long demandId) {
		return inventoryService.closeDemand(demandId);
	}
	
	@QueryMapping
	public VendorDashboardSummary getVendorDashboardSummary(@Argument Long vendorId) {
		return inventoryService.getVendorDashboardSummary(vendorId);
	}
	
	@QueryMapping
	public List<DemandQuotationResponse> getDemandlistByVendor(@Argument List<Long> demandIds,@Argument Long vendorIds,@Argument Long actionType) {
			 return inventoryService.getDemandlistByVendor(demandIds,vendorIds,actionType);
		}
	
		@QueryMapping
		public InvoiceVendorSummaryResponse getInvoiceByVendorId(@Argument List<Long> demandIds,
				@Argument Long vendorIds) {
			return inventoryService.getInvoiceByVendorId(demandIds, vendorIds);

		}
}
