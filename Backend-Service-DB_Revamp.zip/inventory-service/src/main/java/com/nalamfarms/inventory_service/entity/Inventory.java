package com.nalamfarms.inventory_service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;


@Entity
@Table(name = "inventory_txn_inventory")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Inventory {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "inventory_id")
  private Long inventoryId;


  @Column(name = "quantity_available")
  private BigDecimal quantityAvailable;

  @Column(name = "quantity_reserved")
  private BigDecimal quantityReserved=BigDecimal.ZERO;

  @Column(name = "created_at", nullable = false)
  private Date createdAt=new Date();

  @Column(name = "modified_at")
  private Date modifiedAt;


  @Column(name = "created_by", nullable = false)
  private Long createdBy=1l;

  @Column(name = "modified_by")
  private Long modifiedBy=1l; 
  
  @Column(name="sku_id")
  private Long skuId;
  
  @Column(name="batch_code")
  private String batchCode;

  @Transient
  private BigDecimal stockQuantity;

  // Getter to compute stockQuantity dynamically
  public BigDecimal getStockQuantity() {
    if (quantityAvailable == null) return BigDecimal.ZERO;
    if (quantityReserved == null) return quantityAvailable;
    return quantityAvailable.subtract(quantityReserved);
  }

}
