package com.nalamfarms.inventory_service.dto;

public class InvoiceDashboardDto {

    Long totalAmount;
    Long paid;
    Long totalUnpaid;
    Long overDue;

}
