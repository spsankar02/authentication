package com.nalamfarms.inventory_service.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;

@Entity
@Table(name = "inventory_txn_purchase_order", schema = "public")
@Data
public class InventoryTxnPurchaseOrder {

    @Id
    @Column(name = "purchase_order_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long purchaseOrderId;

    @Column(name = "sku_id", nullable = false)
    private Long skuId;

    @Column(name = "created_date", nullable = false)
    private LocalDateTime createdDate=LocalDateTime.now();

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate=LocalDateTime.now();

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;
    
    @Column(name="purchase_order_date")
    private LocalDateTime purchaseOrderDate=LocalDateTime.now();
    
    @Column(name="warehouse_id")
	private Long warehouseId;
    
    @Column(name="purchase_order_code",unique=true)
    private String purchaseOrderCode;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="warehouse_id", insertable = false, updatable = false)
	private MasterInventoryWareHouse warehouse;
	
	@Column(name="description")
	private String description;
	
	@Column(name="quantity")
	private Long quantity;
	
	@Column(name="unit",nullable = false)
	private Long unit;
	
	@Column(name="quotation_approved")
	private Boolean quotationApproved=false;
	
	@Transient
	@JsonProperty
	private String skuCode;

	@Transient
	@JsonProperty
	private Long itemId;

	@Transient
	@JsonProperty
	private Long productId;

	@Transient
	@JsonProperty
	private Long classificationId;

	@Transient
	@JsonProperty
	private String itemCode;

	@Transient
	@JsonProperty
	private String productCode;

	@Transient
	@JsonProperty
	private String classificationCode;

	@Transient
	@JsonProperty
	private Long variantTypeId;

	@Transient
	@JsonProperty
	private String variantTypeCode;

	@Transient
	@JsonProperty
	private String itemName;

	@Transient
	@JsonProperty
	private String classificationName;

	@Transient
	@JsonProperty
	private String productName;

	@Transient
	@JsonProperty
	private String variantTypeName;
	
	
    
}

