package com.nalamfarms.inventory_service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrder;

@Repository
public interface InventoryMasterPurchaseOrderRepository extends JpaRepository<InventoryMasterPurchaseOrder, Long>,JpaSpecificationExecutor<InventoryMasterPurchaseOrder>{

	List<InventoryMasterPurchaseOrder> findByDemandIdIn(List<Long> demandIds);

	Optional<InventoryMasterPurchaseOrder> findByDemandIdAndVendorId(Long demandId, Long vendorId);

}
