package com.nalamfarms.inventory_service.dto;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponseDto {

	private String errorMessage;

	private LocalDateTime timeStamp;

	private HttpStatus httpStatus;

	private String errorPath;

}
