package com.nalamfarms.inventory_service.entity;


public enum PurchaseShippingStatus {
	 AWAITING_SHIPMENT,
	    SHIPPED,
	    IN_TRANSIT,
	    OUT_FOR_DELIVERY,
	    DELIVERED,
	    DELAYED,
	    FAILED_ATTEMPT,
	    RETURNED_TO_SENDER,
	    CANCELLED,
	    LOST_IN_TRANSIT
	}