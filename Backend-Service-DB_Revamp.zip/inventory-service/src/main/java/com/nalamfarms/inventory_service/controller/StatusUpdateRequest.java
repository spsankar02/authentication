package com.nalamfarms.inventory_service.controller;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StatusUpdateRequest {
  private Long statusId;
  private Long vendorSkuId;
}
