package com.nalamfarms.inventory_service.repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nalamfarms.inventory_service.entity.InventoryMasterPurchaseOrderInvoice;

@Repository
public interface InventoryMasterPurchaseOrderInvoiceRepo extends JpaRepository<InventoryMasterPurchaseOrderInvoice,Long> {

    Page<InventoryMasterPurchaseOrderInvoice> findBydemandIdIn(List<Long> demandId, Pageable pageable);

	Optional<InventoryMasterPurchaseOrderInvoice> findBydemandIdAndVendorIdAndPurchaseOrderId(Long demandId, Long vendorId, Long purchaseOrderId);

	@Query("""
		    SELECT COUNT(DISTINCT i.purchaseOrderId, i.demandId,i.invoiceId)
		    FROM InventoryMasterPurchaseOrderInvoice i
		    WHERE i.vendorId = :vendorId
		""")
	Long countInvoiceDemandPerVendorId(Long vendorId);

	List<InventoryMasterPurchaseOrderInvoice> findAllByVendorId(Long vendorIds);

	List<InventoryMasterPurchaseOrderInvoice> findByDemandIdInAndVendorId(List<Long> demandIds, Long vendorIds);

    @Query("SELECT SUM(i.grandTotal) FROM InventoryMasterPurchaseOrderInvoice i")
	BigDecimal findTotalAmount();
    
    @Query("SELECT SUM(i.grandTotal) FROM InventoryMasterPurchaseOrderInvoice i WHERE i.invoiceStatusId = 6")
    BigDecimal findPaidAmount();

    @Query("SELECT SUM(i.grandTotal) FROM InventoryMasterPurchaseOrderInvoice i WHERE i.invoiceStatusId = 2")
    BigDecimal findUnpaidAmount();

    @Query("SELECT SUM(i.grandTotal) FROM InventoryMasterPurchaseOrderInvoice i WHERE i.invoiceDate < :today AND i.invoiceStatusId = 2")
    BigDecimal findTotalDueAmount(LocalDate today);

}
