package com.nalamfarms.inventory_service.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class DemandItemDto {
   private Long skuId;
   private BigDecimal quantity;
}
