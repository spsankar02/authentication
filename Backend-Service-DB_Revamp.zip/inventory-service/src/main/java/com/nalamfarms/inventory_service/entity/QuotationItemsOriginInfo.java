package com.nalamfarms.inventory_service.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "inventory_mapping_quotation_items_origininfo", schema = "public")
@Data
public class QuotationItemsOriginInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "items_origininfo_id", nullable = false)
    private Long itemsOriginInfoId;

    @Column(name = "city", nullable = false)
    private String city;

    @Column(name = "state", nullable = false)
    private String state;

    @Column(name = "country", nullable = false)
    private String country;

    @Column(name = "description", nullable = false, columnDefinition = "text")
    private String description;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt=LocalDateTime.now();

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt=LocalDateTime.now();

    @Column(name = "created_by", nullable = false)
    private Long createdBy=1l;

    @Column(name = "modified_by")
    private Long modifiedBy=1l;
    
//    @ManyToOne(fetch=FetchType.LAZY)
//	@JoinColumn(name="quotation_id",insertable = false, updatable = false)
//    @JsonIgnore
//	private TxnInventoryQuotation inventoryQuotation;
//    
//    
//    @Column(name="quotation_id")
//    private Long quotationId;
//    

    

   
}