//package resolver;
//import dto.UpdateStockRequest;
////import entity.Inventory;
//import service.InventoryService;
//import graphql.kickstart.tools.GraphQLMutationResolver;
//import graphql.kickstart.tools.GraphQLQueryResolver;
//import org.springframework.stereotype.Component;
//
//@Component
//public class InventoryResolver implements GraphQLQueryResolver, GraphQLMutationResolver {
//    private final InventoryService inventoryService;
//
//    public InventoryResolver(InventoryService inventoryService) {
//        this.inventoryService = inventoryService;
//    }
////
////    public Inventory inventory(Long productId) {
////        return inventoryService.getInventory(productId);
////    }
//
////    public Inventory updateStock(Long productId, Integer quantity) {
////        return inventoryService.updateStock(new UpdateStockRequest(productId, quantity));
////    }
//}
