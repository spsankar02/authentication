package com.nalamfarms.logistic_service.dto;

import com.nalamfarms.logistic_service.entity.ShippingStatus;
import jakarta.persistence.Column;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@RequiredArgsConstructor
public class ShippingDetailsDto {

  private Long orderId;

  private Long shippingAddressId;
  
  private String deliveryAgentType;
  
  private Long deliveryAgentTypeId;

  private String shippingMethod;

  private String carrierName;

  private Integer  shippingCost;

  private Long orderStatusId;

  private String remarks;
}
