package com.nalamfarms.logistic_service.exception;

import java.io.Serial;


import lombok.Getter;

@Getter
public class GraphQLServiceException extends RuntimeException {


	@Serial
	private static final long serialVersionUID = 1L;

	public GraphQLServiceException(String message) {
		super(message);

	}

	public GraphQLServiceException(String message, Throwable cause) {
		super(message,cause);

	}

}