package com.nalamfarms.logistic_service.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Data;

@Data
@Entity
@Table(name = "shipment_txn_activity_tracking",
schema = "public",
uniqueConstraints = {
    @UniqueConstraint(
        name = "uq_shipment_status",
        columnNames = {"shipment_id", "shipment_status_id"}
    )
})
public class ShipmentActivityTracking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "activity_tracking_id")
    private Long activityTrackingId;

    @Column(name = "shipment_id", nullable = false)
    private Long shipmentId;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "created_by")
    private Long createdBy=1l;

    @Column(name = "modified_by")
    private Long modifiedBy=1l;

    @Column(name = "created_at")
    private LocalDateTime createdAt=LocalDateTime.now();

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt=LocalDateTime.now();

    @Column(name = "shipment_status_id")
    private Long shipmentStatusId;

    @Column(name = "shipment_driver_id")
    private Long shipmentDriverId;

    @Column(name = "shipment_vehicle_id")
    private Long shipmentVehicleId; 
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipment_status_id",insertable = false,updatable = false)
    private ShippingStatus shippingStatus;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipment_id",insertable = false,updatable = false)
    @JsonIgnore
    private Shipping shipping;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipment_driver_id",insertable = false,updatable = false)
    private ShipmentMasterDrivers drivers;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipment_vehicle_id",insertable = false,updatable = false)
    private ShipmentMasterDeliveryVehicle vehicle;
    
    
    @Column(name="shipment_image_path")
    private String shipmentImagePath;
    
   
    
    
    
    
}
