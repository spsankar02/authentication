package com.nalamfarms.logistic_service.dto;

import lombok.Data;

@Data
public class StatusUpdateRequestDTO {
	private Long id;
    private Boolean isActive;

}
