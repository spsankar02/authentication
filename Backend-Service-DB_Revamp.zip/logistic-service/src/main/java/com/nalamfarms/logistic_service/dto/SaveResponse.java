package com.nalamfarms.logistic_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveResponse {
	//private Long pendingShipmentCount;
    private Long totalShipmentCount;
    private Long locationCount;
    private Long outForDeliveryCount;
    private Long deliveredCount;
   // private Long inTransitCount;
    private Long awaitingShipmentCount;
    private Long failedAttemptCount;

	    
}
