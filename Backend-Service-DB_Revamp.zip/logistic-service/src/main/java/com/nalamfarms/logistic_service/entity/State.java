package com.nalamfarms.logistic_service.entity;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "master_state")
public class State {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "state_id")
  private Long stateId;

  @Column(name = "state_name")
  private String stateName;

  @ManyToOne
  @JoinColumn(name = "country_id")
  private Country countryId;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @Column(name = "is_active")
  private Boolean isActive;
}
