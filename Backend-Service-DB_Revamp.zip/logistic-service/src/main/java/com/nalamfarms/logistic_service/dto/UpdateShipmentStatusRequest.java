package com.nalamfarms.logistic_service.dto;

import com.nalamfarms.logistic_service.entity.ShippingStatus;
import lombok.Data;
import lombok.RequiredArgsConstructor;


@Data
@RequiredArgsConstructor
public class UpdateShipmentStatusRequest{
    private Long orderId;
    private Long shippingStatusId;
    private String trackingNumber;

    }

