package com.nalamfarms.logistic_service.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "shipment_history_shipping_status")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HistoryShippingStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "history_shipping_status_id")
    private Long historyShippingStatusId;

    @ManyToOne
    @JoinColumn(name = "shipping_id", nullable = false)
    private Shipping shipping;

    @ManyToOne
    @JoinColumn(name = "old_status")
    private ShippingStatus oldStatus;

    @ManyToOne
    @JoinColumn(name = "new_status", nullable = false)
    private ShippingStatus newStatus;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    @Column(name = "updated_by")
    private Long updatedBy;

    @Column(name = "order_id")
    private Long orderId;

    @Column(name = "shipping_address_id")
    private Long shippingAddressId;

    @Column(name = "shipping_method")
    private String shippingMethod;

    @Column(name = "tracking_number")
    private String trackingNumber;

    @Column(name = "carrier_name")
    private String carrierName;

    @Column(name = "estimated_delivery")
    private LocalDate estimatedDelivery;

    @Column(name = "shipped_date")
    private LocalDateTime shippedDate;

    @Column(name = "delivered_date")
    private LocalDate deliveredDate;

    @Column(name = "shipping_cost")
    private Double shippingCost;

    @Column(name = "return_status")
    private Boolean returnStatus;

    @Column(name = "remarks")
    private String remarks;
}