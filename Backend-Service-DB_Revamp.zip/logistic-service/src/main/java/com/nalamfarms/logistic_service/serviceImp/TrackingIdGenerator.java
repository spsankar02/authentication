package com.nalamfarms.logistic_service.serviceImp;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.springframework.stereotype.Component;

@Component
public class TrackingIdGenerator {

    private static final String PREFIX = "TRK";
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss");

    public static String generateTrackingId() {
        String timestamp = LocalDateTime.now().format(FORMATTER);
        String randomSuffix = UUID.randomUUID()
                                  .toString()
                                  .replaceAll("-", "")
                                  .substring(0, 6)
                                  .toUpperCase();
        return String.format("%s-%s-%s", PREFIX, timestamp, randomSuffix);
    }

    public static void main(String[] args) {
        System.out.println(generateTrackingId());
    }
}
