package com.nalamfarms.logistic_service.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.nalamfarms.logistic_service.entity.Shipping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

@Repository
public interface ShippingRepository extends JpaRepository<Shipping, Long>,JpaSpecificationExecutor<Shipping> {
	List<Shipping> findByOrderId(Long orderId);
  Shipping findByOrderIdAndTrackingNumber(Long orderId, String trackingNumber);
List<Shipping> findByShippingId(Integer shippingId);
Long countByShippingStatusId(Long statusId);
}
