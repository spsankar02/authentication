package com.nalamfarms.logistic_service.serviceImp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.nalamfarms.logistic_service.dto.ShipmentDateType;
import com.nalamfarms.logistic_service.entity.Shipping;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;

public class ShipmentSpecification {
	
	public static Specification<Shipping> hasShipmentDate(LocalDateTime shipmentDate) {
        return (root, query, cb) -> {
            if (shipmentDate == null) {
                return cb.conjunction(); 
            }
            return cb.equal(root.get("shippedDate"), shipmentDate);
        };
    }
	
	public static Specification<Shipping> hasShipmentLocation(String location) {
	    return (root, query, cb) -> {
	        if (location == null || location.isBlank()) {
	            return cb.conjunction(); 
	        }

	        Join<Object, Object> shipmentTrackingJoin = root.join("shipmentTracking", JoinType.INNER); 

	        return cb.equal(shipmentTrackingJoin.get("location"), location);
	    };
	}
	
	public static Specification<Shipping> hasShipmentDateBetween(LocalDateTime from, LocalDateTime to) {
        return (root, query, builder) ->
                builder.between(root.get("shippedDate"), from, to);
    }

    public static Specification<Shipping> hasShipmentDateBefore(LocalDateTime to) {
        return (root, query, builder) ->
                builder.lessThan(root.get("shippedDate"), to);
    }
    
    public static Specification<Shipping> hasShipmentDateTypes(List<ShipmentDateType> dateTypes) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            LocalDate today = LocalDate.now();

            for (ShipmentDateType type : dateTypes) {
                switch (type) {
                    case TODAY:
                        predicates.add(cb.between(root.get("shippedDate"),
                                today.atStartOfDay(), today.plusDays(1).atStartOfDay()));
                        break;
                    case YESTERDAY:
                        predicates.add(cb.between(root.get("shippedDate"),
                                today.minusDays(1).atStartOfDay(), today.atStartOfDay()));
                        break;
                    case OLD:
                        predicates.add(cb.lessThan(root.get("shippedDate"),
                                today.minusDays(1).atStartOfDay()));
                        break;
                    case ALL:
                        return cb.conjunction();
                }
            }

            return cb.or(predicates.toArray(new Predicate[0]));
        };
    }

    public static Specification<Shipping> hasShipmentLocation(List<String> locations) {
        return (root, query, cb) -> {
        	   boolean containsAll = locations != null && locations.stream()
        	            .anyMatch(loc -> "ALL".equalsIgnoreCase(loc));

            if (locations == null || locations.isEmpty()|| locations.stream().anyMatch(loc -> "ALL".equalsIgnoreCase(loc))) {
                return cb.conjunction(); 
            }

            query.distinct(true);

            Join<Object, Object> shipmentTrackingJoin = root.join("shipmentTracking", JoinType.INNER);

            return shipmentTrackingJoin.get("pinCode").in(locations);
        };
    }
    
    public static Specification<Shipping> shipmentIdIn(List<Integer> shipmentIds) {
        return (root, query, cb) -> shipmentIds == null || shipmentIds.isEmpty()
                ? cb.conjunction()
                : root.get("shippingId").in(shipmentIds);
    }

    public static Specification<Shipping> shippedDateAfter(String startDateStr) {
        return (root, query, cb) -> {
            if (startDateStr == null || startDateStr.isBlank()) return cb.conjunction();
            LocalDateTime startDateTime = LocalDate.parse(startDateStr.trim()).atStartOfDay();
            return cb.greaterThanOrEqualTo(root.get("shippedDate"), startDateTime);
        };
    }

    public static Specification<Shipping> shippedDateBefore(String endDateStr) {
        return (root, query, cb) -> {
            if (endDateStr == null || endDateStr.isBlank()) return cb.conjunction();
            LocalDateTime endDateTime = LocalDate.parse(endDateStr.trim()).atTime(LocalTime.MAX);
            return cb.lessThanOrEqualTo(root.get("shippedDate"), endDateTime);
        };
    }

    public static Specification<Shipping> categoryIn(List<Long> categoryIds) {
        return (root, query, cb) -> categoryIds == null || categoryIds.isEmpty()
                ? cb.conjunction()
                : root.get("shippingStatusId").in(categoryIds);
    }

    public static Specification<Shipping> locationIn(List<String> pincodes) {
        return (root, query, cb) -> {
            if (pincodes == null || pincodes.isEmpty()) {
                return cb.conjunction(); 
            }

            Join<Object, Object> memberAddressJoin = root.join("memberAddress", JoinType.INNER);

            return memberAddressJoin.get("pincode").in(pincodes);
        };
    }
    
}
