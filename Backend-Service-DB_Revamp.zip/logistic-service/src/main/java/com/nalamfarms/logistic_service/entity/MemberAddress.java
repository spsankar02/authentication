package com.nalamfarms.logistic_service.entity;


import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "member_mapping_address")
public class MemberAddress {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "member_address_id")
  private Long memberAddressId;

//  @ManyToOne
//  @JoinColumn(name = "member_id")
//  private Member memberId;

  @Column(name = "flat_houseno_building")
  private String flatHouseNoBuilding;

  @Column(name = "area_sector_locality")
  private String areaSectorLocality;

  @Column(name = "nearby_landmark")
  private String nearbyLandmark;

  @Column(name = "address_type")
  private String addressType;

  @ManyToOne
  @JoinColumn(name = "country_id")
  private Country countryId;

  @ManyToOne
  @JoinColumn(name = "state_id")
  private State stateId;

//  @ManyToOne
//  @JoinColumn(name = "city_id")
//  private City cityId;

  @Column(name = "pincode")
  private String pincode;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @Column(name = "modified_at")
  private LocalDateTime modifiedAt;

  @Column(name = "is_active")
  private Boolean isActive;

  @Column(name = "is_default")
  private Boolean isDefault;
  
  @Column(name = "member_name")
  private String memberName;
  
  @Column(name = "phone_number")
  private String phoneNumber;
  
  @Column(name="addressline1")
  private String addressLine1;
  
  @Column(name="addressline2")
  private String addressLine2;
  
  @Column(name="raw_address")
  private String rawAddress;

  @Column(name="city_name")
  private String cityName;

}
