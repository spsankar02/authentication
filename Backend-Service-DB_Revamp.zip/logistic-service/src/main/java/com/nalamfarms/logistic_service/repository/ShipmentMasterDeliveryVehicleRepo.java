package com.nalamfarms.logistic_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryVehicle;

public interface ShipmentMasterDeliveryVehicleRepo extends JpaRepository<ShipmentMasterDeliveryVehicle, Long> {

}
