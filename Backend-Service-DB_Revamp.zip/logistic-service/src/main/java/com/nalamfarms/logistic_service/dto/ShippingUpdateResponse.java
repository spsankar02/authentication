package com.nalamfarms.logistic_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShippingUpdateResponse {
	private String status;       
    private String message;      
    private Long shippingId;    
    private Long updatedStatusId;
}
