package com.nalamfarms.logistic_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.logistic_service.entity.ShipmentActivityTracking;

@Repository
public interface ShippingActivityRepository extends JpaRepository<ShipmentActivityTracking, Long>{

	ShipmentActivityTracking findByShipmentIdAndShipmentStatusId(Long shippingStatusId, long shipmentStatus);

}
