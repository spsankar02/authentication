package com.nalamfarms.logistic_service.repository;

import com.nalamfarms.logistic_service.entity.ShipmentMasterDrivers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShipmentMasterDriversRepository extends JpaRepository<ShipmentMasterDrivers, Long> {


}
