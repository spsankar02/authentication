package com.nalamfarms.logistic_service.dto;

import java.util.List;

import com.nalamfarms.logistic_service.entity.Shipping;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class ShippingResponse {
	  private List<Shipping> data;
	    private String message;
	    private Boolean success;

}
