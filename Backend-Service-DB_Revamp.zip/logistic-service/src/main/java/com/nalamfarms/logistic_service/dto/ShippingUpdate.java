package com.nalamfarms.logistic_service.dto;

import lombok.Data;

@Data
public class ShippingUpdate {
    private Long orderId;
    private Long shippingStatusId;
    private Long shippingId;
    private Long shipmentDriverId;
    private Long shipmentVechileId;
    private String remarks;
    private String shippingImagePath;

}
