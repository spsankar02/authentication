package com.nalamfarms.logistic_service.entity;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "shipment_txn_shipment_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Shipping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "shipping_id")
    private Integer shippingId;
    
    @Column(name = "order_id", nullable = false)
    private Long orderId;

    @Column(name = "shipping_address_id", nullable = false)
    private Long shippingAddressId;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "shipping_address_id", nullable = false, insertable = false, updatable = false)
    private MemberAddress memberAddress;

    @Column(name = "shipping_method")
    private String shippingMethod;

    @Column(name = "tracking_number")
    private String trackingNumber;

    @Column(name = "carrier_name")
    private String carrierName;

    @Column(name = "estimated_delivery")
    private LocalDate estimatedDelivery;

    @Column(name = "shipped_date")
    private LocalDateTime shippedDate;

    @Column(name = "delivered_date")
    private LocalDate deliveredDate;

    @Column(name = "created_at")
    private LocalDate createdAt=LocalDate.now();

    @Column(name = "modified_at")
    private LocalDate modifiedAt=LocalDate.now();

    @Column(name = "created_by")
    private Long createdBy=1l;

    @Column(name = "modified_by")
    private Long modifiedBy=1l;

    @Column(name = "shipping_cost")
    private Integer shippingCost;
    
    @Column(name = "delivery_agent_type", length = 30)
    private String deliveryAgentType; // "NALAM" or "THIRD_PARTY"

    
    @Column(name = "third_party_agent_id")
    private Long thirdPartyAgentId; 

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "third_party_agent_id", referencedColumnName = "agent_id", insertable = false, updatable = false)
    private ThirdPartyDeliveryAgent thirdPartyAgent;

    @Column(name = "return_status")
    private Boolean returnStatus;

    @Column(name = "remarks", columnDefinition = "text")
    private String remarks;

    @Column(name = "shipping_status_id", insertable = false, updatable = false)
    private Long shippingStatusId;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "shipping_status_id", foreignKey = @ForeignKey(name = "Shipping_Status_id_Fk"))
    private ShippingStatus shipmentStatus;
    
    @OneToMany(fetch=FetchType.EAGER,mappedBy = "shipping",cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ShipmentTracking> shipmentTracking=new ArrayList<>();
    
    @OneToMany(fetch=FetchType.EAGER,mappedBy ="shipping",cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ShipmentActivityTracking>shipmentActivityTracking=new ArrayList<>();
    
}
