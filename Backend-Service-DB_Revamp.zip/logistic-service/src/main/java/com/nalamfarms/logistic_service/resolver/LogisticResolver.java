//package com.nalamfarms.logistic_service.resolver;
//import com.nalamfarms.logistic_service.dto.UpdateShipmentStatusRequest;
//import entity.Shipment;
//import com.nalamfarms.logistic_service.service.LogisticService;
//import graphql.kickstart.tools.GraphQLMutationResolver;
//import graphql.kickstart.tools.GraphQLQueryResolver;
//import org.springframework.stereotype.Component;
//
//@Component
//public class LogisticResolver implements GraphQLQueryResolver, GraphQLMutationResolver {
////    private final LogisticService logisticService;
////
////    public LogisticResolver(LogisticService logisticService) {
////        this.logisticService = logisticService;
////    }
////
////    public Shipment shipment(Long orderId) {
////        return logisticService.getShipment(orderId);
////    }
////
////    public Shipment createShipment(Long orderId) {
////        return logisticService.createShipment(orderId);
////    }
////
////    public Shipment updateShipmentStatus(Long orderId, String status, String trackingNumber) {
////        return logisticService.updateShipmentStatus(new UpdateShipmentStatusRequest(orderId, status, trackingNumber));
////    }
//}
