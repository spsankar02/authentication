package com.nalamfarms.logistic_service.serviceImp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.nalamfarms.logistic_service.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import com.nalamfarms.logistic_service.dto.NotificationDto;
import com.nalamfarms.logistic_service.dto.SaveResponse;
import com.nalamfarms.logistic_service.dto.ShipmentDateType;
import com.nalamfarms.logistic_service.dto.ShippingDetailsDto;
import com.nalamfarms.logistic_service.dto.ShippingResponse;
import com.nalamfarms.logistic_service.dto.ShippingUpdate;
import com.nalamfarms.logistic_service.dto.ShippingUpdateResponse;
import com.nalamfarms.logistic_service.dto.StatusUpdateRequestDTO;
import com.nalamfarms.logistic_service.dto.StatusUpdateResponse;
import com.nalamfarms.logistic_service.dto.UpdateShipmentStatusRequest;
import com.nalamfarms.logistic_service.entity.HistoryShippingStatus;

import com.nalamfarms.logistic_service.entity.ShipmentActivityTracking;
import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryZone;
import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryAgent;
import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryVehicle;
import com.nalamfarms.logistic_service.entity.ShipmentMasterDrivers;
import com.nalamfarms.logistic_service.entity.ShipmentWorkflowStep;
import com.nalamfarms.logistic_service.entity.Shipping;
import com.nalamfarms.logistic_service.entity.ShippingStatus;
import com.nalamfarms.logistic_service.entity.ThirdPartyDeliveryAgent;
import com.nalamfarms.logistic_service.exception.GraphQLServiceException;
import com.nalamfarms.logistic_service.service.LogisticService;
import com.nalamfarms.logistic_service.util.ResponseContent;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LogisticServiceImp implements LogisticService {
  private final ShippingStatusRepository shippingStatusRepository;
  private final TrackingIdGenerator trackingIdGenerator;
  private final ShippingRepository shippingRepository;
  private final HistoryShippingStatusRepository historyShippingStatusRepository;
  private final ShipMentMasterDeliveryZoneRepository shipMentMasterDeliveryZoneRepository;
  private final ShipmentMasterDriversRepository shipmentMasterDriversRepository;
  private final ShipmentMasterDeliveryVehicleRepo shipmentMasterDeliveryVehicleRepo;
  private final ShipmentMasterDeliveryAgentRepo shipmentMasterDeliveryAgentRepo;
  private final ShipmentMasterDriversRepository ShipmentMasterDriversRepo;
  private final ShippingActivityRepository shippingActivityRepository;
  private final ShipmentWorkflowStepRepository workFlowStepsRepository;
  private final ShipmentMasterDeliveryZonesRepo shipmentMasterDeliveryZonesRepo;
  private final ThirdPartyDeliveryAgentRepository deliveryAgentRepository;
  private static final Logger log = LoggerFactory.getLogger(LogisticServiceImp.class);


  @Value("${notificationservice.url}")
  private String notificationServiceUrl;

  @Value("${orderservice.url}")
  private String orderServiceUrl;

  public ResponseEntity<Map<String, Object>> createErrorResponse(String message, Object data) {
	    log.warn("Error Response: {} - Data: {}", message, data);
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response(message, data, true));
  }

  public ResponseEntity<Map<String, Object>> createSuccessResponse(String message, Object data) {
	    log.info("Success Response: {} - Data: {}", message, data);
    return ResponseEntity.status(HttpStatus.OK).body(response(message, data, true));
  }

  private Map<String, Object> response(String message, Object data, Boolean status) {
    Map<String, Object> response = new HashMap<>();
    response.put("message", message);
    response.put("data", data);
    response.put("status", status);
    return response;
  }
  @Override
  public List<ShippingStatus> getAllShipmentStatus() {
	  log.info("Fetching all shipment statuses");

    List<ShippingStatus> results = shippingStatusRepository.findAllByIsActiveTrue();
    log.info("Fetched {} shipment status records", results.size());
    return results;
  }

  @Transactional
  @Override
	public ResponseEntity<Map<String, Object>> addOrderInShipment(ShippingDetailsDto request) {
		if (request != null && request.getOrderStatusId()==11) {
			log.info("Received addOrderInShipment request: {}", request);
			Shipping shipping = new Shipping();
			shipping.setOrderId(request.getOrderId());
			shipping.setShippingAddressId(request.getShippingAddressId());
			shipping.setShippingMethod(null);
			shipping.setShippingCost(0);
			shipping.setRemarks(request.getRemarks());
			shipping.setCarrierName(null);
			shipping.setDeliveryAgentType(request.getDeliveryAgentType());
			shipping.setThirdPartyAgentId(request.getDeliveryAgentTypeId()!=null?request.getDeliveryAgentTypeId():null);
			shipping.setShippingStatusId(1l);
			shipping.setTrackingNumber(trackingIdGenerator.generateTrackingId());
			shipping.setShippedDate(LocalDateTime.now());
			shipping.setEstimatedDelivery(shipping.getShippedDate().plusDays(3).toLocalDate());
			shipping.setReturnStatus(false);
			ShippingStatus shippingStatus = shippingStatusRepository.findByShippingStatusId(1l);
		    shipping.setShipmentStatus(shippingStatus);
			Shipping shippings = shippingRepository.save(shipping);
			log.info("Saved shipping record with TrackingNumber: {}", shippings.getTrackingNumber());
			if (shippings.getShippingStatusId() == 2) {
				NotificationDto notification = new NotificationDto();
				notification.setOrderId(shippings.getOrderId().toString());
				notification.setNotificationType(ResponseContent.ORDER_SHIPPED_STATUS);
				Long memberId = getMemberId(shippings.getOrderId());
				notification.setMemberId(memberId);
				log.info("Sending shipment notification for orderId: {}, memberId: {}", shippings.getOrderId(),
						memberId);

				sendNotification(notification);
			}
			return createSuccessResponse(ResponseContent.SHIPMENT_ADDED_MESSAGE,"");
		} else {
			return createErrorResponse(ResponseContent.SHIPMENT_INVALID_REQUEST_EXCEPTION, "");
		}

	}

  @Override
  public ResponseEntity<Map<String, Object>> updateShipmentStatus(UpdateShipmentStatusRequest request){
	log.info("Updating shipment status for orderId: {}, trackingNumber: {}", request.getOrderId(), request.getTrackingNumber());
    Shipping shipping = shippingRepository.findByOrderIdAndTrackingNumber(request.getOrderId(),request.getTrackingNumber());
    if(shipping!=null){
      ShippingStatus shippingStatus = shippingStatusRepository.findByShippingStatusId(request.getShippingStatusId());
      shipping.setShippingStatusId(shippingStatus.getShippingStatusId());
      shippingRepository.save(shipping);
      ShippingStatus oldStatus = shippingStatusRepository.findByShippingStatusId(shipping.getShippingStatusId());
      saveShippingStatusHistory(shipping, oldStatus, shippingStatus);
      log.info("Shipping status updated successfully for orderId: {}, trackingNumber: {}", request.getOrderId(), request.getTrackingNumber());
      return createSuccessResponse(ResponseContent.SHIPMENT_UPDATED_MESSAGE,"");

    }
    log.warn("No shipping found for orderId: {}, trackingNumber: {}", request.getOrderId(), request.getTrackingNumber());
    return createErrorResponse(ResponseContent.INVALID_ORDERID_ERRORMESSAGE,"");

  }
  
  public void saveShippingStatusHistory(Shipping shipping, ShippingStatus oldStatus, ShippingStatus newStatus) {
	  HistoryShippingStatus history = new HistoryShippingStatus();

	    history.setShipping(shipping);
	    history.setOldStatus(oldStatus);
	    history.setNewStatus(newStatus);
	    history.setUpdatedAt(LocalDateTime.now());
	    history.setUpdatedBy(null);
	    history.setOrderId(shipping.getOrderId());
	    history.setShippingAddressId(shipping.getShippingAddressId());
	    history.setShippingMethod(shipping.getShippingMethod());
	    history.setTrackingNumber(shipping.getTrackingNumber());
	    history.setCarrierName(shipping.getCarrierName());
	    history.setEstimatedDelivery(shipping.getEstimatedDelivery());
	    history.setShippedDate(shipping.getShippedDate());
	    history.setDeliveredDate(shipping.getDeliveredDate());
	    history.setShippingCost(shipping.getShippingCost().doubleValue());
	    history.setReturnStatus(shipping.getReturnStatus());
	    history.setRemarks(shipping.getRemarks());

	    historyShippingStatusRepository.save(history);
	    log.info("Saved shipping status history for orderId: {}, trackingNumber: {}", shipping.getOrderId(), shipping.getTrackingNumber());

	}


  public ShippingResponse getShippingDetailsById(Long orderId) {
	    try {
	    	if(orderId!=0 && orderId!=null) {
	        List<Shipping> shippingList = shippingRepository.findByOrderId(orderId);
	        log.info("Fetching shipping details for orderId: {}", orderId);
	        if (shippingList == null || shippingList.isEmpty()) {
	            log.warn("No shipping data found for orderId: {}", orderId);
	            return new ShippingResponse(null, ResponseContent.SHIPMENT_DATA_NOTFOUND_ERRORMESSAGE + orderId, false);
	        }
	        log.info("Found {} shipping records for orderId: {}", shippingList.size(), orderId);
	        return new ShippingResponse(shippingList,ResponseContent.SUCCESS , true);
	    }else { 
	        List<Shipping> shippingList = shippingRepository.findAll();
	        return new ShippingResponse(shippingList,ResponseContent.SUCCESS , true);
	    }
	    }catch (Exception e) {
	        log.error("Error fetching shipping details for orderId: {}", orderId, e);
	        return new ShippingResponse(null, ResponseContent.SHIPMENT_FETCH_ERRORMESSAGE + e.getMessage(), false);
	    }
	}
  public void sendNotification(NotificationDto notification) {
	  log.info("Sending notification: {}", notification);
	    WebClient webClient = WebClient.create(notificationServiceUrl);
	    try {
	      webClient.post()
	          .uri("/api/notification/sendNotification")
	          .bodyValue(notification)
	          .retrieve()
	          .bodyToMono(NotificationDto.class)
	          .block();
	      log.info("Notification sent successfully");
	    } catch (Exception e) {
	      log.error("Failed to send notification: {}", notification, e);
	    }
  }

  public Long getMemberId(Long orderId) {
	  log.info("Fetching memberId for orderId: {}", orderId);
	    WebClient webClient = WebClient.create(orderServiceUrl);
	    try {
	      Long memberId = webClient.post()
	          .uri(uriBuilder -> uriBuilder
	              .path("/api/orders/getMemberIdByOrder")
	              .queryParam("orderId", orderId)
	              .build())
	          .retrieve()
	          .bodyToMono(Long.class)
	          .block();
	      log.info("Retrieved memberId: {} for orderId: {}", memberId, orderId);
	      return memberId;
	    } catch (Exception e) {
	      log.error("Error retrieving memberId for orderId: {}", orderId, e);
	      return null;
	    }
  }


  public ResponseEntity<String> shippingStatusUpdate(ShippingUpdate shippingUpdate) {
    List<Shipping> shippingList = shippingRepository.findByOrderId(shippingUpdate.getOrderId());
    log.info("Bulk updating shipping status for orderId: {}", shippingUpdate.getOrderId());
    if (shippingList.isEmpty()) {
      return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ResponseContent.SHIPMENT_DATA_NOTFOUND_ERRORMESSAGE);
    }

    ShippingStatus shippingStatus = shippingStatusRepository.findByShippingStatusId(shippingUpdate.getShippingStatusId());

    if (shippingStatus == null) {
        log.warn("Invalid shipping status ID: {}", shippingUpdate.getShippingStatusId());
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResponseContent.INVALID_SHIPPING_STATUS);
    }

    for (Shipping shipment : shippingList) {
      shipment.setShippingStatusId(shippingStatus.getShippingStatusId());
      shippingRepository.save(shipment);
      log.debug("Updated shipping status for shipment with trackingNumber: {}", shipment.getTrackingNumber());

    }
    log.info("Shipping status updated successfully for all shipments of orderId: {}", shippingUpdate.getOrderId());
    return ResponseEntity.ok(ResponseContent.SHIPMENT_UPDATED_MESSAGE);
  }

  @Override
  public ShipmentMasterDeliveryZone getPincodeDetails(String pinCode) {
      return shipMentMasterDeliveryZoneRepository.findByPinCode(pinCode)
              .orElseThrow(() -> new GraphQLServiceException(ResponseContent.PINCODE_NOTFOUND + pinCode));
  }
  @Override
  public PincodeResponse getPincodeAvailableDetails(String pinCode) {
      try {
          Optional<ShipmentMasterDeliveryZone> zoneOpt = shipMentMasterDeliveryZoneRepository.findByPinCode(pinCode);

          if (zoneOpt.isEmpty()) {
              return new PincodeResponse(false, ResponseContent.PINCODE_NOT_APPLICABLE);
          }

          ShipmentMasterDeliveryZone zone = zoneOpt.get();
          Boolean isAvailable = zone.getIsActive() != null ? zone.getIsActive() : false;

          return new PincodeResponse(isAvailable, ResponseContent.PINCODE_SERVICEABLE);
      } catch (Exception ex) {
          // Log the actual error
          ex.printStackTrace(); // Or use a logger
          throw new GraphQLServiceException(ResponseContent.PINCODE_FETCH_ERRORMESSAGE, ex);
      }
  }


	@Override
	public List<ShipmentMasterDeliveryVehicle> getmasterDeliveryVehicle() {
		log.info("Fetching all shipment statuses");
		List<ShipmentMasterDeliveryVehicle> details=shipmentMasterDeliveryVehicleRepo.findAll();
		return details;
	}

    @Override
    public List<ShipmentMasterDrivers> getShipMentMasterDrivers() {

        return  shipmentMasterDriversRepository.findAll();
    }

	@Override
	public List<ShipmentMasterDeliveryAgent> getAllShipmentMasterDeliveryAgent() {
		return shipmentMasterDeliveryAgentRepo.findAll();
	}

	@Override
	public List<Shipping> getShippingDetailsByShippingId(Integer shippingId) {
		if(shippingId !=0) {
			List<Shipping> shippingDetails=shippingRepository.findByShippingId(shippingId);
			return shippingDetails;
		}
			List<Shipping> shippingDetails=shippingRepository.findAll();
		  return shippingDetails;
	}

	

	@Override
	public List<Shipping> filterShipping(List<ShipmentDateType> shipmentDateTypes, List<String> locationAreas) {
		Specification<Shipping> spec = Specification.where(null);

		if (shipmentDateTypes != null && !shipmentDateTypes.isEmpty()) {
			spec = spec.and(ShipmentSpecification.hasShipmentDateTypes(shipmentDateTypes));
		}

		if (locationAreas != null && !locationAreas.isEmpty()) {
			spec = spec.and(ShipmentSpecification.hasShipmentLocation(locationAreas));
		}

		return shippingRepository.findAll(spec);
	}

	@Override
	public List<ShipmentMasterDrivers> getAllShipmentMasterDrivers() {
		return ShipmentMasterDriversRepo.findAll();
	}

	@Override
	public StatusUpdateResponse updateStatus(String entityType, StatusUpdateRequestDTO request) {
		String message;
		switch (entityType.toLowerCase()) {
        case "vehicle":
            updateVehicleStatus(request);
            message = ResponseContent.UPDATE_VEHICLE_MESSAGE;
            break;
        case "driver":
            updateDriverStatus(request);
            message = ResponseContent.UPDATE_DRIVER_MESSAGE;
            break;
        case "shipping":
            updateAgentStatus(request);
            message = ResponseContent.UPDATE_DRIVER_MESSAGE;
            break;
        case "agent":
            updateAgentStatus(request);
            message = ResponseContent.UPDATE_DRIVER_MESSAGE;
            break;
        default:
            throw new IllegalArgumentException(ResponseContent.INVALID_ENTITY_TYPE + entityType);
    }
		return new StatusUpdateResponse(true,ResponseContent.UPDATE_SUCCESS);
	}

	private void updateVehicleStatus(StatusUpdateRequestDTO request) {
		ShipmentMasterDeliveryVehicle vehicle = shipmentMasterDeliveryVehicleRepo.findById(request.getId())
                .orElseThrow(() -> new EntityNotFoundException(ResponseContent.VECHICLE_NOTFOUND));
		vehicle.setActive(request.getIsActive());
		shipmentMasterDeliveryVehicleRepo.save(vehicle);
		
	}
	private void updateDriverStatus(StatusUpdateRequestDTO request) {
		ShipmentMasterDrivers driver = ShipmentMasterDriversRepo.findById(request.getId())
                .orElseThrow(() -> new EntityNotFoundException(ResponseContent.DRIVER_NOTFOUND));
		driver.setActive(request.getIsActive());
		ShipmentMasterDriversRepo.save(driver);
		
	}
	private void updateShipmentStatus(StatusUpdateRequestDTO request) {
		Shipping shipping = shippingRepository.findById(request.getId())
                .orElseThrow(() -> new EntityNotFoundException(ResponseContent.SHIPMENTDETAILS_NOTFOUND));
		shipping.setReturnStatus(request.getIsActive());
		shippingRepository.save(shipping);
		
	}
	private void updateAgentStatus(StatusUpdateRequestDTO request) {
		ShipmentMasterDeliveryAgent agent = shipmentMasterDeliveryAgentRepo.findByAgentId(request.getId());
		agent.setActive(request.getIsActive());
		shipmentMasterDeliveryAgentRepo.save(agent);
		
	}

	//@Override
//	public List<SaveResponse> getShipmentDashboardReport(List<Long> statusIds, String category, Long limit) {
//	    List<Shipping> shipments = shippingRepository.findAll();
//	    Long availableLocationDeliveryZoneCount=shipMentMasterDeliveryZoneRepository.countByIsAvailableTrue();
//	    long totalShipment = shipments.size();
//
//	    List<Shipping> filteredShipments = shipments.stream()
//	        .filter(s -> s.getShipmentStatus() != null)
//	        .filter(s -> {
//	            ShippingStatus status = s.getShipmentStatus();
//	            boolean matchesCategory = (category == null || category.isBlank() ||
//	                                       status.getStatusName().equalsIgnoreCase(category));
//	            boolean matchesId = (statusIds == null || statusIds.isEmpty() ||
//	                                  statusIds.contains(status.getShippingStatusId()));
//	            return matchesCategory && matchesId;
//	        })
//	        .toList();
//
//	    Map<ShippingStatus, Long> statusCountMap = filteredShipments.stream()
//	        .collect(Collectors.groupingBy(
//	            Shipping::getShipmentStatus,
//	            Collectors.counting()
//	        ));
//
//	    Stream<Map.Entry<ShippingStatus, Long>> resultStream = statusCountMap.entrySet().stream()
//	        .sorted(Map.Entry.<ShippingStatus, Long>comparingByValue().reversed());
//
//	    if (limit != null && limit > 0) {
//	        resultStream = resultStream.limit(limit);
//	    }
//
//	    List<SaveResponse> responseList = resultStream
//	        .map(entry -> {
//	            ShippingStatus status = entry.getKey();
//	            Long count = entry.getValue();
//	            return new SaveResponse(status.getShippingStatusId(), status.getStatusName(), count);
//	        })
//	        .collect(Collectors.toList());
//
//	    long pendingShipment = filteredShipments.stream()
//	        .filter(shipment -> shipment.getShipmentStatus() != null
//	            && shipment.getShipmentStatus().getShippingStatusId() == 7)
//	        .count();
//
//	    responseList.add(new SaveResponse(100L, "Pending Shipment", pendingShipment));
//	    responseList.add(new SaveResponse(0L, "Total Shipment", totalShipment));
//	    responseList.add(new SaveResponse(0L, "Location Count", availableLocationDeliveryZoneCount));
//	    return responseList;
//	}


	@Override
	public SaveResponse getShipmentDashboardReport() {
		Long awaitingShipmentCount = shippingRepository.countByShippingStatusId(1l);
		Long totalShipmentCount = shippingRepository.count();
		Long locationCount = shipMentMasterDeliveryZoneRepository.countByIsActiveTrue();
		Long outForDeliveryCount = shippingRepository.countByShippingStatusId(4l);
		Long deliveredCount = shippingRepository.countByShippingStatusId(5l);
		//Long inTransitCount = shippingRepository.countByShippingStatusId(6l);
		Long failedAttemptCount = shippingRepository.countByShippingStatusId(7l);
		//Long pendingShipmentCount = totalShipmentCount - failedAttemptCount;

		SaveResponse saveResponse = new SaveResponse();
		saveResponse.setAwaitingShipmentCount(awaitingShipmentCount);
		saveResponse.setDeliveredCount(deliveredCount);
		saveResponse.setLocationCount(locationCount);
		saveResponse.setTotalShipmentCount(totalShipmentCount);
		saveResponse.setOutForDeliveryCount(outForDeliveryCount);
		saveResponse.setFailedAttemptCount(failedAttemptCount);
		//saveResponse.setInTransitCount(inTransitCount);
		//saveResponse.setPendingShipmentCount(pendingShipmentCount);

		return saveResponse;

	}



	//@Override
//	public List<Shipping> getShipmentBasedOnFilters(String startDateStr, String endDateStr, List<Long> categoryId,List<Integer> shipmentId) {
//	    List<Shipping> allShipments = shippingRepository.findAll();
//
//	    return allShipments.stream()
//	        .filter(s -> {
//	        	 if (shipmentId != null && !shipmentId.isEmpty()) {
//	                 if (s.getShippingId() == null || !shipmentId.contains(s.getShippingId())) {
//	                     return false;
//	                 }
//	             }
//	            if (startDateStr != null && !startDateStr.isBlank()) {
//	                try {
//	                    LocalDateTime startDateTime = LocalDate.parse(startDateStr.trim()).atStartOfDay();
//	                    if (s.getShippedDate() == null || s.getShippedDate().isBefore(startDateTime)) {
//	                        return false;
//	                    }
//	                } catch (DateTimeParseException e) {
//	                    return false;
//	                }
//	            }
//
//	            if (endDateStr != null && !endDateStr.isBlank()) {
//	                try {
//	                    LocalDateTime endDateTime = LocalDate.parse(endDateStr.trim()).atTime(LocalTime.MAX);
//	                    if (s.getShippedDate() == null || s.getShippedDate().isAfter(endDateTime)) {
//	                        return false;
//	                    }
//	                } catch (DateTimeParseException e) {
//	                    return false;
//	                }
//	            }
//
//	            if (categoryId != null && !categoryId.isEmpty()) {
//	                 if (s.getShippingStatusId() == null || !categoryId.contains(s.getShippingStatusId())) {
//	                     return false;
//	                 }
//	             }
//	            return true;
//	        })
//	        .collect(Collectors.toList());
//	}


	@Override
	public List<Shipping> getShipmentBasedOnFilters(String startDateStr, String endDateStr, List<Long> categoryId,
			List<Integer> shipmentId, List<String> locationAreas) {
		return shippingRepository.findAll(Specification.where(ShipmentSpecification.shipmentIdIn(shipmentId))
				.and(ShipmentSpecification.shippedDateAfter(startDateStr))
				.and(ShipmentSpecification.shippedDateBefore(endDateStr))
				.and(ShipmentSpecification.categoryIn(categoryId))
				.and(ShipmentSpecification.locationIn(locationAreas)));
	}


	@Override
	@Transactional
	public ResponseEntity<ShippingUpdateResponse> updateShippingStatusByShippingId(ShippingUpdate shippingUpdate) {

		if (shippingUpdate == null || shippingUpdate.getShippingId() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(new ShippingUpdateResponse(ResponseContent.ERROR, ResponseContent.SHIPPING_ID_NOT_NULL, null, null));
		}

		Optional<Shipping> shippingOpt = shippingRepository.findById(shippingUpdate.getShippingId());
		if (shippingOpt.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new ShippingUpdateResponse(ResponseContent.ERROR,
							ResponseContent.SHIPPING_ID_NOT_FOUND+ shippingUpdate.getShippingId(),
							shippingUpdate.getShippingId(), null));
		}

		Shipping shipping = shippingOpt.get();

		ShipmentActivityTracking tracking = new ShipmentActivityTracking();
		tracking.setRemarks(shippingUpdate.getRemarks() != null ? shippingUpdate.getRemarks() : "");
		tracking.setShipmentId(shipping.getShippingId().longValue());
		tracking.setShipmentStatusId(shippingUpdate.getShippingStatusId());

		if (shippingUpdate.getShippingStatusId() != null && shippingUpdate.getShippingStatusId() == 4) {
			tracking.setShipmentDriverId(shippingUpdate.getShipmentDriverId());
			tracking.setShipmentVehicleId(shippingUpdate.getShipmentVechileId());
			tracking.setShipmentImagePath(
					shippingUpdate.getShippingImagePath() != null ? shippingUpdate.getShippingImagePath()
							: "/dam/shipment/shippingImage.jfif");
		}

		if (shippingUpdate.getShippingStatusId() != null && shippingUpdate.getShippingStatusId() == 5) {
			ShipmentActivityTracking shipmentActivity = shippingActivityRepository
					.findByShipmentIdAndShipmentStatusId(shippingUpdate.getShippingId().longValue(), 4l);
			if (shipmentActivity != null) {
				tracking.setShipmentDriverId(shipmentActivity.getShipmentDriverId());
				tracking.setShipmentVehicleId(shipmentActivity.getShipmentVehicleId());
				tracking.setShipmentImagePath(shipmentActivity.getShipmentImagePath());
			} else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND)
						.body(new ShippingUpdateResponse(ResponseContent.ERROR,
								ResponseContent.UPDATE_UNSUCCESSFULL + shippingUpdate.getShippingId(),
								shippingUpdate.getShippingId(), null));
			}

		}

		shippingActivityRepository.save(tracking);

		ShippingStatus shippingStatus = shippingStatusRepository
				.findByShippingStatusId(shippingUpdate.getShippingStatusId());
		if (shippingStatus != null)
			shipping.setShipmentStatus(shippingStatus);
		shippingRepository.save(shipping);

		return ResponseEntity.ok(new ShippingUpdateResponse(ResponseContent.SUCCESS, ResponseContent.SHIPMENT_UPDATED_MESSAGE,
				shippingUpdate.getShippingId(), shippingUpdate.getShippingStatusId()));
	}

	@Override
	public List<ShipmentWorkflowStep> getAllShipmentWorkFlow() {

		return workFlowStepsRepository.findAllByIsActiveTrue();

	}

	@Override
	public List<ShippingStatus> getAllShippingStatus() {
		return shippingStatusRepository.findAll();
	}

	@Override
	public List<ShipmentMasterDeliveryZone> getAllShipmentDeliveryZone() {
		return shipmentMasterDeliveryZonesRepo.findAll();
	}

	@Override
	
	@KafkaListener(topics = "logistics.created", groupId = "logistics-service-group")
	public void kafkaLogisticsConsumer(String topic, String message) {

		System.out.println("Successfully Published the message to the Logistice Consumer:" + message);
	}

	@Override
	public List<ThirdPartyDeliveryAgent> getAllDeilveryAgent() {
		return deliveryAgentRepository.findAllByIsActiveTrue();
	}
	
	
	
	


}
