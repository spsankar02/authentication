package com.nalamfarms.logistic_service.controller;

import java.util.List;
import java.util.Map;

import com.nalamfarms.logistic_service.dto.*;
import com.nalamfarms.logistic_service.entity.*;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.nalamfarms.logistic_service.dto.ShippingUpdateResponse;
import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryZone;
import com.nalamfarms.logistic_service.service.LogisticService;
import com.nalamfarms.logistic_service.entity.ShipmentWorkflowStep;
import com.nalamfarms.logistic_service.serviceImp.PincodeResponse;

import lombok.RequiredArgsConstructor;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/logistic")
public class LogisticController {

  private final LogisticService logisticservice;



  @QueryMapping
  public List<ShippingStatus> getAllShipmentStatus() {
    return logisticservice.getAllShipmentStatus();
  }
  
	@QueryMapping
	public List<ThirdPartyDeliveryAgent> getAllDeilveryAgent() {
		return logisticservice.getAllDeilveryAgent();
	}

  @PostMapping("/addOrderInShipment")
  public ResponseEntity<Map<String, Object>> addOrderInShipment(@RequestBody ShippingDetailsDto request) {
    return logisticservice.addOrderInShipment(request);
  }
  @PostMapping("/updateShipmentStatus")
  public ResponseEntity<Map<String, Object>> updateShipmentStatus(@RequestBody UpdateShipmentStatusRequest request) {
    return logisticservice.updateShipmentStatus(request);
  }
  
  @QueryMapping
	public ShippingResponse  getShippingDetailsByOrderId(@Argument Long orderId)  {
		return logisticservice.getShippingDetailsById(orderId);
	}
  
  @QueryMapping
  public List<Shipping> getShippingDetailsByShippingId(@Argument("shippingId") Integer shippingId){
	  return logisticservice.getShippingDetailsByShippingId(shippingId);
  }
  @PostMapping("/updateShipmentStatusByOrderId")
  public ResponseEntity<String> shippingStatusUpdate(@RequestBody ShippingUpdate shippingUpdate){
    return logisticservice.shippingStatusUpdate(shippingUpdate);

  }

  @QueryMapping
  public ShipmentMasterDeliveryZone getPincodeDetails(@Argument  String pinCode) {
    return logisticservice.getPincodeDetails(pinCode);
  }
  @QueryMapping
  public PincodeResponse getPincodeAvailableDetails(@Argument  String pinCode) {
    return logisticservice.getPincodeAvailableDetails(pinCode);
  }

  @QueryMapping
  public List<ShipmentMasterDeliveryVehicle> getmasterDeliveryVehicle(){
	  return  logisticservice.getmasterDeliveryVehicle();
  }
  
  @MutationMapping
	public StatusUpdateResponse updateEntityStatus(@Argument String entityType, @Argument StatusUpdateRequestDTO request) {
		return logisticservice.updateStatus(entityType, request);

	}


  @QueryMapping
  public List<ShipmentMasterDrivers> getShipMentMasterDrivers() {
    return  logisticservice.getShipMentMasterDrivers();
  }
  
  @QueryMapping
  public  List<ShipmentMasterDeliveryAgent> getAllShipmentMasterDeliveryAgent(){
	  return logisticservice.getAllShipmentMasterDeliveryAgent();
  }
  
  
  @QueryMapping
  public List<Shipping> filterShippingByShipmentDateAndLocationArea(
          @Argument("filterType") List<ShipmentDateType> shipmentDateTypes,
          @Argument List<String> locationAreas) {
      return logisticservice.filterShipping(shipmentDateTypes, locationAreas);
  }
  
  @QueryMapping
  public List<ShipmentMasterDrivers> getAllShipmentMasterDrivers(){
	  return logisticservice.getAllShipmentMasterDrivers();
  }
  
  @QueryMapping
	public SaveResponse getShipmentDashboardReport() {
		return logisticservice.getShipmentDashboardReport();
	}

	@QueryMapping
	public List<Shipping> filterShipments(@Argument String startDate, @Argument String endDate,
			@Argument List<Long> categoryId, @Argument List<Integer> shipmentId, @Argument List<String> locationAreas) {
		return logisticservice.getShipmentBasedOnFilters(startDate, endDate, categoryId, shipmentId, locationAreas);

	}

	@PostMapping(value = "/updateShippingStatusByShippingId")
	public ResponseEntity<ShippingUpdateResponse> updateShippingStatusByShippingId(@RequestBody ShippingUpdate shippingUpdate ) {
		return logisticservice.updateShippingStatusByShippingId(shippingUpdate);
	}

	@QueryMapping
	public List<ShipmentWorkflowStep> getAllShipmentWorkFlow() {
		return logisticservice.getAllShipmentWorkFlow();
	}

	@QueryMapping
	public List<ShippingStatus> getAllShippingStatus() {
		return logisticservice.getAllShippingStatus();
	}

    @QueryMapping
    public List<ShipmentMasterDeliveryZone> getAllDeliveryZones(){
        return logisticservice.getAllShipmentDeliveryZone();
    }



}
