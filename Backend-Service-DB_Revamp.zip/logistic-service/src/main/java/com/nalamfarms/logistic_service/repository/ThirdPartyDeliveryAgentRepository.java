package com.nalamfarms.logistic_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalamfarms.logistic_service.entity.ThirdPartyDeliveryAgent;

public interface ThirdPartyDeliveryAgentRepository extends JpaRepository<ThirdPartyDeliveryAgent, Long> {

	List<ThirdPartyDeliveryAgent> findAllByIsActiveTrue();

}
