package com.nalamfarms.logistic_service.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "shipment_master_shipment_status")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShippingStatus {
	@Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "shipping_status_id")
	  private Long shippingStatusId;
	 
	  @Column(name = "status_name")
	  private String statusName;
	 
	  @Column(name = "description")
	  private String description;
	  
	  @Column(name = "is_active")
	  private Boolean isActive;
	  
	  @OneToOne(fetch = FetchType.EAGER)
	  @JoinColumn(name = "workflow_step_id",nullable = false,insertable = false,updatable = false)
      @com.fasterxml.jackson.annotation.JsonManagedReference
      private ShipmentWorkflowStep workFlow;
	  
	  @Column(name = "workflow_step_id",nullable = false)
	  private Long workFlowStepId;


}
