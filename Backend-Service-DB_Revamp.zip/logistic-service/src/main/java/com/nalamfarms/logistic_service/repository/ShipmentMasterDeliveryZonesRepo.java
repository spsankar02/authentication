package com.nalamfarms.logistic_service.repository;

import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryZone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ShipmentMasterDeliveryZonesRepo extends JpaRepository<ShipmentMasterDeliveryZone,Long> {
}
