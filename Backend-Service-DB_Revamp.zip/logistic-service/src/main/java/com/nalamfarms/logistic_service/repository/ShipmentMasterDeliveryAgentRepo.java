package com.nalamfarms.logistic_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryAgent;

public interface ShipmentMasterDeliveryAgentRepo extends JpaRepository<ShipmentMasterDeliveryAgent, Integer> {

	public ShipmentMasterDeliveryAgent findByAgentId(Long id);

}
