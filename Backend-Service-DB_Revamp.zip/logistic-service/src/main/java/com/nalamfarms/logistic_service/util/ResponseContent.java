package com.nalamfarms.logistic_service.util;

public class ResponseContent {
	
	private ResponseContent() {}
	
	/**========== ERROR MESSAGES ==========**/
	public static final String INVENTORY_UPDATE_ERRORMESSAGE="Error Occurred While Updating the Inventory Details";
	public static final String INVALID_ORDERID_ERRORMESSAGE="invalid orderId or tracking number";
	public static final String SHIPMENT_DATA_NOTFOUND_ERRORMESSAGE="No shipping data found for orderId: ";
	public static final String SHIPMENT_FETCH_ERRORMESSAGE="Error fetching shipping details: ";
	public static final String PINCODE_FETCH_ERRORMESSAGE="Error occurred while fetching pincode availability";
	
	 /** ========== EXCEPTION MESSAGES ========== */
	public static final String SHIPMENT_INVALID_REQUEST_EXCEPTION="invalid request";
	
	/** ========== SUCCESS MESSAGES ========== */
	public static final String SHIPMENT_ADDED_MESSAGE = "shipment details added successfully";
	public static final String SHIPMENT_UPDATED_MESSAGE ="shipping status updated successfully";
	
	/** ========== STATUS MESSAGES ========== */
	public static final String PENDING="Pending";
	public static final String ERROR="error";
	public static final String SUCCESS="Success";
	public static final String UPDATE_SUCCESS="Updated_successfully...!";
	public static final String INVALID_SHIPPING_STATUS="Invalid shipping status ID";
	public static final String ORDER_SHIPPED_STATUS="Order_Shipped";
	public static final String INVALID_ENTITY_TYPE = "Invalis Entity Type";
	public static final String UPDATE_VEHICLE_MESSAGE = "Vehicles Status Updated Successfully...!";
	public static final String VECHICLE_NOTFOUND = "Vehicle ID is Not Found";
	public static final String DRIVER_NOTFOUND = "Driver ID is Not Found";
	public static final String UPDATE_DRIVER_MESSAGE = "Driver Status Updated Successfully...!";
	public static final String SHIPMENTDETAILS_NOTFOUND = "Shipment ID is Not Found";
	public static final String AGENT_NOTFOUND = "Agent ID is Not Found";
	public static final String PINCODE_NOTFOUND = "Pincode not found: ";
	public static final String PINCODE_NOT_APPLICABLE = "Pincode is not applicable for delivery";
	public static final String PINCODE_SERVICEABLE="Pincode is serviceable";
	public static final String SHIPPING_ID_NOT_NULL="Shipping request or ID cannot be null";
	public static final String SHIPPING_ID_NOT_FOUND="Shipping record not found for ID";
	public static final String UPDATE_UNSUCCESSFULL="Cannot Update For Status:Delivered";
	
	
	
}
