package com.nalamfarms.logistic_service.serviceImp;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PincodeResponse {
    private  Boolean isAvailable;;
    private String message;
}
