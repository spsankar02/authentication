package com.nalamfarms.logistic_service.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "shipment_workflow_steps")
@Data
public class ShipmentWorkflowStep {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "step_id")
    private Long stepId;
 
    @Column(name = "step_name", nullable = false, unique = true, length = 50)
    private String stepName;
 
    @Column(name = "step_description")
    private String stepDescription;
 
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
 
    @Column(name = "modified_at")
    private LocalDateTime modifiedAt = LocalDateTime.now();
 
    @Column(name = "created_by")
    private Long createdBy;
 
    @Column(name = "modified_by")
    private Long modifiedBy;
 
    @Column(name = "is_active")
    private Boolean isActive;
    
    @OneToOne(fetch = FetchType.EAGER,mappedBy = "workFlow")
    @com.fasterxml.jackson.annotation.JsonManagedReference
    private ShippingStatus shippingStatus;

}
