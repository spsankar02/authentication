package com.nalamfarms.logistic_service.service;


import java.util.List;
import java.util.Map;

import com.nalamfarms.logistic_service.dto.ShippingUpdate;
import com.nalamfarms.logistic_service.dto.ShippingUpdateResponse;
import com.nalamfarms.logistic_service.dto.StatusUpdateRequestDTO;
import com.nalamfarms.logistic_service.dto.StatusUpdateResponse;
import com.nalamfarms.logistic_service.entity.*;
import com.nalamfarms.logistic_service.serviceImp.PincodeResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.nalamfarms.logistic_service.dto.SaveResponse;
import com.nalamfarms.logistic_service.dto.ShipmentDateType;
import com.nalamfarms.logistic_service.dto.ShippingDetailsDto;
import com.nalamfarms.logistic_service.dto.ShippingResponse;
import com.nalamfarms.logistic_service.dto.UpdateShipmentStatusRequest;


@Service
public interface LogisticService {
    List<Shipping> getShippingDetailsByShippingId(Integer shippingID);
	List<ShippingStatus> getAllShipmentStatus();
    ResponseEntity<Map<String, Object>> addOrderInShipment(ShippingDetailsDto request);
    ResponseEntity<Map<String, Object>> updateShipmentStatus(UpdateShipmentStatusRequest request);
    ShippingResponse  getShippingDetailsById(Long orderId) ;
    public ResponseEntity<String> shippingStatusUpdate(ShippingUpdate shippingUpdate);

    ShipmentMasterDeliveryZone getPincodeDetails(String pinCode);
	List<ShipmentMasterDeliveryVehicle> getmasterDeliveryVehicle();

    List<ShipmentMasterDrivers>  getShipMentMasterDrivers();
	List<ShipmentMasterDeliveryAgent> getAllShipmentMasterDeliveryAgent();
	List<ShipmentMasterDrivers> getAllShipmentMasterDrivers();
	List<Shipping> filterShipping(List<ShipmentDateType> shipmentDateTypes, List<String> locationAreas);
	StatusUpdateResponse updateStatus(String entityType, StatusUpdateRequestDTO request);
	SaveResponse getShipmentDashboardReport();
	//List<SaveResponse> getShipmentDashboardReport(List<Long> statusIds, String category, Long limit);
	PincodeResponse getPincodeAvailableDetails(String pinCode);
	List<Shipping> getShipmentBasedOnFilters(String startDateStr, String endDateStr, List<Long> categoryId,
			List<Integer> shipmentId, List<String> locationAreas)	;
	ResponseEntity<ShippingUpdateResponse> updateShippingStatusByShippingId(ShippingUpdate shippingUpdate);
	List<ShipmentWorkflowStep> getAllShipmentWorkFlow();
	List<ShippingStatus> getAllShippingStatus();
	List<ShipmentMasterDeliveryZone> getAllShipmentDeliveryZone();
	void kafkaLogisticsConsumer(String topic,String message);
	List<ThirdPartyDeliveryAgent> getAllDeilveryAgent();
}
