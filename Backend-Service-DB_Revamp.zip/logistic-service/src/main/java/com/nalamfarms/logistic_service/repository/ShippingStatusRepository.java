package com.nalamfarms.logistic_service.repository;

import com.nalamfarms.logistic_service.entity.ShippingStatus;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ShippingStatusRepository extends JpaRepository<ShippingStatus,Long> {
  ShippingStatus findByShippingStatusId(Long shippingStatusId);


List<ShippingStatus> findAllByIsActiveTrue();
}
