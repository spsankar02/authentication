package com.nalamfarms.logistic_service.dto;

public enum ShipmentDateType {

	TODAY, YESTERDAY, OLD, ALL

}
