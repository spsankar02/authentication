package com.nalamfarms.logistic_service.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalamfarms.logistic_service.entity.ShipmentMasterDeliveryZone;

public interface ShipMentMasterDeliveryZoneRepository extends JpaRepository<ShipmentMasterDeliveryZone, Long> {
	Optional<ShipmentMasterDeliveryZone> findByPinCode(String pinCode);


	//Long countByIsAvailableTrue();


	Long countByIsActiveTrue();

}
