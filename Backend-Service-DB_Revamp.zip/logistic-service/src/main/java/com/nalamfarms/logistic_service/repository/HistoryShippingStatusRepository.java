package com.nalamfarms.logistic_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalamfarms.logistic_service.entity.HistoryShippingStatus;

public interface HistoryShippingStatusRepository extends JpaRepository<HistoryShippingStatus, Long>{

}
