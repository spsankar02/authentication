package com.nalamfarms.logistic_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nalamfarms.logistic_service.entity.ShipmentWorkflowStep;

@Repository
public interface ShipmentWorkflowStepRepository extends JpaRepository<ShipmentWorkflowStep, Long>{

	//List<ShipmentWorkflowStep> findAllByIsActive();

	List<ShipmentWorkflowStep> findAllByIsActiveTrue();

}
