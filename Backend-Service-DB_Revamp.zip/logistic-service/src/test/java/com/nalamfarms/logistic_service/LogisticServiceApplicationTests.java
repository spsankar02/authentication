//package com.nalamfarms.logistic_service;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class LogisticServiceApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
