package com.nalamfarms.cart_service.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import com.nalamfarms.cart_service.serviceimpl.CartServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nalamfarms.cart_service.dto.AddToCartRequest;
import com.nalamfarms.cart_service.dto.CartDetailsResponse;
import com.nalamfarms.cart_service.dto.CartResponse;
import com.nalamfarms.cart_service.dto.DeleteCartRequest;
import com.nalamfarms.cart_service.entity.Cart;
import com.nalamfarms.cart_service.entity.CartType;
import com.nalamfarms.cart_service.entity.SaveStatus;
import com.nalamfarms.cart_service.exception.CustomErrorType;
import com.nalamfarms.cart_service.exception.GraphQLServiceException;
import com.nalamfarms.cart_service.repository.CartRepository;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class CartServiceImplementationTest {

	@Mock
	private CartRepository cartRepo;

	@InjectMocks
	private CartServiceImpl cartService;

	@Mock
	private WebClient webClient;

	@Mock
	private ObjectMapper objectMapper;

	@Mock
	private WebClient.RequestBodyUriSpec requestBodyUriSpec;

	@Mock
	private WebClient.RequestBodySpec requestBodySpec;
	
	@Mock
    private WebClient.RequestHeadersSpec<?> requestHeadersSpec;

	@Mock
	private WebClient.ResponseSpec responseSpec;

	private final String productServiceUrl = "http://localhost:8006";

	private AddToCartRequest validSubscriptionRequest;
	private Cart existingCart;
	private Cart oldSubscribedCart;
	private Cart deleteCart;
	private DeleteCartRequest cartRequest;

	@BeforeEach
	void setUp() {
		validSubscriptionRequest = new AddToCartRequest();
		validSubscriptionRequest.setMemberId(2L);
	///	validSubscriptionRequest.setBasketId(5L);
	///	validSubscriptionRequest.setVariantTypeId(1L);
		validSubscriptionRequest.setQuantity(1);
		validSubscriptionRequest.setPriceAtAdd(BigDecimal.valueOf(99.99));
		validSubscriptionRequest.setDiscountAtAdd(BigDecimal.valueOf(10.0));
		validSubscriptionRequest.setType("subscription");

		existingCart = new Cart();
		existingCart.setMemberId(2L);
	///	existingCart.setBasketId(5L);
	///	existingCart.setVariantTypeId(1L);
		existingCart.setQuantity(1);
		existingCart.setPriceAtAdd(BigDecimal.valueOf(99.99));
		existingCart.setDiscountAtAdd(BigDecimal.valueOf(10.0));
		existingCart.setIsActive(true);
		existingCart.setSubscribed(true);
		existingCart.setCreatedAt(LocalDateTime.now());

		oldSubscribedCart = new Cart();
		oldSubscribedCart.setCartId(2L);
		oldSubscribedCart.setMemberId(2L);
	///	oldSubscribedCart.setBasketId(3L);
		oldSubscribedCart.setIsActive(true);
		oldSubscribedCart.setSubscribed(true);

		cartRequest = new DeleteCartRequest();
		cartRequest.setCartId(1L);
		cartRequest.setMemberId(1L);
		cartRequest.setStatus(2);

		deleteCart = new Cart();
		deleteCart.setCartId(1L);
		deleteCart.setMemberId(1L);
		deleteCart.setIsActive(true);
		deleteCart.setCartStatus("ACTIVE");
	
	}

	@Test
	void testAddCartDetails_NewCart_Success() {
		AddToCartRequest request = new AddToCartRequest();
		request.setMemberId(1L);
		request.setProductId(10L);
	///	request.setItemId(10L);
	///	request.setVariantTypeId(2L);
		request.setType("add");
		request.setQuantity(2);
		request.setPriceAtAdd(BigDecimal.valueOf(100));
		request.setDiscountAtAdd(BigDecimal.valueOf(10));

		List<AddToCartRequest> requests = List.of(request);

		// No existing cart
	///	when(cartRepo.findByMemberIdAndProductIdAndItemIdAndVariantTypeIdAndIsActiveTrue(1L, 10L, 100L, 5L))
	///			.thenReturn(Optional.empty());

		// When saving new cart
		ArgumentCaptor<List<Cart>> cartCaptor = ArgumentCaptor.forClass(List.class);
		when(cartRepo.saveAll(anyList())).thenAnswer(invocation -> invocation.getArgument(0));

		// When
		List<Cart> result = cartService.addCartDetails(requests);

		// Then
		assertNotNull(result);
		assertEquals(1, result.size());

		Cart savedCart = result.get(0);
		assertEquals(1L, savedCart.getMemberId());
		assertEquals(2, savedCart.getQuantity());
		assertFalse(savedCart.isSubscribed());
		assertTrue(savedCart.getIsActive());
		assertEquals("CART", savedCart.getSaveStatus());
		assertEquals("ITEM", savedCart.getType());
		verify(cartRepo).saveAll(cartCaptor.capture());
	}

	@Test
	void testAddCartDetails_UpdateExistingCart_Success() {
		AddToCartRequest addRequest = new AddToCartRequest();
		addRequest.setMemberId(2L);
	///	addRequest.setBasketId(5L);
	///	addRequest.setVariantTypeId(1L);
		addRequest.setQuantity(3);
		addRequest.setPriceAtAdd(BigDecimal.valueOf(199.99));
		addRequest.setDiscountAtAdd(BigDecimal.valueOf(20.0));
		addRequest.setType("add");

	///	when(cartRepo.findByMemberIdAndBasketIdAndVariantTypeIdAndIsActiveTrue(2L, 5L, 1L))
	///			.thenReturn(Optional.of(existingCart));
		when(cartRepo.saveAll(anyList())).thenAnswer(invocation -> {
			List<Cart> carts = invocation.getArgument(0);
			carts.forEach(cart -> {
				cart.setQuantity(3);
				cart.setPriceAtAdd(BigDecimal.valueOf(199.99));
				cart.setDiscountAtAdd(BigDecimal.valueOf(20.0));
			});
			return carts;
		});

		List<Cart> result = cartService.addCartDetails(Collections.singletonList(addRequest));

		assertNotNull(result);
		assertEquals(1, result.size());
		Cart updatedCart = result.get(0);
		assertEquals(3, updatedCart.getQuantity());
		assertTrue(updatedCart.getIsActive());
	///	assertEquals(5L, updatedCart.getBasketId());
	///	assertEquals(1L, updatedCart.getVariantTypeId());
		verify(cartRepo, times(1)).saveAll(anyList());
	}

	@Test
	void testAddCartDetails_SubscriptionType_DisablesOldAndCreatesNew() {
		Cart newCart = new Cart();
		newCart.setMemberId(2L);
	///	newCart.setBasketId(5L);
	///	newCart.setVariantTypeId(1L);
		newCart.setQuantity(1);
		newCart.setPriceAtAdd(BigDecimal.valueOf(99.99));
		newCart.setDiscountAtAdd(BigDecimal.valueOf(10.0));
		newCart.setIsActive(true);
		newCart.setSubscribed(true);
		newCart.setType(CartType.BASKET.getValue());
		newCart.setSaveStatus(SaveStatus.CART.getValue());

	///	when(cartRepo.findByMemberIdAndBasketIdAndVariantTypeIdAndIsActiveTrue(2L, 5L, 1L))
	///			.thenReturn(Optional.empty());
		when(cartRepo.findByMemberIdAndIsActiveTrueAndIsSubscribedTrue(2L))
				.thenReturn(Collections.singletonList(oldSubscribedCart));
		when(cartRepo.saveAll(anyList())).thenAnswer(invocation -> {
			List<Cart> carts = invocation.getArgument(0);
			if (carts.contains(oldSubscribedCart)) {
				oldSubscribedCart.setIsActive(false);
				oldSubscribedCart.setSubscribed(false);
				oldSubscribedCart.setModifiedBy(2L);
				oldSubscribedCart.setModifiedAt(LocalDateTime.now());
				return Collections.singletonList(oldSubscribedCart);
			}
			return Collections.singletonList(newCart);
		});

		List<Cart> result = cartService.addCartDetails(Collections.singletonList(validSubscriptionRequest));

		assertFalse(result.isEmpty());
		assertEquals(1, result.size());
		Cart resultCart = result.get(0);
		assertTrue(resultCart.isSubscribed());
	///	assertEquals(5L, resultCart.getBasketId());
		assertTrue(resultCart.getIsActive());
		verify(cartRepo, times(2)).saveAll(anyList());
		verify(cartRepo, times(1)).findByMemberIdAndIsActiveTrueAndIsSubscribedTrue(2L);
	}

	@Test
	void testAddCartDetails_NullRequest_ReturnsEmptyList() {
		List<Cart> result = cartService.addCartDetails(null);

		assertNotNull(result);
		assertTrue(result.isEmpty());
		verify(cartRepo, never()).saveAll(anyList());
	}

	@Test
	void testAddCartDetails_EmptyRequest_ReturnsEmptyList() {
		List<Cart> result = cartService.addCartDetails(Collections.emptyList());

		assertNotNull(result);
		assertTrue(result.isEmpty());
		verify(cartRepo, never()).saveAll(anyList());
	}

	@Test
	void testAddCartDetails_RepositoryThrowsUnexpectedException() {
	///	lenient().when(cartRepo.findByMemberIdAndProductIdAndItemIdAndVariantTypeIdAndIsActiveTrue(anyLong(), anyLong(),
	///			anyLong(), anyLong())).thenReturn(Optional.empty());

		when(cartRepo.saveAll(anyList())).thenThrow(new RuntimeException("Database failure"));

		GraphQLServiceException thrown = assertThrows(GraphQLServiceException.class, () -> {
			cartService.addCartDetails(List.of(validSubscriptionRequest));
		});

		assertTrue(thrown.getMessage().contains("Error saving cart details"));
		assertEquals(CustomErrorType.INTERNAL_ERROR, thrown.getErrorType());
	}

	@Test
    void deleteCartDetails_SuccessfulDeactivation() {
        // Arrange
        when(cartRepo.findByCartIdAndMemberIdAndIsActiveTrue(1L, 1L)).thenReturn(deleteCart);
        when(cartRepo.save(any(Cart.class))).thenReturn(deleteCart);

        // Act
        CartResponse response = cartService.deleteCartDetails(cartRequest);

        // Assert
        assertTrue(response.isStatus());
        assertEquals("Cart deactivated successfully", response.getMessage());
        assertFalse(deleteCart.getIsActive());
        assertEquals("CANCELLED", deleteCart.getCartStatus());
        assertEquals(1L, deleteCart.getModifiedBy());
        verify(cartRepo).findByCartIdAndMemberIdAndIsActiveTrue(1L, 1L);
        verify(cartRepo).save(deleteCart);
    }

	@Test
	void deleteCartDetails_CartNotFound_ReturnsFailureResponse() {
		cartRequest.setCartId(3L);
		// Arrange
		when(cartRepo.findByCartIdAndMemberIdAndIsActiveTrue(3L, 1L)).thenReturn(null);

		// Act
		CartResponse response = cartService.deleteCartDetails(cartRequest);

		// Assert
		assertFalse(response.isStatus());
		assertEquals("Cart not found, wrong member, or already inactive", response.getMessage());
		verify(cartRepo).findByCartIdAndMemberIdAndIsActiveTrue(3L, 1L);
		verify(cartRepo, never()).save(any());
	}

	@Test
    void deleteCartDetails_DatabaseError_ThrowsGraphQLServiceException() {
        // Arrange
        when(cartRepo.findByCartIdAndMemberIdAndIsActiveTrue(1L, 1L)).thenReturn(deleteCart);
        doThrow(new RuntimeException("Database error")).when(cartRepo).save(any(Cart.class));

        // Act & Assert
        GraphQLServiceException exception = assertThrows(GraphQLServiceException.class, () -> {
            cartService.deleteCartDetails(cartRequest);
        });

        assertTrue(exception.getMessage().contains("Error deactivating cart"));
        assertTrue(exception.getMessage().contains("Database error"));
        verify(cartRepo).findByCartIdAndMemberIdAndIsActiveTrue(1L, 1L);
        verify(cartRepo).save(any(Cart.class));
    }

	@Test
    void getAddCartDetails_SuccessfulRetrieval_ReturnsCartDetailsResponse() {

//        // Mock GraphQL response
//        JsonNode mockJsonNode = new ObjectMapper().createObjectNode()
//                .putObject("dasta")
//                .putObject("getProductDetails")
//                .putArray("results")
//                .addObject()
//                .put("itemId", 10L)
//                .put("itemName", "Test Item")
//                .put("imageUrl", "url")
//                .put("isActive", true)
//                .put("price", 100)
//                .put("discount", 10);
//
//        // Use Mockito leniency or static ObjectMapper for convertValue
//        when(webClient.post()).thenReturn(requestBodyUriSpec);
//        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
//        when(requestBodyUriSpec.uri(anyString()))
//        .thenReturn((RequestBodySpec) requestBodySpec);
//        when(requestBodySpec.retrieve()).thenReturn(responseSpec);
//        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
//        when(responseSpec.bodyToMono(eq(JsonNode.class)))
//            .thenReturn(Mono.just(mockJsonNode));
//
//        CartDetailsResponse response = cartService.getAddCartDetails(101L, "type");
//
//        assertNotNull(response);
//        assertEquals(1, response.getResults().size());
//        assertEquals(10L, response.getResults().get(0).getItemId());
        
        
     

        Cart basketCart = new Cart();
        basketCart.setCartId(2L);
	///    basketCart.setBasketId(301L);
	///    basketCart.setVariantTypeId(1L);
        basketCart.setIsActive(true);
        basketCart.setSaveStatus(1);
        basketCart.setQuantity(3);
        basketCart.setType(2);
        basketCart.setPriceAtAdd(BigDecimal.valueOf(20));
        basketCart.setDiscountAtAdd(BigDecimal.valueOf(5));
        basketCart.setSubscribed(true);

        List<Cart> cartList = List.of(basketCart);
        when(cartRepo.findByMemberIdAndIsActiveTrue(3L)).thenReturn(cartList);

        // Mock WebClient behavior
        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
        when(requestBodySpec.retrieve()).thenReturn(responseSpec);        
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);

        // Mock JSON response from product service
        JsonNode mockJson = buildMockGraphQLResponse();

        when(responseSpec.bodyToMono(JsonNode.class)).thenReturn(Mono.just(mockJson));
        when(objectMapper.convertValue(any(JsonNode.class), any(TypeReference.class))).thenCallRealMethod();

        // Call method under test
	///    CartDetailsResponse response = cartService.getAddCartDetails(3L, "all");

    ///    assertNotNull(response);
	///    assertEquals(2, response.getResults().size());
    }
	
	private JsonNode buildMockGraphQLResponse() {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode root = mapper.createObjectNode();
        ObjectNode data = mapper.createObjectNode();
        ObjectNode getProductDetails = mapper.createObjectNode();
        ArrayNode results = mapper.createArrayNode();

        // Mock BASKET
        ObjectNode basket = mapper.createObjectNode();
        basket.put("basketId", 301L);
        basket.put("basketName", "Fresh Basket");
        basket.put("imageUrl", "/img/basket.jpg");
        basket.put("isActive", true);
        basket.putNull("itemId");
        basket.putNull("itemName");
        basket.putNull("price");
        basket.putNull("discount");
        basket.putNull("product");
        basket.put("upcoming", false);
        basket.put("description", "Fresh daily vegetables");

        // variantLists -> basketprices
        ObjectNode variant = mapper.createObjectNode();
        variant.put("variantTypeId", "1");
        variant.put("variantTypeName", "Small Pack");
        variant.put("size", 3);

        ObjectNode basketPrice = mapper.createObjectNode();
        basketPrice.put("basketPriceId", "11");
        basketPrice.put("basketId", "301");
        basketPrice.put("price", 20);
        basketPrice.put("discount", 5);
        basketPrice.put("isActive", true);

        variant.set("basketprices", basketPrice);

        ArrayNode variantList = mapper.createArrayNode();
        variantList.add(variant);
        basket.set("variantLists", variantList);
        
        results.add(basket);
        getProductDetails.set("results", results);
        data.set("getProductDetails", getProductDetails);
        root.set("data", data);

        return root;
    }

//
//	@Test
//	void testGetCartDetailsByMemberId() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetCartDetailsBycartIds() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetAddCartDetails() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetCartSummary() {
//		fail("Not yet implemented");
//	}

}
