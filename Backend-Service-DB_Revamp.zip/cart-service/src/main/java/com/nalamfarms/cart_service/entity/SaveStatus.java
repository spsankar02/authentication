package com.nalamfarms.cart_service.entity;

import lombok.Getter;

@Getter
public enum SaveStatus {
	CART(1),
    SAVED(2);

    private final int value;

    SaveStatus(int value) {
        this.value = value;
    }
    

    public static SaveStatus from(int value) {
        return switch (value) {
            case 1 -> CART;
            case 2 -> SAVED;
            default -> throw new IllegalArgumentException("Invalid SaveStatus value: " + value);
        };
    }
}
