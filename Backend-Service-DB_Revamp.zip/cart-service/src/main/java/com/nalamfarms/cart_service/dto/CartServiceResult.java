package com.nalamfarms.cart_service.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartServiceResult {
	private Long cartId;
	private Long productId;
	private Boolean cartIsActive;
	private Boolean saveStatus;
	private Integer quantity;
	private Long variantTypeId;
	private BigDecimal priceAtAdd;
	private BigDecimal discountAtAdd;
	private String type;
	private Boolean isOfferItem;
	private Long itemId;
	private String itemName;
	private String imageUrl;
	private Boolean isActive;
	private Product product;
	private Long basketId;
	private String basketName;
	private Boolean upcoming;
	private String description;
	private List<VariantList> variantLists;
	private boolean isSubscribed;
}
