package com.nalamfarms.cart_service.exception;

import lombok.Getter;

import java.io.Serial;

@Getter
public class GraphQLServiceException extends RuntimeException {

	@Serial
	private static final long serialVersionUID = 1L;
	private final CustomErrorType errorType;

	public GraphQLServiceException(String message, CustomErrorType errorType) {
		super(message);
		this.errorType = errorType;
	}

}
