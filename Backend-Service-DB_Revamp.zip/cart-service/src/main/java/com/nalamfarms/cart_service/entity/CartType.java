package com.nalamfarms.cart_service.entity;

import lombok.Getter;

@Getter
public enum CartType {
	ITEM(1), BASKET(2);

	private final int value;

	CartType(int value) {
		this.value = value;
	}

	public static CartType from(Long productId, Long basketId) {
		return (productId != null) ? ITEM : BASKET;

    }
}
