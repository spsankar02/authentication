package com.nalamfarms.cart_service.entity;

public enum CartStatus {
	ORDERED(1),
    CANCELLED(2);
	
	private final int value;

    CartStatus(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    public static CartStatus fromValue(int value) {
        for (CartStatus status : values()) {
            if (status.getValue() == value) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }

    public String getStatusName() {
        return this.name();
    }
}
