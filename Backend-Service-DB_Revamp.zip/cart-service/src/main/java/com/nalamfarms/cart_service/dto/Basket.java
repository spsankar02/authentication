package com.nalamfarms.cart_service.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Basket {
	private Long basketId;
	private String basketName;
	private String imageUrl;
	private boolean isActive;
	private boolean upcoming;
	private String description;
	private List<VariantList> variantLists;
}
