package com.nalamfarms.cart_service.dto;

import lombok.Data;

@Data
public class Member {
	private Long memberId;
    private String firstname;
    private String lastname;
    private String emailAddress;
    private boolean isActive;
}

	