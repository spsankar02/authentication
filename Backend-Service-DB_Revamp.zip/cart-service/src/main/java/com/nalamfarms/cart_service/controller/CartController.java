package com.nalamfarms.cart_service.controller;

import java.util.List;

import com.nalamfarms.cart_service.dto.CartQuantityDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nalamfarms.cart_service.dto.AddToCartRequest;
import com.nalamfarms.cart_service.dto.CartResponse;
import com.nalamfarms.cart_service.dto.DeleteCartRequest;
import com.nalamfarms.cart_service.entity.Cart;
import com.nalamfarms.cart_service.service.CartService;

@RestController
@RequiredArgsConstructor
public class CartController {

	private final CartService cartService; // No @Autowired needed

	@MutationMapping
	public List<Cart> addCartDetails(@Argument("input") List<AddToCartRequest> request) {
		return cartService.addCartDetails(request);
	}

	@MutationMapping
	public CartResponse deleteCartDetails(@Argument("input") DeleteCartRequest cartRequest) {
		return cartService.deleteCartDetails(cartRequest);
	}

	@QueryMapping
	public List<Cart> getCartDetailsByMemberId(@Argument Long memberId) {
		return cartService.getCartDetailsByMemberId(memberId);
	}

//	@QueryMapping
//	public CartDetailsResponse getAddCartDetails(@Argument("input") GetAddCartDetailsRequest request) {
//		return cartService.getAddCartDetails(request.getMemberId(), request.getType());
//	}

//	@QueryMapping
//	public BillDetails getCartSummary(@Argument("input") BillDetailsRequest request) {
//		return cartService.getCartSummary(request.getMemberId(), request.getCartIds(),request.getType(),request.isUsedPoints());
//	}

  @QueryMapping
  public List<Cart> getCartDetailsByCartIds(@Argument("input") List<Long> cartIds) {
    return cartService.getCartDetailsBycartIds(cartIds);
  }

  @QueryMapping
  public List<CartQuantityDetails> getCartQuantity(@Argument Long memberId, @Argument List<Long> skuIds) {
	  return cartService.getCartQuantity(memberId, skuIds);
  }

}
