package com.nalamfarms.cart_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.graphql.execution.RuntimeWiringConfigurer;
import org.springframework.web.reactive.function.client.WebClient;

import graphql.scalars.ExtendedScalars;

@Configuration
@ComponentScan("com.nalamfarms.cart_service")
public class WebClientConfig {
	@Bean 
	public WebClient webClient(WebClient.Builder builder) {
	    return builder.build();
	}
	
	@Bean
	public RuntimeWiringConfigurer addScalars() {
	    return wiring -> wiring
	        .scalar(ExtendedScalars.GraphQLLong);
	}
}
