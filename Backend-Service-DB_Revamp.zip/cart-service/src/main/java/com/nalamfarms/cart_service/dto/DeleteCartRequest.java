package com.nalamfarms.cart_service.dto;

import lombok.Data;

@Data
public class DeleteCartRequest {
	private Long cartId;
	private Long memberId;
	private Integer status;
}
