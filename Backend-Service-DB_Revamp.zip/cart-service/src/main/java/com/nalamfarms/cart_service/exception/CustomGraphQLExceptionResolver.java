package com.nalamfarms.cart_service.exception;

import java.util.List;

import org.springframework.graphql.execution.DataFetcherExceptionResolver;
import org.springframework.stereotype.Component;

import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;
import reactor.core.publisher.Mono;

@Component
public class CustomGraphQLExceptionResolver implements DataFetcherExceptionResolver {

    @Override
    public Mono<List<GraphQLError>> resolveException(Throwable exception, DataFetchingEnvironment env) {

        if (exception instanceof GraphQLServiceException ex) {
            // Log expected (business) exceptions
            AuditLoggerUtil.log(ex);

            return Mono.just(List.of(
                GraphqlErrorBuilder.newError(env)
                    .message(ex.getMessage())
                    .errorType(ex.getErrorType())
                    .build()
            ));
        }

        // Log unexpected exceptions
        AuditLoggerUtil.log(exception);

        return Mono.just(List.of(
            GraphqlErrorBuilder.newError(env)
                .message("Unexpected error occurred")
                .errorType(CustomErrorType.INTERNAL_ERROR)
                .build()
        ));
    }
}
