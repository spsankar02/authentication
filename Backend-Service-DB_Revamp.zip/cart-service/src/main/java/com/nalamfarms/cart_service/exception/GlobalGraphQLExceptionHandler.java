package com.nalamfarms.cart_service.exception;

import org.springframework.graphql.data.method.annotation.GraphQlExceptionHandler;
import org.springframework.stereotype.Component;

import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;

@Component
public class GlobalGraphQLExceptionHandler {


    @GraphQlExceptionHandler(GraphQLServiceException.class)
    public GraphQLError handleGraphQLServiceException(GraphQLServiceException ex, DataFetchingEnvironment env) {
        AuditLoggerUtil.log(ex);
        return GraphqlErrorBuilder.newError(env)
            .message(ex.getMessage())
            .errorType(ex.getErrorType())
            .build();
    }

    @GraphQlExceptionHandler
    public GraphQLError handleAllExceptions(Throwable ex, DataFetchingEnvironment env) {
        AuditLoggerUtil.log(ex);
        return GraphqlErrorBuilder.newError(env)
            .message("Unexpected error occurred")
            .errorType(CustomErrorType.INTERNAL_ERROR)
            .build();
    }
}