package com.nalamfarms.cart_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ItemDetails {
	private Long itemId;
	private String itemName;
	private String imageUrl;
	private boolean isActive;
	private Product products;
	private BigDecimal price;
	private BigDecimal discount;
}
