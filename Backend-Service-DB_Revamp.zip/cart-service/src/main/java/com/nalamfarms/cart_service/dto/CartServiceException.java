package com.nalamfarms.cart_service.dto;

public class CartServiceException  extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * Constructs a new CartServiceException with the specified detail message.
     *
     * @param message the detail message
     */
    public CartServiceException(String message) {
        super(message);
    }

    /**
     * Constructs a new CartServiceException with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause   the cause of the exception
     */
    public CartServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new CartServiceException with the specified cause.
     *
     * @param cause the cause of the exception
     */
    public CartServiceException(Throwable cause) {
        super(cause);
    }

}
