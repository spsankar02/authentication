package com.nalamfarms.cart_service.serviceimpl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.nalamfarms.cart_service.dto.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nalamfarms.cart_service.entity.Cart;
import com.nalamfarms.cart_service.entity.CartStatus;
import com.nalamfarms.cart_service.entity.CartType;
import com.nalamfarms.cart_service.entity.SaveStatus;
import com.nalamfarms.cart_service.exception.CustomErrorType;
import com.nalamfarms.cart_service.exception.GraphQLServiceException;
import com.nalamfarms.cart_service.repository.CartRepository;
import com.nalamfarms.cart_service.service.CartService;
import com.nalamfarms.cart_service.util.ResponseContent;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

	private static final Logger log = LoggerFactory.getLogger(CartServiceImpl.class);
//	private final WebClient.Builder webClientBuilder;
	private final CartRepository cartRepo;
	private final WebClient webClient;
//	private final ObjectMapper objectMapper;

	@Value("${productservice.url}")
	private String productServiceUrl;
	
	@Value("${orderservice.url}")
	private String orderServiceUrl;

	@Override
	public List<Cart> addCartDetails(List<AddToCartRequest> addCartRequest) {
		if (addCartRequest == null || addCartRequest.isEmpty()) {
	        log.warn("addCartDetails called with null or empty request list");
			return Collections.emptyList();
		}
		
	    log.info("Adding/updating cart details for {} requests", addCartRequest.size());

		
		List<Cart> carts = addCartRequest.stream().filter(request -> request.getMemberId() != null)
				.map(this::buildOrUpdateCart).collect(Collectors.toList());

		if (carts.isEmpty()) {
	        log.warn("No valid carts to add after filtering memberId != null");
			return Collections.emptyList();
		}

		try {
	        log.info("Successfully saved {} carts", cartRepo.saveAll(carts).size());

			return cartRepo.saveAll(carts);
		} catch (GraphQLServiceException e) {
	        log.error("GraphQLServiceException in addCartDetails: {}", e.getMessage(), e);

			throw e;
		} catch (Exception e) {
	        log.error("Unexpected error saving cart details: {}", e.getMessage(), e);
			throw new GraphQLServiceException(ResponseContent.SAVE_CART_EXCEPTION + e.getMessage(),
					CustomErrorType.INTERNAL_ERROR);
		}
	}

	private Cart buildOrUpdateCart(AddToCartRequest request) {
		Long memberId = request.getMemberId();
		Long productId = request.getProductId();
		Long skuId = request.getSkuId();

		Optional<Cart> existingCart = Optional.empty();
		//MappingItemDeals dealResponse = null;

//		boolean isItemBased = itemId != null && productId != null && variantTypeId != null && basketId == null;
//		boolean isBasketBased = basketId != null && variantTypeId != null && itemId == null && productId == null;

		if (skuId==null) {
			throw new GraphQLServiceException(
					ResponseContent.INVALID_CART_INPUT_EXCEPTION,
					CustomErrorType.BAD_REQUEST);
		}

		// Check for existing cart based on conditions
//		if (isItemBased) {
//			// Case 1: itemId and productId are not null, basketId is null
//			existingCart = cartRepo.findByMemberIdAndProductIdAndItemIdAndVariantTypeIdAndIsActiveTrue(memberId,
//					productId, itemId, variantTypeId);
//	        log.debug("Looking for existing item-based cart: found={}", existingCart.isPresent());
//
//			//dealResponse = fetchDealPrice(productId, itemId);
//		} else if (isBasketBased) {
//			// Case 2: basketId is not null, itemId and productId are null
//			existingCart = cartRepo.findByMemberIdAndBasketIdAndVariantTypeIdAndIsActiveTrue(memberId, basketId,
//					variantTypeId);
//	        log.debug("Looking for existing basket-based cart: found={}", existingCart.isPresent());
//
//		}

		existingCart= cartRepo.findByMemberIdAndIsActiveTrueAndSkuId(memberId,skuId);
		
		boolean isDeal = Boolean.TRUE.equals(request.getIsDealItem());

		BigDecimal dealPrice = isDeal && request.getDealPrice() != null ? request.getDealPrice() : BigDecimal.ZERO;
		BigDecimal dealDiscount = isDeal && request.getDealDiscount() != null ? request.getDealDiscount() : BigDecimal.ZERO;
		
		if (request.getQuantity() != null && request.getQuantity() == 0) {
	        if (existingCart.isPresent()) {
	            Cart cart = existingCart.get();
	            cart.setIsActive(false);
	            cart.setModifiedBy(memberId);
	            cart.setModifiedAt(LocalDateTime.now());
	            return cartRepo.save(cart); 
	        } else {
	        	   String errMsg = ResponseContent.DEACTIVE_CART_ERRORMESSAGE + memberId;
	               log.error(errMsg);
	            throw new GraphQLServiceException(ResponseContent.DEACTIVE_CART_ERRORMESSAGE + memberId, CustomErrorType.NOT_FOUND);
	        }
	    }

		if (existingCart.isPresent() && ResponseContent.ADD.equalsIgnoreCase(request.getType())) {
			// Update existing cart
			Cart cart = existingCart.get();
			Integer newQuantity = request.getQuantity() != null ? request.getQuantity() : cart.getQuantity();
	        log.info("Updating existing cart id: {} quantity from {} to {}", cart.getCartId(), cart.getQuantity(), newQuantity);
			cart.setQuantity(newQuantity);
			cart.setModifiedBy(memberId);
			cart.setModifiedAt(LocalDateTime.now());
			if (request.getPriceAtAdd() != null) {
				cart.setPriceAtAdd(request.getPriceAtAdd());
			}
			if (request.getDiscountAtAdd() != null) {
				cart.setDiscountAtAdd(request.getDiscountAtAdd());
			}
			cart.setDealPrice(dealPrice);
			cart.setDealDiscount(dealDiscount);
			return cart;
		}

		if (ResponseContent.SUBSCRIPTION.equalsIgnoreCase(request.getType())) {

			if (existingCart.isPresent() && existingCart.get().isSubscribed()) {
	            log.info("Returning existing subscribed cart id: {}", existingCart.get().getCartId());

				return existingCart.get();
			}

			List<Cart> subscribedCarts = cartRepo.findByMemberIdAndIsActiveTrueAndIsSubscribedTrue(memberId);

			if (!subscribedCarts.isEmpty()) {
	            log.info("Deactivating {} existing subscribed carts for memberId: {}", subscribedCarts.size(), memberId);

				subscribedCarts.forEach(oldCart -> {
					oldCart.setSubscribed(false);
					oldCart.setIsActive(false);
					oldCart.setModifiedBy(memberId);
					oldCart.setModifiedAt(LocalDateTime.now());
				});
				cartRepo.saveAll(subscribedCarts);
			}
		}

		Cart cart = new Cart();
		cart.setMemberId(memberId);
		cart.setCreatedBy(memberId);
		cart.setModifiedBy(null);
		cart.setIsActive(true);
		cart.setQuantity(request.getQuantity() != null ? request.getQuantity() : 1);
		//cart.setProductId(productId);
		//cart.setItemId(itemId);
		//cart.setBasketId(basketId);
		cart.setSkuId(skuId);
		cart.setPriceAtAdd(request.getPriceAtAdd() !=null ? request.getPriceAtAdd() : BigDecimal.ZERO);

		CartType cartType = CartType.from(productId, null);
		cart.setType(cartType.getValue());

		cart.setDiscountAtAdd(request.getDiscountAtAdd()!=null ? request.getDiscountAtAdd() : BigDecimal.ZERO);
		cart.setCreatedAt(LocalDateTime.now());
		cart.setModifiedAt(null);
		cart.setSaveStatus(SaveStatus.CART.getValue());
		//cart.setVariantTypeId(variantTypeId);
		cart.setIsOfferItem(request.getIsOfferItem()!=null ? request.getIsOfferItem(): false);	
		if (request.getType().equalsIgnoreCase(ResponseContent.SUBSCRIPTION)) {
			cart.setSubscribed(true);
		} else if (request.getType().equalsIgnoreCase(ResponseContent.ADD)) {
			cart.setSubscribed(false);
		}
		cart.setDealPrice(dealPrice);
		cart.setDealDiscount(dealDiscount);
		
		 log.info("Created new cart for memberId: {} with productId: {}, skuId: {}, quantity: {}",
		            memberId, productId, skuId, cart.getQuantity());

		
		return cart;
	}

	@Override
	public CartResponse deleteCartDetails(DeleteCartRequest cartRequest) {
		try {
			log.info("Attempting to delete cart. CartId: {}, MemberId: {}", cartRequest.getCartId(), cartRequest.getMemberId());
			Cart cart = cartRepo.findByCartIdAndMemberIdAndIsActiveTrue(cartRequest.getCartId(),
					cartRequest.getMemberId());
			if (cart == null) {
				log.warn("Cart not found or already inactive. CartId: {}, MemberId: {}", cartRequest.getCartId(), cartRequest.getMemberId());
				return new CartResponse(false, ResponseContent.CART_NOT_FOUND_EXCEPTION);
			}
			cart.setIsActive(false);
			cart.setModifiedAt(LocalDateTime.now());
			cart.setModifiedBy(cartRequest.getMemberId());
			CartStatus status = CartStatus.fromValue(cartRequest.getStatus());
			cart.setCartStatus(status.getStatusName());
			cartRepo.save(cart);
			log.info("Cart deactivated successfully. CartId: {}, MemberId: {}", cartRequest.getCartId(), cartRequest.getMemberId());

			return new CartResponse(true, ResponseContent.DEACTIVE_CART_SUCESSFULLY);
		} catch (Exception e) {
			log.error("Error deactivating cart. CartId: {}, MemberId: {}, Error: {}", cartRequest.getCartId(), cartRequest.getMemberId(), e.getMessage(), e);

			throw new GraphQLServiceException(ResponseContent.DEACTIVE_CART_ERRORMESSAGE + e.getMessage(),
					CustomErrorType.INTERNAL_ERROR);
		}
	}

	@Override
	public List<Cart> getCartDetailsByMemberId(Long memberId) {
		log.info("Fetching cart details for MemberId: {}", memberId);
		try {
			List<Cart> carts = cartRepo.findByMemberIdAndIsActiveTrue(memberId);
			log.info("Found {} active carts for MemberId: {}", carts.size(), memberId);
			return carts;
		} catch (Exception e) {
			log.error("Error fetching cart details by MemberId: {}", memberId, e);
			throw e;
		}
	}

	@Override
	public List<Cart> getCartDetailsBycartIds(List<Long> cartIds) {
		log.info("Fetching cart details for cartIds: {}", cartIds);
		try {
			List<Cart> carts = cartRepo.findAllByCartIdIn(cartIds);
			log.info("Found {} carts for provided IDs.", carts.size());
			return carts;
		} catch (Exception e) {
			log.error("Error fetching carts by IDs: {}", cartIds, e);
			throw e;
		}
//	    if (carts.isEmpty()) {
//	        return Collections.emptyList();
//	    }
//
//	    Long memberId = carts.get(0).getMemberId(); 
//	    List<MemberCategoryOfferItemBasketDto> offers = getMemberOffers(memberId);
//
//	    Map<String, MemberCategoryOfferItemBasketDto> offerMap = offers.stream()
//	        .collect(Collectors.toMap(
//	            offer -> offer.getBasket() + "_" + offer.getVarientTypeId(),
//	            offer -> offer,
//	            (existing, replacement) -> existing 
//	        ));
//
//	    for (Cart cart : carts) {
//	        if (cart.getIsOfferItem()!=null && cart.getIsOfferItem()) {
//	            String key = cart.getBasketId() + "_" + cart.getVariantTypeId();
//	            MemberCategoryOfferItemBasketDto matchingOffer = offerMap.get(key);
//	            if (matchingOffer != null) {
//	                cart.setMappingOfferId(matchingOffer.getMappingOfferItemBasketId());
//	                cart.setOfferId(matchingOffer.getOfferId());
//	            }
//	        }
//	    }
//
//	    return carts;
	}

//	@Override
//	public CartDetailsResponse getAddCartDetails(Long memberId, String type) {
//		log.info("Starting cart details retrieval for memberId: {}", memberId);
//		validateMemberId(memberId);
//		try {
//			List<Cart> cartList = cartRepo.findByMemberIdAndIsActiveTrue(memberId);
//			if (cartList.isEmpty()) {
//				log.debug("No active carts found for memberId: {}", memberId);
//				return new CartDetailsResponse(Collections.emptyList());
//			}
//
//			Map<Long, Long> itemIdToVariantTypeId = cartList.stream()
//					.filter(cart -> cart.getItemId() != null && cart.getVariantTypeId() != null)
//					.collect(Collectors.toMap(Cart::getItemId, Cart::getVariantTypeId, (v1, v2) -> v1));
//
//			// Map basketId to its single variantTypeId from cartList
//			Map<Long, Long> basketIdToVariantTypeId = cartList.stream()
//					.filter(cart -> cart.getBasketId() != null && cart.getVariantTypeId() != null)
//					.collect(Collectors.toMap(Cart::getBasketId, Cart::getVariantTypeId, (v1, v2) -> v1));
//
//			if (itemIdToVariantTypeId.isEmpty() && basketIdToVariantTypeId.isEmpty()) {
//				log.debug("No valid item or basket IDs found for memberId: {}", memberId);
//				return new CartDetailsResponse(Collections.emptyList());
//			}
//
//			JsonNode itemResponse = fetchProductDetails(itemIdToVariantTypeId, basketIdToVariantTypeId, type, memberId);
//			log.info("Successfully fetched product details for memberId: {}", memberId);
//
//			// Parse results into items and baskets
//			JsonNode resultsNode = itemResponse.path("data").path("getProductDetails").path("results");
//			List<Result> productResults = objectMapper.convertValue(resultsNode,
//					objectMapper.getTypeFactory().constructCollectionType(List.class, Result.class));
//
//			// Create maps for quick lookup
//			Map<Long, Result> itemMap = productResults.stream().filter(result -> result.getItemId() != null)
//					.collect(Collectors.toMap(Result::getItemId, result -> result));
//
//			Map<Long, Result> basketMap = productResults.stream().filter(result -> result.getBasketId() != null)
//					.collect(Collectors.toMap(Result::getBasketId, result -> result));
//
//			List<CartServiceResult> results = new ArrayList<>();
//
//			for (Cart cart : cartList) {
//				processCartItem(cart, itemMap, basketMap, results);
//			}
//	        results.sort(Comparator.comparing(CartServiceResult::getCartId));
//			return new CartDetailsResponse(results);
//
//		} catch (Exception e) {
//			log.error("Error processing cart details for memberId: {}", memberId, e);
//			throw new CartServiceException("Failed to retrieve cart details", e);
//		}
//	}
//
//	private void validateMemberId(Long memberId) {
//		if (memberId == null || memberId <= 0) {
//			log.error("Invalid memberId: {}", memberId);
//			throw new IllegalArgumentException("Member ID must be a positive number");
//		}
//	}
//
//	private void processCartItem(Cart cart, Map<Long, Result> itemMap, Map<Long, Result> basketMap,
//			List<CartServiceResult> results) {
//		try {
//			Result sourceResult = null;
//			if (cart.getItemId() != null && itemMap.containsKey(cart.getItemId())) {
//				sourceResult = itemMap.get(cart.getItemId());
//
//			} else if (cart.getBasketId() != null && basketMap.containsKey(cart.getBasketId())) {
//				sourceResult = basketMap.get(cart.getBasketId());
//			}
//			if (sourceResult == null) {
//				log.warn("No matching product details found for cartId: {}, itemId: {}, basketId: {}", cart.getCartId(),
//						cart.getItemId(), cart.getBasketId());
//				return;
//			}
//
//			int quantity = cart.getQuantity() != null ? cart.getQuantity() : 1;
//
//			// Only update realPrice based on quantity (no discount logic here)
//			if (sourceResult.getVariantLists() != null && cart.getVariantTypeId() != null) {
//				for (VariantList variant : sourceResult.getVariantLists()) {
//					if (variant.getVariantTypeId().equals(cart.getVariantTypeId())) {
//
//						if (variant.getItemPrices() != null && variant.getItemPrices().getRealPrice() != null) {
//							BigDecimal itemRealPrice = variant.getItemPrices().getRealPrice()
//									.multiply(BigDecimal.valueOf(quantity));
//							variant.getItemPrices().setRealPrice(itemRealPrice);
//						}
//
//						if (variant.getBasketprices() != null && variant.getBasketprices().getRealPrice() != null) {
//							BigDecimal basketRealPrice = variant.getBasketprices().getRealPrice()
//									.multiply(BigDecimal.valueOf(quantity));
//							variant.getBasketprices().setRealPrice(basketRealPrice);
//						}
//
//						break; // Found matching variant, no need to continue
//					}
//				}
//			}
//
//			String type = cart.getType() != null
//					? (cart.getType() == 1 ? "ITEM" : cart.getType() == 2 ? "BASKET" : null)
//					: null;
//			Boolean saveStatus = cart.getSaveStatus() != null ? (cart.getSaveStatus() == 1) : null;
//			CartServiceResult cartResult = new CartServiceResult(cart.getCartId(), cart.getProductId(),
//					cart.getIsActive(), saveStatus, cart.getQuantity(), cart.getVariantTypeId(), cart.getPriceAtAdd(),
//					cart.getDiscountAtAdd(), type, cart.getIsOfferItem(), sourceResult.getItemId(), sourceResult.getItemName(),
//					sourceResult.getImageUrl(), sourceResult.getIsActive(), sourceResult.getProduct(),
//					sourceResult.getBasketId(), sourceResult.getBasketName(), sourceResult.getUpcoming(),
//					sourceResult.getDescription(), sourceResult.getVariantLists(), cart.isSubscribed());
//			results.add(cartResult);
//		} catch (Exception e) {
//			log.error("Error processing cart item: {}", cart.getCartId(), e);
//			throw new CartServiceException("Failed to process cart item: " + cart.getCartId(), e);
//		}
//	}
//
//	private JsonNode fetchProductDetails(Map<Long, Long> itemIdToVariantTypeId, Map<Long, Long> basketIdToVariantTypeId,
//			String type, Long memberId) {
//		try {
//			String query = buildGraphQLQuery();
//			ObjectNode variables = objectMapper.createObjectNode();
//
//			List<ObjectNode> itemInput = new ArrayList<>();
//
//			if (itemIdToVariantTypeId != null && !itemIdToVariantTypeId.isEmpty()) {
//				itemInput = itemIdToVariantTypeId.entrySet().stream().map(entry -> {
//					ObjectNode input = objectMapper.createObjectNode();
//					input.put("itemId", entry.getKey());
//					input.put("variantTypeId", entry.getValue());
//					return input;
//				}).collect(Collectors.toList());
//			}
//
//			List<ObjectNode> basketInput = new ArrayList<>();
//			if (basketIdToVariantTypeId != null && !basketIdToVariantTypeId.isEmpty()) {
//				basketInput = basketIdToVariantTypeId.entrySet().stream().map(entry -> {
//					ObjectNode input = objectMapper.createObjectNode();
//					input.put("basketId", entry.getKey());
//					input.put("variantTypeId", entry.getValue());
//					return input;
//				}).collect(Collectors.toList());
//			}
//
//			variables.putPOJO("itemInput", itemInput.isEmpty() ? null : itemInput);
//			variables.putPOJO("basketInput", basketInput.isEmpty() ? null : basketInput);
//			variables.put("type", type);
//			variables.put("memberId", memberId);
//
//			ObjectNode requestBody = objectMapper.createObjectNode();
//			requestBody.put("query", query);
//			requestBody.set("variables", variables);
//
//			return webClient.post().uri(productServiceUrl + GRAPHQL_PATH).bodyValue(requestBody).retrieve()
//					.onStatus(status -> status.isError(),
//							response -> response.bodyToMono(String.class)
//									.map(body -> new CartServiceException("Product service responded with status: "
//											+ response.statusCode() + ", body: " + body)))
//					.bodyToMono(JsonNode.class).blockOptional()
//					.orElseThrow(() -> new CartServiceException("No response from product service"));
//
//		} catch (Exception e) {
//			log.error("Error fetching product details: {}", e.getMessage());
//			throw new CartServiceException("Failed to fetch product details", e);
//		}
//	}
//
//	private String buildGraphQLQuery() {
//		return """
//				    query GetProductDetails($itemInput: [BasketInput], $basketInput: [BasketInput], $type: String!, $memberId: ID) {
//				        getProductDetails(itemInput: $itemInput, basketInput: $basketInput, type: $type, memberId: $memberId) {
//				            results {
//				                itemId
//				                itemName
//				                imageUrl
//				                isActive
//				                basketId
//				                basketName
//				                upcoming
//				                description
//				                product {
//				                    productId
//				                    productName
//				                    imageUrl
//				                }
//				                variantLists {
//				                    variantTypeId
//				                    variantTypeName
//				                    size
//				                    wishList
//				                    isStockAvailable
//				                    stockQuantity
//				                    isSubscribed
//				                    basketprices {
//				                        basketPriceId
//				                        basketId
//				                        price
//				                        discount
//				                        isActive
//				                        realPrice
//				                    }
//				                    itemPrices {
//				                           price
//				                           discount
//				                           realPrice
//				                           isDealItem
//				                           dealPrice
//				                           dealDiscount
//				                       }
//				                    itemList {
//				                        itemId
//				                        itemName
//				                        productId
//				                        imageUrl
//				                        price
//				                        discount
//				                        realPrice
//				                        wishList
//				                        isStockAvailable
//				                        stockQuantity
//				                        size
//				                        unitName
//				                        isActive
//				                        products {
//				                            productId
//				                            productName
//				                            imageUrl
//				                        }
//				                    }
//				                }
//				            }
//				        }
//				    }
//				""";
//	}

//	public BillDetails getCartSummary(Long memberId, List<Long> cartIds, String type,boolean isUsedPoints) {
//		if (cartIds == null || cartIds.isEmpty()) {
//			log.error("Invalid cartIds: {}", cartIds);
//			throw new IllegalArgumentException("Cart IDs must not be null or empty");
//		}
//		try {
//			List<Cart> cartList = cartRepo.findByCartIdInAndMemberIdAndIsActiveTrue(cartIds, memberId);
//			if (cartList.isEmpty()) {
//				log.debug("No active carts found for memberId: {}, cartIds: {}", memberId, cartIds);
//				return new BillDetails(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, 
//						BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO, 0);
//			}
//
//			Map<Long, Long> itemIdToVariantTypeId = cartList.stream()
//					.filter(cart -> cart.getItemId() != null && cart.getVariantTypeId() != null)
//					.collect(Collectors.toMap(Cart::getItemId, Cart::getVariantTypeId, (v1, v2) -> v1));
//
//			Map<Long, Long> basketIdToVariantTypeId = cartList.stream()
//					.filter(cart -> cart.getBasketId() != null && cart.getVariantTypeId() != null)
//					.collect(Collectors.toMap(Cart::getBasketId, Cart::getVariantTypeId, (v1, v2) -> v1));
//
//			JsonNode itemResponse = fetchProductDetails(itemIdToVariantTypeId, basketIdToVariantTypeId, type, memberId);
//			log.info("Successfully fetched product details for memberId: {}", memberId);
//
//			JsonNode resultsNode = itemResponse.path("data").path("getProductDetails").path("results");
//			List<Result> productResults = objectMapper.convertValue(resultsNode,
//					objectMapper.getTypeFactory().constructCollectionType(List.class, Result.class));
//
//			Map<Long, Result> itemMap = productResults.stream().filter(result -> result.getItemId() != null)
//					.collect(Collectors.toMap(Result::getItemId, result -> result));
//
//			Map<Long, Result> basketMap = productResults.stream().filter(result -> result.getBasketId() != null)
//					.collect(Collectors.toMap(Result::getBasketId, result -> result));
//
//			BigDecimal itemTotal = BigDecimal.ZERO;
//			BigDecimal totalSaving = BigDecimal.ZERO;
//			BigDecimal deliveryCharge = BigDecimal.ZERO;
//			BigDecimal handlingCharge = new BigDecimal("5.0");
//			BigDecimal creditPointAmount  = BigDecimal.ZERO;
//			BigDecimal cartGrandTotal=BigDecimal.ZERO;
//			int totalPoints=0;
//
//			for (Cart cart : cartList) {
//				
//				if (Boolean.TRUE.equals(cart.getIsOfferItem())) {
//			        log.info("Offer item detected. Skipping price and discount for cartId: {}", cart.getCartId());
//			        continue;
//			    }
//				
//				BigDecimal quantity = cart.getQuantity() != null ? new BigDecimal(cart.getQuantity()) : BigDecimal.ZERO;
//				BigDecimal price = BigDecimal.ZERO;
//				BigDecimal discount = BigDecimal.ZERO;
//
//				if (cart.getItemId() != null && itemMap.containsKey(cart.getItemId())) {
//					Result item = itemMap.get(cart.getItemId());
//					if (item.getVariantLists() != null && cart.getVariantTypeId() != null) {
//						Optional<VariantList> variantOpt = item.getVariantLists().stream()
//								.filter(v -> cart.getVariantTypeId().equals(v.getVariantTypeId())).findFirst();
//
//						if (variantOpt.isPresent()) {
//							ItemPrices itemPrices = variantOpt.get().getItemPrices();
//							if (itemPrices != null) {
//								if (itemPrices.isDealItem()) {
//									price = itemPrices.getDealPrice() != null ? itemPrices.getDealPrice()
//											: BigDecimal.ZERO;
//									discount = itemPrices.getDealDiscount() != null ? itemPrices.getDealDiscount()
//											: BigDecimal.ZERO;
//								} else {
//									price = itemPrices.getPrice() != null ? itemPrices.getPrice() : BigDecimal.ZERO;
//									discount = itemPrices.getDiscount() != null ? itemPrices.getDiscount()
//											: BigDecimal.ZERO;
//								}
//
//							}
//						} else {
//							log.warn("No matching variantTypeId for itemId: {}", cart.getItemId());
//							continue;
//						}
//					} else {
//						log.warn("Missing variantLists or variantTypeId for itemId: {}", cart.getItemId());
//						continue;
//					}
//
//				} else if (cart.getBasketId() != null && basketMap.containsKey(cart.getBasketId())
//						&& cart.getVariantTypeId() != null) {
//					Result basket = basketMap.get(cart.getBasketId());
//					if (basket.getVariantLists() != null) {
//						Optional<Basketprices> prices = basket.getVariantLists().stream()
//								.filter(v -> cart.getVariantTypeId().equals(v.getVariantTypeId()))
//								.map(VariantList::getBasketprices).filter(Objects::nonNull)
//								.filter(Basketprices::getIsActive).findFirst();
//
//						if (prices.isPresent()) {
//							price = prices.get().getPrice() != null ? prices.get().getPrice() : BigDecimal.ZERO;
//							discount = prices.get().getDiscount() != null ? prices.get().getDiscount()
//									: BigDecimal.ZERO;
//						} else {
//							log.warn("Invalid basket prices for cartId: {}, basketId: {}, variantTypeId: {}",
//									cart.getCartId(), cart.getBasketId(), cart.getVariantTypeId());
//							continue;
//						}
//					} else {
//						log.warn("No variant lists for basketId: {}", cart.getBasketId());
//						continue;
//					}
//				} else {
//					log.warn("Invalid item/basket in cartId: {}", cart.getCartId());
//					continue;
//				}
//				
//
//				BigDecimal discountAmountPerItem = price.multiply(discount).divide(BigDecimal.valueOf(100));
//
//				BigDecimal totalPrice = price.multiply(quantity);
//
//				// Total discount for the quantity
//				BigDecimal totalDiscount = discountAmountPerItem.multiply(quantity);
//
//				// Final totals
//				itemTotal = itemTotal.add(totalPrice.subtract(totalDiscount));
//				totalSaving = totalSaving.add(totalDiscount);
//			}
//           
//			BigDecimal grandTotal = itemTotal.add(deliveryCharge).add(handlingCharge);
//			cartGrandTotal=grandTotal;
//			
//			
//			if (isUsedPoints) {
//				RewardPointEntityDto points = fetchMemberRewardPointById(memberId).block();
//
//				List<RewardPointAmountConfigDto> pointAmountList = getAllRewardPointAmountConfigs().block();
//
//				if (points != null && pointAmountList != null && !pointAmountList.isEmpty()) {
//					RewardPointAmountConfigDto config = pointAmountList.get(0);
//					BigDecimal amountPerPoint = config.getAmountValue();
//					BigDecimal.valueOf(points.getPoints());
//					totalPoints = points.getPoints();
//
//					creditPointAmount = BigDecimal.valueOf(totalPoints).multiply(amountPerPoint);
//
//					if (grandTotal.compareTo(creditPointAmount) > 0) {
//						// Full credit can be used
//						grandTotal = grandTotal.subtract(creditPointAmount);
//						System.out.println("Full credit applied: ₹" + creditPointAmount);
//					}
//
////			        } else if (grandTotal.compareTo(creditPointAmount) == 0) {
////			            // Exact credit equals grandTotal
////			            System.out.println("Exact credit matched grand total (₹" + creditPointAmount + "), but not deducted.");
////
////			        } else {
////			            // Credit more than grandTotal → apply partial
////			            BigDecimal requiredAmount = grandTotal;
////			            int pointsToUse = requiredAmount.divide(amountPerPoint, 0, RoundingMode.FLOOR).intValue();
////
////			            BigDecimal actualCreditUsed = amountPerPoint.multiply(BigDecimal.valueOf(pointsToUse));
////			            grandTotal = grandTotal.subtract(actualCreditUsed);
////
////			            int remainingPoints = points.getPoints() - pointsToUse;
////
////			            System.out.println("Partially applied credit: ₹" + actualCreditUsed + " using " + pointsToUse + " points");
////			            System.out.println("Remaining points: " + remainingPoints);
////			        }
//				}
//			}
//
//			return new BillDetails(itemTotal, totalSaving, deliveryCharge, handlingCharge, grandTotal,cartGrandTotal,
//					creditPointAmount, totalPoints);
//
//		} catch (Exception e) {
//			log.error("Error processing cart summary for memberId: {}, cartIds: {}", memberId, cartIds, e);
//			throw new CartServiceException("Failed to retrieve cart summary", e);
//		}
//	}

	@Override
	public List<CartQuantityDetails> getCartQuantity(Long memberId, List<Long> skuIds) {
		try {
			log.info("Fetching cart quantity for memberId: {}, skuIds: {}", memberId, skuIds);

			if (skuIds == null || skuIds.isEmpty()) {
				log.warn("Empty SKU list provided for memberId: {}", memberId);
				return Collections.emptyList();
			}

			List<Cart> cartItems = cartRepo.findByMemberIdAndIsActiveTrueAndSkuIdIn(memberId, skuIds);

			if (cartItems.isEmpty()) {
				log.info("No active cart items found for memberId: {} and skuIds: {}", memberId, skuIds);
				return Collections.emptyList();
			}

			List<CartQuantityDetails> result = cartItems.stream()
					.map(cart -> new CartQuantityDetails(0, 0, cart.getSkuId(), cart.getQuantity()))
					.collect(Collectors.toList());

			log.info("Found {} active cart entries for memberId: {}", result.size(), memberId);

			return result;

		} catch (Exception e) {
			log.error("Unexpected error while retrieving cart for memberId: {}", memberId, e);
			throw new CartServiceException(ResponseContent.RETERIVIENG_CART_ERRORMESSAGE, e);
		}
//		throw new CartServiceException(
//				"No active cart found for memberId: " + memberId + ", itemId: " + itemId + ", basketId: " + basketId);
	}

//	public MappingItemDeals fetchDealPrice(Long productId, Long itemId) {
//		try {
//			Map<String, Object> variables = Map.of("productId", productId, "itemId", itemId);
//
//			Map<String, Object> requestBody = Map.of("query",
//					"query($productId: Long!, $itemId: Long!) { getDealDetails(productId: $productId, itemId: $itemId) { itemPrice discountPrice isItemDeal } }",
//					"variables", variables);
//
//			JsonNode responseNode = webClient.post().uri(productServiceUrl + GRAPHQL_PATH).bodyValue(requestBody)
//					.retrieve().bodyToMono(JsonNode.class).blockOptional()
//					.orElseThrow(() -> new RuntimeException("No response from product service"));
//
//			JsonNode dealNode = responseNode.path("data").path("getDealDetails");
//
//			if (dealNode.isMissingNode() || dealNode.isNull()) {
//				throw new RuntimeException("getDealDetails is missing or null in response");
//			}
//
//			BigDecimal dealPrice = dealNode.hasNonNull("itemPrice") ? dealNode.get("itemPrice").decimalValue() : null;
//			BigDecimal dealDiscount = dealNode.hasNonNull("discountPrice")
//					? dealNode.get("discountPrice").decimalValue()
//					: null;
//			boolean isItemDeal = dealNode.path("isItemDeal").asBoolean(false);
//
//			return new MappingItemDeals(dealPrice, dealDiscount, isItemDeal);
//
//		} catch (Exception e) {
//			throw new RuntimeException("Failed to fetch deal price: " + e.getMessage(), e);
//		}
//	}

	public boolean checkIsDeal(BigDecimal dealPrice, BigDecimal dealDiscount) {
		boolean result = dealPrice != null && dealDiscount != null
	            && (dealPrice.compareTo(BigDecimal.ZERO) > 0 || dealDiscount.compareTo(BigDecimal.ZERO) > 0);
	    log.debug("checkIsDeal called with dealPrice: {}, dealDiscount: {} -> result: {}", dealPrice, dealDiscount, result);
	    return result;
	}

	public BigDecimal calculateItemTotal(BigDecimal price, BigDecimal discount, int quantity) {
		if (price == null || discount == null) {
			log.warn("calculateItemTotal received null price or discount. Returning 0.");
			return BigDecimal.ZERO;
		}

		BigDecimal qty = BigDecimal.valueOf(quantity);
		BigDecimal totalPrice = price.multiply(qty);
		BigDecimal totalDiscount = discount.multiply(qty);
		  BigDecimal total = totalPrice.subtract(totalDiscount);
	    log.debug("calculateItemTotal price: {}, discount: {}, quantity: {} -> total: {}", price, discount, quantity, total);

		return total;
	}
	
	public Mono<RewardPointEntityDto> fetchMemberRewardPointById(Long memberId) {
		String query = """
				    {
				        "query": "query($input: RewardPointDTO!) { getMemberRewardPointById(input: $input) { memberRewardPointId memberId points } }",
				        "variables": {
				            "input": {
				                "memberId": %d
				            }
				        }
				    }
				"""
				.formatted(memberId);

		return webClient.post().uri(orderServiceUrl + ResponseContent.GRAPHQL_PATH).contentType(MediaType.APPLICATION_JSON)
				.bodyValue(query).retrieve().bodyToMono(String.class).map(responseJson -> {
					try {
						JsonNode root = new ObjectMapper().readTree(responseJson);
						JsonNode data = root.path("data").path("getMemberRewardPointById");
		                log.debug("Reward points fetched successfully for memberId: {}", memberId);
						return new ObjectMapper().treeToValue(data, RewardPointEntityDto.class);
					} catch (Exception e) {
		                log.error("Failed to parse reward points response for memberId: {}", memberId, e);
						throw new RuntimeException(ResponseContent.GRAPHQL_PARSE_EXCEPTION, e);
					}
				});
	}
	
	public Mono<List<RewardPointAmountConfigDto>> getAllRewardPointAmountConfigs() {
		String query = """
				    {
				        "query": "query { getAllRewardPointAmountConfigs { rewardPointAmountConfigId pointValue amountValue isActive } }"
				    }
				""";

		return webClient.post().uri(orderServiceUrl + ResponseContent.GRAPHQL_PATH).contentType(MediaType.APPLICATION_JSON)
				.bodyValue(query).retrieve().bodyToMono(String.class).map(responseJson -> {
					try {
						ObjectMapper mapper = new ObjectMapper();
						JsonNode root = mapper.readTree(responseJson);
						JsonNode dataNode = root.path("data").path("getAllRewardPointAmountConfigs");
		                log.debug("Reward point amount configs fetched successfully");
						return Arrays.asList(mapper.treeToValue(dataNode, RewardPointAmountConfigDto[].class));
					} catch (Exception e) {
		                log.error("Failed to parse reward point amount configs response", e);
						throw new RuntimeException(ResponseContent.GRAPHQL_PARSE_EXCEPTION, e);
					}
				});
	}
	
	public List<MemberCategoryOfferItemBasketDto> getMemberOffers(Long memberId) {
	    log.info("Fetching member offers for memberId: {}", memberId);
		try {
	        String query = """
	            query($memberId: ID!) {
	              getMemberOffer(memberId: $memberId) {
	                mappingOfferItemBasketId
	                offerId
	                basket
	                varientTypeId
	                memberCategoryId
	              }
	            }
	        """;

	        Map<String, Object> requestBody = new HashMap<>();
	        requestBody.put("query", query);
	        requestBody.put("variables", Map.of("memberId", memberId));

	        WebClient webClient = WebClient.builder()
	                .baseUrl(productServiceUrl+ ResponseContent.GRAPHQL_PATH) 
	                .build();

	        Map<String, Object> response = webClient.post()
	        	    .bodyValue(requestBody)
	        	    .retrieve()
	        	    .onStatus(
	        	        status -> status.isError(),
	        	        clientResponse -> clientResponse.bodyToMono(String.class)
	        	            .map(body -> new RuntimeException(ResponseContent.MEMBEROFFER_EXCEPTION + body))
	        	    )
	        	    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
	        	    .blockOptional()
	        	    .orElseThrow(() -> new RuntimeException(ResponseContent.NO_RESPONSE_MEMBEROFFER_EXCEPTION));

	        Object data = ((Map<?, ?>) response.get("data")).get("getMemberOffer");

	        if (!(data instanceof List<?> resultList)) {
	            return Collections.emptyList();
	        }

	        List<MemberCategoryOfferItemBasketDto> dtoList = new ArrayList<>();
	        for (Object obj : resultList) {
	            Map<?, ?> map = (Map<?, ?>) obj;
	            MemberCategoryOfferItemBasketDto dto = new MemberCategoryOfferItemBasketDto();
	            dto.setMappingOfferItemBasketId(getLong(map.get("mappingOfferItemBasketId")));
	            dto.setOfferId(getLong(map.get("offerId")));
	            dto.setBasket(map.get("basket") != null ? getLong(map.get("basket")) : null);
	            dto.setVarientTypeId(getLong(map.get("varientTypeId")));
	            dto.setMemberCategoryId(getLong(map.get("memberCategoryId")));
	            dtoList.add(dto);
	        }
	        log.info("Successfully fetched {} member offers for memberId: {}", dtoList.size(), memberId);
	        return dtoList;

	    } catch (Exception e) {
	        log.error("Error fetching member offers: {}", e.getMessage(), e);
	        throw new RuntimeException(ResponseContent.MEMBEROFFER_EXCEPTION, e);
	    }
	}

	private Long getLong(Object value) {
	    return value != null ? Long.valueOf(value.toString()) : null;
	}
}