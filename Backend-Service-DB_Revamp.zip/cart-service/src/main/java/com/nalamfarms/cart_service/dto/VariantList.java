package com.nalamfarms.cart_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VariantList {
	private Long variantTypeId;
	private String variantTypeName;
	private Integer size;
    private boolean wishList;
	private Basketprices basketprices;
	private ItemPrices itemPrices;
	private List<Item> itemList;
    private boolean isStockAvailable;
    private BigDecimal stockQuantity;
    private boolean isSubscribed;
}
