package com.nalamfarms.cart_service.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalamfarms.cart_service.entity.Cart;

public interface CartRepository extends JpaRepository<Cart, Long> {

	Cart findByCartIdAndMemberIdAndIsActiveTrue(Long cartId, Long memberId);
	List<Cart> findByMemberIdAndIsActiveTrue(Long memberId);
	List<Cart> findAllByCartIdIn(List<Long> cartIds);
	List<Cart> findByMemberIdAndIsActiveTrueAndIsSubscribedTrue(Long memberId);
	Optional<Cart> findBySkuId(Long skuId);
	Optional<Cart> findByMemberIdAndIsActiveTrueAndSkuId(Long memberId,Long skuId);

	List<Cart> findByMemberIdAndIsActiveTrueAndSkuIdIn(Long memberId, List<Long> skuIds);
}