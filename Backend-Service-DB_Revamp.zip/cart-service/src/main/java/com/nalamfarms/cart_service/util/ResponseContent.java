package com.nalamfarms.cart_service.util;

public class ResponseContent {
	
	private ResponseContent() {}
	
	/**========== ERROR MESSAGES ==========**/
	public static final String NO_ACTIVE_CART_ERRORMESSAGE = "No active cart found to deactivate for memberId: ";
	public static final String RETERIVIENG_CART_ERRORMESSAGE = "Unexpected error while retrieving cart quantities";
	public static final String DEACTIVE_CART_ERRORMESSAGE = "Error deactivating cart:";
	
	
	
	/** ========== EXCEPTION MESSAGES ========== */
	public static final String CART_NOT_FOUND_EXCEPTION="Cart not found, wrong member, or already inactive";
	public static final String INVALID_CART_INPUT_EXCEPTION="Invalid cart input: Provide either (itemId + productId + variantTypeId) with no basketId "
			+ "OR (basketId + variantTypeId) with no itemId or productId.";
	public static final String SAVE_CART_EXCEPTION="Error saving cart details: ";
	public static final String MEMBEROFFER_EXCEPTION="Error from memberOffer service: ";
	public static final String NO_RESPONSE_MEMBEROFFER_EXCEPTION="No response from member offer service";
	public static final String GRAPHQL_PARSE_EXCEPTION="Failed to parse response";
	
	
	
	
	/** ========== STATUS MESSAGES ========== */
	public static final String SUBSCRIPTION = "subscription";
	public static final String DEACTIVE_CART_SUCESSFULLY = "Cart deactivated successfully";
	public static final String GRAPHQL_PATH = "/graphql";
	public static final String ADD = "add";
	
}
