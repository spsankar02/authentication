package com.nalamfarms.cart_service.service;

import java.util.List;

import com.nalamfarms.cart_service.dto.CartQuantityDetails;
import org.springframework.stereotype.Service;

import com.nalamfarms.cart_service.dto.AddToCartRequest;
import com.nalamfarms.cart_service.dto.CartResponse;
import com.nalamfarms.cart_service.dto.DeleteCartRequest;
import com.nalamfarms.cart_service.entity.Cart;

@Service
public interface CartService {

	List<Cart> addCartDetails(List<AddToCartRequest> request);

	CartResponse deleteCartDetails(DeleteCartRequest cartRequest);

	List<Cart> getCartDetailsByMemberId(Long memberId);

	//CartDetailsResponse getAddCartDetails(Long memberId, String type);

    //BillDetails getCartSummary(Long memberId, List<Long> cartIds,String type, boolean isUsedPoints);

    List<Cart> getCartDetailsBycartIds(List<Long> cartIds) ;

    List<CartQuantityDetails> getCartQuantity(Long memberId, List<Long> skuIds);

  }
