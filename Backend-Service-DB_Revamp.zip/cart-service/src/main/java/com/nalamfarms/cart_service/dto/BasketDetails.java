package com.nalamfarms.cart_service.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BasketDetails {
	private Long basketId;
    private String basketName;
    private String imageUrl;
    private Boolean isActive;
    private Boolean upcoming;
    private String description;
    private List<Item> items;
    private List<VariantList> variantLists;

}