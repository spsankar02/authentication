package com.nalamfarms.cart_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RewardPointAmountConfigDto {
	private Long rewardPointAmountConfigId;
	private BigDecimal pointValue;
	private BigDecimal amountValue;
	private Boolean isActive;
}
