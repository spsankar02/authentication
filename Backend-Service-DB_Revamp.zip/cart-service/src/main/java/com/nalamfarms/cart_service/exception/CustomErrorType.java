package com.nalamfarms.cart_service.exception;

import graphql.ErrorClassification;

public enum CustomErrorType implements ErrorClassification {
	NOT_FOUND, BAD_REQUEST, INTERNAL_ERROR
}
