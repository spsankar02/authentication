package com.nalamfarms.cart_service.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "order_master_cart")
@Data

@NoArgsConstructor
@AllArgsConstructor
public class Cart {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_id")
    private Long cartId;

    @Column(name = "member_id")
    private Long memberId;

    private Integer quantity = 1;

    @Column(name = "price_at_add", precision = 10, scale = 2)
    private BigDecimal priceAtAdd;

    @Column(name = "type", nullable = false)
    private Integer type;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "modified_at")
    private LocalDateTime modifiedAt;

    @Column(name = "created_by")
    private Long createdBy;

    @Column(name = "modified_by")
    private Long modifiedBy;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "save_status")
    private Integer saveStatus = SaveStatus.CART.getValue();
    
    @Column(name = "discount_at_add")
    private BigDecimal discountAtAdd;

    @Column(name = "is_subscribed")
    private boolean isSubscribed=false;
    
    @Column(name= "cart_status")
    private String cartStatus;
    
    @Column(name = "deal_price")
    private BigDecimal dealPrice;
    
    @Column(name = "deal_discount")
    private BigDecimal dealDiscount;
    
    @Column(name = "is_offer_item")
    private Boolean isOfferItem;
    
    @Transient
    private Long mappingOfferId;
    
    @Transient
    private Long offerId;

    @Column(name= "sku_id")
    private Long skuId;
}
