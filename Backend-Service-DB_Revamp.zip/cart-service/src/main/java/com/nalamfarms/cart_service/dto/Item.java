package com.nalamfarms.cart_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Item {
	private Long itemId;
    private String itemName;
    private String imageUrl;
    private Boolean isActive;
    private BigDecimal price;
	private BigDecimal discount;
	private Product products; 
	private BigDecimal realPrice;
	private Boolean wishList;
	private Boolean isStockAvailable;
	private BigDecimal stockQuantity;
	private int size;
	private String unitName;
}