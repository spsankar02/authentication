package com.nalamfarms.cart_service.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartItemDetails {
	private Long cartId;
	private Long productId;
	private Boolean isActive;
	private Integer saveStatus;
	private Item item;
	private Integer quantity;
	private Long variantTypeId;
	private BigDecimal priceAtAdd;
	private BigDecimal discountAtAdd;
	private Integer type;
	private Long mappingOfferId;
	private Long offerId;
}
