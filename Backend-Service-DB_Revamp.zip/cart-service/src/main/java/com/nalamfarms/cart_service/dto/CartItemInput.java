package com.nalamfarms.cart_service.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CartItemInput {
	private Long memberId;
	private Long productId;
	private Long itemId;
	private Long basketId;
	private Integer quantity;
	private BigDecimal priceAtAdd;
	private Long variantTypeId;
	private Long discountAtAdd;
}
